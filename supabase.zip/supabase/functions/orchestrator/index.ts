/**
 * @fileoverview ORQUESTRADOR CENTRAL (Gateway de Roteamento Bilateral)
 * @path supabase/functions/orchestrator/index.ts
 * 
 * ============================================================================
 * ARQUITETURA DE REDE E ROTEAMENTO (sbX Core)
 * ============================================================================
 * Este módulo é o coração do ecossistema sbX. Ele opera como E/S (Entrada/Saída):
 * - MODO LEITURA (GET): Hidrata o front-end com os dados da jornada atual.
 * - MODO ESCRITA (POST): Valida a intenção, registra a visita e define a rota.
 * 
 * @author Cesar Ismael Pereira da Costa
 * @description Single Source of Truth para roteamento dinâmico baseado em regras de negócio (PF/PJ, Parceiros, Canais).
 */

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { validateRequest } from "../_shared/auth.ts";
import { captureInfrastructure } from "../_shared/infrastructure.ts";
import { sql } from "../_shared/db.ts";
import { withSecurity } from "../_shared/server.ts";
import { validateVisitAndOfferIntegrity } from "../_shared/gateKeeper.ts";
import { persistVisitData } from "./persist-data.ts";

import {
  Entity,
  Manager,
  Seller,
  Event,
  Vehicle,
  Offer,
  InteractionContext,
  OrchestratorPayload,
  OrchestratorResponse,
  OriginDetails,
} from "../_shared/types.ts";

/**
 * FUNÇÃO DE LOG PADRONIZADA
 * Centraliza o rastreio do pipeline respeitando a flag DEBUG_MODE.
 */
import { debugLog } from "../_shared/logger.ts";


/**
 * ============================================================================
 * HELPER FUNCTIONS (Gatekeeper de Dados e Motor de Decisão)
 * ============================================================================
 */

/**
 * @function validatePayload
 * @description O "Gatekeeper" de Dados. Valida a integridade do payload campo a campo.
 * Regra de Negócio Crítica: Aplica obrigatoriedade dinâmica baseada no tipo de conta (PF vs PJ).
 */
async function validatePayload(
  supabaseClient: any,
  payload: OrchestratorPayload,
): Promise<{ category_id?: number; product_id?: number; action: "VISIT" | "CONSULT" | "REDIRECT" | "SIMULATE" | "CONTACT" }> {
  const errors: string[] = [];
  let found_category_id: number | undefined;
  let found_product_id: number | undefined = payload.product_id;

  const action = payload.action?.toUpperCase() as "VISIT" | "CONSULT" | "REDIRECT" | "SIMULATE" | "CONTACT";
  payload.action = action;

  // 1. Validação de Contexto de Tráfego
  if (!payload.interaction_context?.utm_source) errors.push("interaction_context.utm_source ausente.");
  const source = payload.interaction_context?.utm_source;

  if (!payload.interaction_context?.origin_url) errors.push("interaction_context.origin_url ausente.");
  if (!payload.origin_url) errors.push("origin_url ausente na raiz do payload. É obrigatório para o roteamento.");

  // Se a ação dita o destino no front-end, o front-end é obrigado a informar para onde está indo
  if (["VISIT", "REDIRECT", "CONTACT"].includes(action) && !payload.target_url) {
    errors.push(`target_url ausente. Obrigatório enviar o destino da página para ações do tipo ${action}.`);
  }

  // 2. Validação da Entidade (PF vs PJ)
  if (action === "SIMULATE" || action === "CONSULT" || payload.entity) {
    if (!payload.entity?.entity_id) errors.push("entity.entity_id ausente.");
    if (!payload.entity?.name) errors.push("entity.name ausente.");
    if (!payload.entity?.document) errors.push("entity.document ausente.");
    if (!payload.entity?.phone) errors.push("entity.phone ausente.");
    if (!payload.entity?.email) errors.push("entity.email ausente.");

    // Higienização para identificar PJ (14 dígitos)
    const cleanDoc = String(payload.entity?.document || "").replace(/\D/g, "");
    const isPJ = cleanDoc.length === 14;

    if (!isPJ) {
      if (!payload.entity?.birth_date) errors.push("entity.birth_date ausente. Obrigatório para PF.");
      if (!payload.entity?.gender) errors.push("entity.gender ausente. Obrigatório para PF.");
    } else {
      // Sanitiza preventivamente os campos PF caso venham nulos na requisição PJ
      if (payload.entity) {
        payload.entity.gender = payload.entity.gender || "";
        payload.entity.birth_date = payload.entity.birth_date || "";
      }
    }
  }

  // 3. Validação de Contexto da Oferta (Leilão/B2B2C)
  const hasOfferContext = !!payload.offer && (source === "offer" || !!payload.offer.offer_id);
  if (hasOfferContext) {
    if (!payload.manager?.manager_name) errors.push("manager.manager_name é obrigatório.");
    if (!payload.seller?.seller_id) errors.push("seller.seller_id é obrigatório.");
    if (!payload.seller?.legal_name) errors.push("seller.legal_name é obrigatório.");
    if (!payload.seller?.trade_name) errors.push("seller.trade_name é obrigatório.");
    if (!payload.seller?.economic_group) errors.push("seller.economic_group é obrigatório.");
    if (!payload.event?.event_id) errors.push("event.event_id é obrigatório.");
    if (!payload.event?.event_description) errors.push("event.event_description é obrigatório.");
    if (!payload.event?.event_start_date) errors.push("event.event_start_date é obrigatório.");
    if (!payload.event?.event_end_date) errors.push("event.event_end_date é obrigatório.");
    if (!payload.offer?.offer_id) errors.push("offer.offer_id é obrigatório.");
    if (!payload.offer?.offer_description) errors.push("offer.offer_description é obrigatório.");
    if (!payload.offer?.offer_value) errors.push("offer.offer_value é obrigatório.");

    // Resolução Semântica de Categoria
    if (payload.offer?.category) {
      debugLog("ValidatePayload categoria recebida:", payload.offer?.category);
      const { data: catData } = await supabaseClient
        .from("category_types")
        .select("id, product_id")
        .ilike("name", `%${payload.offer.category}%`)
        .single();

      if (!catData) {
        errors.push(`Categoria '${payload.offer.category}' não mapeada.`);
      } else {
        found_category_id = catData.id;
        payload.offer!.category_id = catData.id;
        if (!payload.product_id && catData.product_id) {
          found_product_id = catData.product_id;
          payload.product_id = catData.product_id;
        }
      }
    }
  }

  // 4. Validação Cross-Channel
  if (["banner", "whatsapp", "email", "sms"].includes(source || "") && !found_product_id) {
    errors.push(`Para o canal '${source}', o 'product_id' é obrigatório.`);
  }

  if (errors.length > 0) throw new Error(`[sbX Validation Error]: ${errors.join(" | ")}`);
  return { category_id: found_category_id, product_id: found_product_id, action };
}

/**
 * @function resolveDestination
 * @description O Motor de Roteamento. Define a URL final e o parceiro responsável.
 * Opera via "Filtro de Prioridade (Cascata)": Produto > Evento > Seller > Categoria.
 */
async function resolveDestination(
  supabaseClient: any,
  action: "VISIT" | "CONSULT" | "REDIRECT" | "SIMULATE" | "CONTACT",
  payloadTargetUrl?: string,
  eventId?: string | number,
  sellerId?: string | number,
  categoryId?: number,
  productId?: number,
  entityType?: "F" | "J" | string,
) {
  debugLog(`RESOLVE DESTINATION: Ação ${action}. category: ${categoryId} | product_id: ${productId}`);

  if (["VISIT", "REDIRECT", "CONTACT"].includes(action)) {
    throw new Error(`Ação '${action}' não deve passar pelo motor de resolução de destinos.`);
  }

  const currentProfile = entityType === "J" ? "PJ" : "PF";

  const priorities = [
    { type: "EVENT", id: eventId ? Number(eventId) : undefined },
    { type: "SELLER", id: sellerId ? Number(sellerId) : undefined },
    { type: "PRODUCT", id: productId ? Number(productId) : undefined },
    { type: "CATEGORY", id: categoryId ? Number(categoryId) : undefined },
  ];

  for (const priority of priorities) {
    if (priority.id && !isNaN(priority.id)) {
      debugLog(`Tentando query: ${priority.type} com ID: ${priority.id} para Perfil: ${entityType}`);
      const { data, error } = await supabaseClient
        .from("orchestrator_configs")
        .select("id, page_url, partner_id, is_integrated, integration_method, integration_details, entity_type, rules, consent_configs, page_configs, page_faqs")
        .eq("lookup_id", priority.id)
        .eq("config_type", priority.type)
        .eq("is_active", true)
        .in("entity_type", [currentProfile, "PF+PJ"])
        .maybeSingle();

      if (error) {
        debugLog(`[ROTEAMENTO AVISO] Erro na query de ${priority.type}:`, error.message);
        continue;
      }

      if (!data) continue;

      debugLog(`[ROTEAMENTO SUCESSO] Match cravado via ${priority.type} -> `, data);
      return {
        orchestrator_config_id: data.id,
        url: data.page_url,
        partner_id: data.partner_id,
        is_integrated: data.is_integrated,
        integration_method: data.integration_method,
        integration_details: data.integration_details,
        rules: data.rules,
        consent_configs: data.consent_configs,
        page_configs: data.page_configs,
        page_faqs: data.page_faqs,
      };
    }
  }

  throw new Error("Nenhuma configuração de destino ativa encontrada para esta simulação.");
}

/**
 * @function resolveOrchestratorConfigs
 * @description Réplica da lógica de roteamento focada na extração das Regras (Rules/JSONB).
 * Necessária durante a fase de Hidratação (GET) para alimentar os componentes React.
 */
async function resolveOrchestratorConfigs(
  supabase: any,
  eventId?: any,
  sellerId?: any,
  categoryId?: any,
  productId?: any,
  entityType?: "F" | "J" | string, // 👈 Aceita "F", "J" ou qualquer string genérica / undefined
) {
  const currentProfile = entityType === "J" ? "PJ" : "PF";

  const priorities = [
    { type: "EVENT", id: eventId },
    { type: "SELLER", id: sellerId },
    { type: "PRODUCT", id: productId },
    { type: "CATEGORY", id: categoryId },
  ];

  for (const priority of priorities) {
    if (priority.id && priority.id !== "undefined") {
      const { data, error } = await supabase
        .from("orchestrator_configs")
        .select("partner_id, rules, consent_configs, page_configs, page_faqs, is_integrated, integration_method, integration_details")
        .eq("lookup_id", Number(priority.id))
        .eq("config_type", priority.type)
        .eq("is_active", true)
        .in("entity_type", [currentProfile, "PF+PJ"])
        .maybeSingle();

      if (error) continue;
      if (data) return data;
    }
  }
  return null;
}


/**
 * ============================================================================
 * HANDLER PRINCIPAL (E/S BILATERAL)
 * ============================================================================
 */
serve(withSecurity('orchestrator', async (req: Request) => {

  // Salva a origem logo no milissegundo zero para casos de erro no codigo não tratados
  const globalFallbackUrl = req.headers.get("x-original-url") || "/";

  try  {

    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, {
      auth: { persistSession: false },
    });

    // Descoberta da Origem e URL para falha de autenticação
    const originPath = req.headers.get("x-original-url") || "/";
    const authPath = req.headers.get("x-auth-fallback-url") || "/";
    
    // =========================================================================
    // SEGURANÇA: Validação de Identidade pelo token opaco próprio
    // Como o GET e o POST exigem autenticação, validamos aqui no início.
    // =========================================================================
    let auth;
    try {
        auth = await validateRequest(req);
    } catch (err: any) {

        if (!originPath) {
            // Failsafe: Se o frontend não enviou o header, barramos aqui.
            return {
              status: 400,
              data: { 
                success: false,
                code: "INTERNAL_ERROR",
                message: "Erro de segurança: A origem da requisição não foi identificada.",
                fallback_url: "/"
              }
            };
        }

        // 2. Padronização de Variáveis
        let userMessage = "Falha de autenticação. Por favor, faça login novamente.";
        let errorCode = "UNAUTHORIZED";
        let fallbackUrl = authPath;
        let statusCode = 401;

        // 3. Tradução do Erro para Experiência do Usuário (UX)
        if (err.message.includes("SESSION_EXPIRED")) {
            userMessage = "Sua sessão expirou. Por favor, faça login novamente.";
            errorCode = "SESSION_EXPIRED";
            
        } else if (err.message.includes("FORBIDDEN")) {
            userMessage = "Você não tem permissão para acessar este recurso.";
            errorCode = "FORBIDDEN";
            fallbackUrl = originPath; // Apenas devolve para a página atual, não pede login
            statusCode = 403;
            
        } else if (err.message.includes("INTERNAL_ERROR")) {
            userMessage = "Ocorreu um erro interno ao validar sua sessão.";
            errorCode = "INTERNAL_ERROR";
            fallbackUrl = originPath; // Devolve para a home em caso de falha de banco/infra
            statusCode = 500;
        }

        // 4. Retorno seguindo o contrato oficial da API
        return { 
          status: statusCode,
          data: { 
            success: false,
            code: errorCode,
            message: userMessage, 
            fallback_url: fallbackUrl 
          }
        };
    }

    // =========================================================================
    // PIPELINE DE LEITURA (GET): Hidratação do Front-End
    // =========================================================================
    if (req.method === "GET") {
      try {
        const url = new URL(req.url);
        const visitId = url.searchParams.get("visit_id");
        const visitUpdateId = url.searchParams.get("visit_update_id");
        const simulationId = url.searchParams.get("simulation_id");

        if (!visitId) throw new Error("O parâmetro 'visit_id' é obrigatório.");

        // A: Busca de Simulação Prévia com Validação de Identidade (Ownership)
        let simulationData = null;
        if (simulationId) {
          const { data: sim, error: simError } = await supabase
            .from("simulations")
            .select("*")
            .eq("id", simulationId)
            .eq("visit_id", visitId)
            .eq("entity_id", auth.user_id) 
            .single();

          // Se não encontrar ou erro de banco:
          if (simError || !sim) {
            debugLog(`🚨 [Security] Tentativa de acesso não autorizada: ${simulationId}`);
            
            // Cria o erro seguindo o seu padrão de injetar propriedades
            const err = new Error("Você não tem permissão para simular nesta oferta.");
            (err as any).errorCode = "INVALID_RELATIONSHIP"; 
            (err as any).fallback_url = originPath; // Garante que volta para a origem
            
            throw err; // Lança para o catch, que já tratará o errorCode e a mensagem
          }

          simulationData = sim;
        }

        // B: DEEP JOIN - Extração do Snapshot Completo da Visita
        const { data: visit, error: visitError } = await supabase
          .from("visits")
          .select(`
            id, product_id, partner_id, utm_source, utm_medium, utm_campaign, origin_url, target_url,
            visit_entities ( entity_id, entity_type, name, document, phone, email, birth_date, gender, entity_details ),
            visit_offers ( offer_id, offer_value, manager_details, seller_details, event_details, offer_details, category_id )
          `)
          .eq("id", visitId)
          .single();

        debugLog("VISIT no GET:", visit);

        if (visitError || !visit) throw new Error("Visita não encontrada ou expirada.");

        // =====================================================================
        // C: VALIDAÇÃO DE JORNADA (GATEKEEPER)
        // O Gatekeeper unificado valida a propriedade da Visita e o Upstream da Oferta
        // =====================================================================
        const visitEntityData = visit.visit_entities?.[0] || {};
        const visitOfferData = visit.visit_offers?.[0] || {};
        
        const requestContext = {
            entity_id: visitEntityData.entity_id,
            offer_id: visitOfferData.offer_id
        };

        try {
            debugLog("🚨 [GET] Validando integridade da jornada (Visita + Oferta)...");
            const validatedOffer = await validateVisitAndOfferIntegrity(
                supabase, 
                auth, 
                visitId, 
                requestContext
            );
            
            // Se houver oferta e ela for validada na sbX, hidratamos o valor atualizado
            if (validatedOffer) {
                visitOfferData.offer_value = validatedOffer.offer.offer_value;
            }
        } catch (err: any) {
            debugLog("🚨 [Gatekeeper GET] Falha na validação:", err.message);

            let userMessage = "Ocorreu um erro ao carregar a oferta.";
            let errorCode = "UNKNOWN_ERROR";
            let targetFallback = visit?.origin_url || "/";

            if (err.message.includes("OFFER_NOT_FOUND")) {
                userMessage = "Esta oferta não está mais disponível ou não foi encontrada.";
                errorCode = "OFFER_NOT_FOUND";
            } else if (err.message.includes("INVALID_RELATIONSHIP")) {
                userMessage = "Você não tem permissão para acessar esta oferta ou visita.";
                errorCode = "INVALID_RELATIONSHIP";
            } else if (err.message.includes("SESSION_EXPIRED")) {
                userMessage = "Sua sessão expirou. Por favor, faça login novamente.";
                errorCode = "SESSION_EXPIRED";
                targetFallback = authPath; 
            } else if (err.message.includes("UPSTREAM_CONNECTION_ERROR")) {
                userMessage = "Estamos com instabilidade no serviço de ofertas. Tente novamente em instantes.";
                errorCode = "UPSTREAM_CONNECTION_ERROR";
            } else if (err.message.includes("FORBIDDEN") || err.message.includes("INVALID_PAYLOAD")) {
                userMessage = "Inconsistência nos dados de segurança (Bloqueio).";
                errorCode = "FORBIDDEN";
            }

            debugLog("fallback_url: ", targetFallback)

            const errorForUI = new Error(userMessage);
            (errorForUI as any).errorCode = errorCode; 
            (errorForUI as any).fallback_url = targetFallback; 
            
            throw errorForUI; 
        }

        // D: Resolução de Regras e Parâmetros (Cascata Inversa)
        const orchestratorConfigs = await resolveOrchestratorConfigs(
          supabase,
          visitOfferData.event_details?.event_id, 
          visitOfferData.seller_details?.seller_id, 
          visitOfferData.category_id, 
          visit.product_id, 
          visitEntityData.entity_type,
        );
        
        if (!orchestratorConfigs) {
          throw new Error(`[resolveOrchestratorConfigs]: Configurações não localizadas para o perfil e contexto informados.`);
        }

        // E: Construção do Payload Hidratado (Pronto para o React consumir)
        const hydratedPayload = {
          visit_id: visit.id,
          visit_update_id: visitUpdateId,
          simulation_id: simulationId || null,
          product_id: visit.product_id,
          partner_id: orchestratorConfigs.partner_id,
          origin_url: visit.origin_url,
          interaction_context: {
            utm_source: visit.utm_source,
            utm_medium: visit.utm_medium,
            utm_campaign: visit.utm_campaign,
            origin_url: visit.origin_url,
          },
          target_url: visit.target_url,
          entity: visitEntityData.entity_details || {},
          manager: visitOfferData.manager_details || {},
          seller: visitOfferData.seller_details || {},
          event: visitOfferData.event_details || {},
          offer: visitOfferData.offer_details || {},
          rules: orchestratorConfigs?.rules,
          consent_configs: orchestratorConfigs?.consent_configs,
          page_configs: orchestratorConfigs?.page_configs,
          page_faqs: orchestratorConfigs?.page_faqs,
          is_integrated: orchestratorConfigs?.is_integrated,
          integration_method: orchestratorConfigs?.integration_method,
          integration_details: orchestratorConfigs?.integration_details,
          simulation_details: simulationData?.simulation_details || {
            requested_value: visitOfferData.offer_details?.offer_value ? parseFloat(visitOfferData.offer_details.offer_value) : null,
            installments: null,
            down_payment_percentage: orchestratorConfigs?.simulation_rules?.min_down_payment_percentage ?? null, 
            down_payment_amount: visitOfferData.offer_details?.offer_value && orchestratorConfigs?.simulation_rules?.min_down_payment_percentage
                ? parseFloat(visitOfferData.offer_details.offer_value) * (orchestratorConfigs?.simulation_rules?.min_down_payment_percentage / 100)
                : null,
          },
        };

        return { status: 200, data: hydratedPayload };

      } catch (error: any) {
          debugLog(`[Orquestrador GET Error]: ${error.message}`);
          
          // Extraímos o código que injetamos lá no bloco de validação. 
          // Se não existir, é um erro genérico.
          const errorCode = error.errorCode || "UNKNOWN_ERROR";
          debugLog("fallback url:", error.fallback_url);

          return {
              status: 400,
              data: { 
                  success: false,
                  code: errorCode,           // <--- Agora o front-end recebe isso!
                  message: error.message,      // <--- A mensagem amigável
                  fallback_url: error.fallback_url || "/" 
              }
          };
      }
    }

    // =========================================================================
    // PIPELINE DE ESCRITA (POST): Orquestração do Clique
    // =========================================================================
    if (req.method === "POST") {
      try {
        const payload: OrchestratorPayload = await req.json();

        // A: Captura de Contexto Nativo (Device/Geo)
        const infra = await captureInfrastructure(req);
        
        // B: Gatekeeper de Dados (Formatação e Regras Estruturais)
        const { category_id, product_id, action } = await validatePayload(supabase, payload);

        // =====================================================================
        // C: GATEKEEPER DE SEGURANÇA E NEGÓCIO (Zero-Trust)
        // Obrigatório executar ANTES de qualquer inserção/alteração no banco.
        // =====================================================================
        const targetVisitId = payload.visit_id || null;
        const targetEntityId = payload.entity?.entity_id || null;
        const targetOfferId = payload.offer?.offer_id || null;
        
        const requestContext = {
            entity_id: targetEntityId,
            offer_id: targetOfferId
        };

        try {
            debugLog("🚨 [Gateway POST] Validando ownership da visita e integridade da oferta...");
            await validateVisitAndOfferIntegrity(
                supabase, 
                auth, 
                targetVisitId, 
                requestContext
            );
            debugLog("✅ Jornada validada com sucesso pelo Gatekeeper.");
        } catch (err: any) {
            debugLog("🚨 [Gatekeeper POST] Falha na validação:", err.message);

            let userMessage = "Ocorreu um erro ao processar sua requisição.";
            let errorCode = "UNKNOWN_ERROR";
            let targetFallback = originPath; // Default para erros de negócio é voltar para a origem

            if (err.message.includes("OFFER_NOT_FOUND")) {
                userMessage = "Esta oferta não está mais disponível ou não foi encontrada.";
                errorCode = "OFFER_NOT_FOUND";
            } else if (err.message.includes("INVALID_RELATIONSHIP")) {
                userMessage = "Você não tem permissão para acessar esta oferta ou visita.";
                errorCode = "INVALID_RELATIONSHIP";
            } else if (err.message.includes("SESSION_EXPIRED")) {
                userMessage = "Sua sessão expirou. Por favor, faça login novamente.";
                errorCode = "SESSION_EXPIRED";
                targetFallback = authPath; // Direciona para o login
            } else if (err.message.includes("UPSTREAM_CONNECTION_ERROR")) {
                userMessage = "Estamos com instabilidade no serviço de ofertas. Tente novamente em instantes.";
                errorCode = "UPSTREAM_CONNECTION_ERROR";
            } else if (err.message.includes("FORBIDDEN") || err.message.includes("INVALID_PAYLOAD")) {
                userMessage = "Inconsistência nos dados de segurança (Bloqueio).";
                errorCode = "FORBIDDEN";
            }

            const errorForUI = new Error(userMessage);
            (errorForUI as any).errorCode = errorCode; 
            (errorForUI as any).fallback_url = targetFallback; 
            
            throw errorForUI; 
        }

        // =====================================================================
        // D: Motor de Decisão (Onde o usuário vai pousar?)
        // =====================================================================
        let orchestratorConfigId = null;

        if (["VISIT", "REDIRECT", "CONTACT"].includes(action)) {
          if (!payload.target_url) {
            throw new Error(`Para ações de '${action}', a target_url é obrigatória no payload.`);
          }
          // Para navegação direta, o payload já tem a URL e o partner_id.
        } else {
          // Se for simulação ou consulta, busca no banco e já injeta no payload
          const resolved = await resolveDestination(
            supabase,
            action,
            payload.target_url,
            payload.event?.event_id,
            payload.seller?.seller_id,
            category_id,
            product_id,
            payload.entity?.entity_type, 
          );

          payload.target_url = resolved.url; 
          if (resolved.is_integrated !== undefined) payload.is_integrated = resolved.is_integrated; 
          if (resolved.integration_method !== undefined) payload.integration_method = resolved.integration_method;
          if (resolved.integration_details !== undefined) payload.integration_details = resolved.integration_details;
          if (resolved.partner_id !== undefined && resolved.partner_id !== null) {
            payload.partner_id = resolved.partner_id;
          }

          // Hidrata o payload ativo para a "foto" ir completa para o banco
          payload.rules = resolved.rules;
          payload.consent_configs = resolved.consent_configs;
          payload.page_configs = resolved.page_configs;
          payload.page_faqs = resolved.page_faqs;

          orchestratorConfigId = resolved.orchestrator_config_id;
        }

        debugLog("Origem: ", payload.origin_url);

        // =====================================================================
        // E: Persistência Segura (One-Shot Database Insertion)
        // Agora protegido pelo Gatekeeper na etapa C.
        // =====================================================================
        const { visitId, visitUpdateId } = await persistVisitData(
          sql,
          payload,
          infra,
          category_id,
          payload.action,
          payload.origin_url,
          payload.target_url,
          payload.visit_id,
          orchestratorConfigId,
        );

        // G: Montagem do Payload de Retorno (Command: REDIRECT)
        const simulationId = payload.simulation_id || null;
        let finalUrl = `${payload.target_url}?visit_id=${visitId}&visit_update_id=${visitUpdateId}`;
        if (simulationId) finalUrl += `&simulation_id=${simulationId}`;

        debugLog("[POST] payload final de retorno:", { payload, visitId, visitUpdateId, simulationId });

        return {
          status: 200,
          data: {
            action: "REDIRECT",
            url: finalUrl,
            visit_id: visitId,
            visit_update_id: visitUpdateId,
            simulation_id: simulationId, 
            partner_id: payload.partner_id,
          }
        };

      } catch (error: any) {
        debugLog(`[Orquestrador POST Error REAL]: ${error.message}`);
        
        const errorCode = error.errorCode || "UNKNOWN_ERROR";

        return {
          status: 400,
          data: { 
              success: false,
              code: errorCode,              // <--- Agora o front-end recebe isso!
              message: error.message,       // <--- A mensagem amigável
              fallback_url: error.fallback_url || originPath 
          }
        };
      }
    }

    // Falha de Método HTTP
    return { 
      status: 405, 
      data: { error: "Método HTTP não permitido." } 
    };
  } catch (fatalError: any) {
    // O FAILSAFE ABSOLUTO
    // Se qualquer coisa quebrar (syntax error, banco fora do ar, null pointer),
    // cai aqui ANTES de vazar para o withSecurity.
    
    debugLog(`🚨 [CRASH FATAL INTERCEPTADO]: ${fatalError.message}`);
    
    return {
        status: 500,
        data: {
            success: false,
            code: "INTERNAL_SERVER_ERROR",
            message: "Ocorreu um erro interno inesperado. Tente novamente.",
            fallback_url: globalFallbackUrl // Faz jornada voltar para a origem
        }
    };
  }
}));