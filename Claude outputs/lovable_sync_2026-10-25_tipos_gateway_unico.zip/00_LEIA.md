# Tipagem gateway + orchestrator (2026-10-25) — pacote único

Substitui tipos_gateway e tipos_gateway2 (não aplicar esses dois).
Aplicar depois do tipos_flowcredi.

Só tipos, sem mudança de comportamento. Zera os erros de tipo e tira os `any` do
financial-gateway e do orchestrator, exceto os 12 da conexão com o banco (sql/t do postgres).

## Lovable: prompts na ordem
01 _shared/types.ts
02 _shared/hydrate-data.ts
03 _shared/gatekeeper.ts
04 orchestrator/index.ts
05 orchestrator/persist-data.ts
06 financial-gateway/index.ts
07 financial-gateway/simulation-handler.ts
08 financial-gateway/persist-data.ts
09 financial-gateway/fandi-service.ts
10 financial-gateway/partner-service.ts
11 financial-gateway/credit-card-service.ts
12 financial-gateway/email-offer-button.ts
13 financial-gateway/partner-notifications.ts
14 financial-gateway/fandi-notifications.ts

## Deploy
financial-gateway e orchestrator (homol).

Sem migration.
