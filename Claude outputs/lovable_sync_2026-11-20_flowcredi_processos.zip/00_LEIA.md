# FlowCredi: API de Processos, termos oficiais e webhook (2026-11-20)

Atualização da integração com a FlowCredi conforme as respostas deles (PDF "respostas_superbid"):
a API antiga de leads (Preamble) foi descontinuada e o envio passa para a API de Processos.

ATENÇÃO: os pacotes B, C e D (simulador, termos, telas do Car Equity e webhook) ainda NÃO foram
testados em dev. Só o envio pela API de Processos (Imóveis) foi testado em dev, com sucesso.

## O que muda

Envio (API de Processos, `POST /processos`)
- Imóveis (FINANCIAMENTO), Home Equity (CGI) e Car Equity (CGA) criam um processo na FlowCredi.
  O `processoId` fica em `simulations.external_operation_id`. O envio deixa de ser simulado:
  antes nenhum lead saía (FLOWCREDI_SEND_LEAD = false).
- Ambiente por configuração: `orchestrator_configs.integration_details.partner_environment`
  ("staging" ou "production"; ausente = production). Nada fixo no código.
- Aceites registrados na API de Termos com IP e user-agent do cliente e a versão do texto exibido.

Simulador
- Sem `idSeguradora` (orientação da FlowCredi); card com a condição Balcão; parcela exibida =
  parcela cheia da tabela (MIP, DFI e tarifa); nova tentativa automática em 429.
- Imóveis: financiado mín. R$ 10 mil, prazo 36–420, LTV 90%; salas 70%/120 e terrenos 70%/240
  (por subcategoria); sem renda mínima fixa.
- Home Equity: 60% (casa/apto), 40% (sala/loja), 30% (terreno) menos o saldo devedor; Galpão e
  Rural bloqueados; prazo 12–240 (padrão 120); imóvel mín. R$ 50 mil, crédito mín. R$ 10 mil.

Telas
- Termos: os links abrem o texto oficial da FlowCredi num modal (arquivo novo `flowTerms.tsx`).
- Car Equity: saem Portas e Tempo na ocupação; entram Restrição no SPC/Serasa e Banco do
  financiamento (veículo não quitado); prazo até 70 meses. Endereço continua vindo do cadastro.

Webhook
- Nova rota `financial-gateway-webhook/flowcredi`: recebe o aviso `bank.status_changed`, só aceita
  processos nossos, confirma o status na Process Bank API com o nosso token e grava a mudança.
  Ignora eventos repetidos; até 30 consultas por processo por hora. Sem secret nova.

## Lovable: prompts (na ordem)
01–06 Edge Function `financial-gateway` (6 arquivos)
07–08 Edge Function `financial-gateway-webhook` (07 é arquivo novo)
09–18 Telas (11 `flowTerms.tsx` é arquivo novo)
19 SQL de configuração (só dados em `orchestrator_configs`; sem tabela/coluna nova)
20 `config.toml`: webhook sem verificação de JWT + deploy das duas funções

Sem migration. Sem secret nova.

## Antes de testar em homol (manual)
- Secret `FLOWCREDI_API_KEY` do homol: o VALOR precisa ser o token de **Staging** do Portal
  Parceiro (parceiro.flowcredi.com.br > Documentação > Tokens). Mesmo nome, só o valor muda.
- Assinatura do webhook de homol na FlowCredi (Portal > Referência OpenAPI > Partner Webhook
  Dispatcher > `POST /subscriptions`), com a URL da função de homol:
  `https://<projeto de homol>.supabase.co/functions/v1/financial-gateway-webhook/flowcredi`,
  `eventTypes: ["bank.status_changed"]` e um `secret` aleatório (mín. 16 caracteres; não é guardado).

## Teste em homol
1. Imóveis: simular > escolher condição > Seus dados > abrir os 3 links (texto oficial com versão) >
   aceitar > Enviar proposta. Esperado: "Lead · Enviado" e o processo em Portal Parceiro > Propostas.
2. Home Equity: mesmo fluxo (testar também Sala Comercial: limite 40%; Galpão: bloqueado).
3. Car Equity: sem Portas e Tempo na ocupação; com SPC e Banco do financiamento (se não quitado).

## Observações
- Tipos: rodar `npx tsc --noEmit` antes de aplicar (ainda não confirmado para as telas deste zip).
- Imóveis: o slider ainda permite 90% para salas e terrenos; acima de 70% o servidor recusa com
  mensagem.
- Produção: trocar `partner_environment` para "production", o `terms_url` para
  `https://api.flowcredi.com.br/terms-service/v1/terms` e usar o token de Produção.
