No arquivo `supabase/config.toml`, verifique se existe o bloco `[functions.financial-gateway-webhook]`.

- Se NÃO existir, adicione ao final do arquivo, sem alterar mais nada:

```
[functions.financial-gateway-webhook]
verify_jwt = false
```

- Se já existir com `verify_jwt = false`, não altere nada.

Motivo: a FlowCredi (e a FANDI) chamam esse webhook de fora, sem o token do Supabase. A segurança fica no código de cada rota (a da FlowCredi só aceita processos nossos e confirma tudo na API da FlowCredi).

Depois, faça o deploy das Edge Functions `financial-gateway` e `financial-gateway-webhook`.
