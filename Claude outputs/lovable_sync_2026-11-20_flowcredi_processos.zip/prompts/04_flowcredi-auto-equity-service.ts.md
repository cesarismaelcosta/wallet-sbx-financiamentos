Substitua todo o conteúdo do arquivo `supabase/functions/financial-gateway/flowcredi-auto-equity-service.ts` com exatamente o conteúdo abaixo. Não altere nada além deste arquivo e não rode formatação.

O que muda: Car Equity: processo CGA com endereço/nome da mãe do cadastro, restrição SPC, banco do saldo devedor, prazo até 70.

```
/**
 * FLOWCREDI · CRÉDITO COM GARANTIA DE VEÍCULO (CAR EQUITY / CGA)
 * @path supabase/functions/financial-gateway/flowcredi-auto-equity-service.ts
 *
 * @description Jornada de Car Equity com a FlowCredi (parceiro 3, PRODUCT 7, ativada por
 * `rules.flowcredi_product = "auto_equity"` no orchestrator_configs). A FlowCredi não tem
 * simulador de auto: a jornada tem uma única ação.
 *
 *  LEAD (SUBMIT_LEAD): valida as entradas, confere os aceites e cria o processo CGA (POST /processos).
 *
 * --- ENTRADAS (simulation_details, digitadas pelo cliente) ---
 * vehicle_plate, vehicle_brand, vehicle_model, vehicle_year, vehicle_model_year, vehicle_doors,
 * vehicle_fuel (opcional), vehicle_value, vehicle_state (UF), vehicle_owner (bool), vehicle_paid (bool),
 * outstanding_balance, requested_value, installments, loan_purpose, monthly_income,
 * professional_status, profession, employment_years, customer_zip, customer_address.
 * Nome, CPF, e-mail, telefone e nascimento vêm do cadastro (entity).
 *
 * --- LIMITES ---
 * O swagger só diz que o empréstimo não pode passar do valor do veículo. Usamos o valor do
 * veículo menos o saldo devedor (regra nossa, a confirmar). Parcelas: lista fechada do lead.
 *
 * --- PROCESSO (Process API, produto CGA) ---
 * Raiz: aceites, refId (= simulation_id), valor_credito, valor_garantia (veículo), prazo_meses, finalidade.
 * participantes[PRINCIPAL]: profissao, tipo_renda (lista da API), nome_mae e residência
 * (cep, estado, cidade, logradouro, numero, bairro) do cadastro Superbid; sem cadastro, o
 * CEP e o endereço digitados. dados_garantia: placa, tipo_veiculo "Carro", uf_licenciamento,
 * propriedade_objeto, marca, modelo, anos, veiculo_quitado e saldo_devedor.
 * Restrição SPC/Serasa (Sim/Não) e banco do saldo devedor (veículo financiado) vêm da tela. Prazo até 70 meses.
 */

import { SimulationResponse, SimulationPayload, SimulationFinancials } from "../_shared/types.ts";
import { debugLog } from "../_shared/logger.ts";
import {
  FlowAction, FlowSimRequest, FlowRules, FlowClient,
  businessError, num, resolveFlowAction, birthDateOf, assertPF, assertRequiredConsents,
  flowPrincipal, flowRefId, consentFlags, entityAddress, fmtCep, compact,
  submitProcess, leadConsult, maskProcess,
} from "./flowcredi-service.ts";

const PRODUCT_LABEL = "O crédito com garantia de veículo";

const UFS = ["AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO"];
const TERMS = ["12", "24", "30", "36", "42", "48", "54", "60", "66", "70"]; // CGA: até 70 meses
const PURPOSES = ["Pagamento de dívidas", "Refinanciamento de dívidas", "Reforma de casa", "Aquisição de Bens", "Outros"];
const PROFESSIONAL_STATUS = ["Assalariado/Registrado", "Autônomo", "Profissional Liberal", "Empresário", "Funcionário Público", "Aposentado/Pensionista"];
const PLATE_RE = /^[A-Z]{3}-?\d[A-Z0-9]\d{2}$/;

export function isFlowcrediAutoEquity(rules: FlowRules | null | undefined): boolean {
  return rules?.flowcredi_product === "auto_equity";
}

const money = (v: unknown) => Math.round(num(v) * 100) / 100;
const text = (v: unknown, max: number) => String(v ?? "").trim().replace(/\s+/g, " ").slice(0, max);
const year = (v: unknown) => {
  const y = String(v ?? "").trim();
  const n = Number(y);
  return /^\d{4}$/.test(y) && n >= 1950 && n <= new Date().getFullYear() + 1 ? y : "";
};

/** Situação profissional da tela → lista da API de Processos (TipoRenda). */
const PROCESS_INCOME_TYPE: Record<string, string> = {
  "Assalariado/Registrado": "Assalariado",
  "Funcionário Público": "Assalariado",
  "Autônomo": "Autônomo",
  "Profissional Liberal": "Autônomo",
  "Empresário": "Empresário",
  "Aposentado/Pensionista": "Aposentado",
};

/** Valida as entradas do cliente e monta o corpo de POST /processos (produto CGA). */
export function buildAutoEquityLead(payload: SimulationPayload) {
  const sim: SimulationFinancials = payload.simulation_details || ({} as SimulationFinancials);
  assertPF(payload, PRODUCT_LABEL);
  birthDateOf(payload); // valida o nascimento do cadastro antes das demais entradas

  const placa = String(sim.vehicle_plate ?? "").trim().toUpperCase();
  if (!PLATE_RE.test(placa)) throw businessError("Informe a placa do veículo.");
  const marca = text(sim.vehicle_brand, 60);
  if (marca.length < 2) throw businessError("Informe a marca do veículo.");
  const modelo = text(sim.vehicle_model, 80);
  if (!modelo) throw businessError("Informe o modelo do veículo.");
  const anoVeiculo = year(sim.vehicle_year);
  const anoModelo = year(sim.vehicle_model_year);
  if (!anoVeiculo || !anoModelo) throw businessError("Informe os anos de fabricação e do modelo.");
  const uf = String(sim.vehicle_state ?? "").trim().toUpperCase();
  if (!UFS.includes(uf)) throw businessError("Informe a UF de licenciamento.");

  const valorVeiculo = money(sim.vehicle_value);
  if (!(valorVeiculo > 0)) throw businessError("Informe o valor do veículo.");
  const quitado = sim.vehicle_paid === true;
  const saldoDevedor = quitado ? 0 : money(sim.outstanding_balance);
  if (!(saldoDevedor >= 0)) throw businessError("Informe o saldo devedor do veículo.");
  const maxCredito = Math.floor(valorVeiculo - saldoDevedor);
  if (!(maxCredito > 0)) throw businessError("O saldo devedor não permite crédito com este veículo em garantia.");
  const valorEmprestimo = money(sim.requested_value);
  if (!(valorEmprestimo > 0) || valorEmprestimo > maxCredito) {
    throw businessError(`O valor do crédito deve ficar entre R$ 1 e R$ ${maxCredito.toLocaleString("pt-BR")}.`);
  }
  const parcelas = String(Math.trunc(num(sim.installments)));
  if (!TERMS.includes(parcelas)) throw businessError("Escolha o número de parcelas.");
  const motivo = String(sim.loan_purpose ?? "");
  if (!PURPOSES.includes(motivo)) throw businessError("Escolha o motivo do crédito.");

  const renda = money(sim.monthly_income);
  if (!(renda > 0)) throw businessError("Informe sua renda bruta familiar.");
  const situacao = String(sim.professional_status ?? "");
  if (!PROFESSIONAL_STATUS.includes(situacao)) throw businessError("Informe sua situação profissional.");
  const profissao = text(sim.profession, 80);
  if (profissao.length < 2) throw businessError("Informe sua profissão.");
  if (typeof sim.credit_restriction !== "boolean") throw businessError("Informe se há restrição no SPC/Serasa.");
  const bancoSaldo = quitado ? "" : text(sim.outstanding_bank, 100);
  if (!quitado && bancoSaldo.length < 2) throw businessError("Informe o banco do financiamento do veículo.");

  // Residência: cadastro Superbid; o CEP e o endereço digitados só valem quando o cadastro não tem
  const home = entityAddress(payload);
  const fromProfile = !!(home.cep && home.cidade && home.estado);
  const cep = String(sim.customer_zip ?? "").replace(/\D/g, "");
  const endereco = text(sim.customer_address, 200);
  if (!fromProfile && (cep.length !== 8 || endereco.length < 5)) throw businessError("Informe seu CEP e endereço.");

  const principal = flowPrincipal(payload, PRODUCT_LABEL, renda, {
    profissao: profissao,
    tipo_renda: PROCESS_INCOME_TYPE[situacao] ?? "Outros",
    nome_mae: home.nome_mae,
    // Residência: cadastro Superbid; sem ele, o CEP e o endereço digitados
    cep: fromProfile ? home.cep : fmtCep(cep),
    estado: home.estado,
    cidade: home.cidade,
    logradouro: fromProfile ? home.logradouro : endereco,
    numero: home.numero,
    complemento: home.complemento,
    bairro: home.bairro,
  });

  const lead = {
    ...consentFlags(payload),
    produto: "CGA",
    refId: flowRefId(payload),
    valor_credito: valorEmprestimo,
    valor_garantia: valorVeiculo,
    prazo_meses: Number(parcelas),
    finalidade: motivo,
    restricao_spc_serasa: sim.credit_restriction === true ? "Sim" : "Não",
    participantes: [principal],
    dados_garantia: compact({
      placa_veiculo: placa.replace("-", ""),
      tipo_veiculo: "Carro",
      uf_licenciamento: uf,
      propriedade_objeto: sim.vehicle_owner === true ? "Sim" : "Não",
      marca_veiculo: marca,
      modelo_veiculo: modelo,
      ano_fabricacao: Number(anoVeiculo),
      ano_modelo: Number(anoModelo),
      veiculo_quitado: quitado,
      saldo_devedor: quitado ? null : saldoDevedor,
      banco_saldo_devedor: bancoSaldo,
    }),
  };

  // Para o registro da consulta (mesmo formato dos outros produtos FlowCredi)
  const req = { valorImovel: valorVeiculo, valorFinanciado: valorEmprestimo, prazo: Number(parcelas) } as FlowSimRequest;
  return { lead, req };
}

/** Executa a ação da jornada (só LEAD: não há simulador de auto na FlowCredi). */
export async function processFlowcrediAutoEquity(
  payload: SimulationPayload,
  _rules: FlowRules,
  step: string = "SUBMIT_LEAD",
  client: FlowClient = {},
): Promise<{ action: FlowAction; result: SimulationResponse; persist: boolean }> {
  const action = resolveFlowAction(payload, step);
  if (action !== "LEAD") throw businessError("Ação inválida.");

  assertRequiredConsents(payload);
  const { lead, req } = buildAutoEquityLead(payload);
  debugLog("🚗 [FlowCredi Car Equity] Criando processo (refId):", lead.refId);
  const response = await submitProcess(payload, lead, client);
  return {
    action,
    persist: true,
    result: {
      success: true,
      consults: [leadConsult(req, response.processoId, { withDownPayment: false })],
      raw: { action, process: maskProcess(lead), response },
    },
  };
}
```
