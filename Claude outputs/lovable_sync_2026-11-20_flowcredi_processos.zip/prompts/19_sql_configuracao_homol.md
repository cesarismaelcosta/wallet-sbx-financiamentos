Execute no banco de dados deste projeto o SQL abaixo, exatamente como está (é só dado de configuração em `orchestrator_configs`: não cria tabela nem coluna). No fim, mostre o resultado da consulta de conferência.

```sql
-- FlowCredi · configuração das jornadas (HOMOL · ambiente de staging da FlowCredi)
-- As configs são localizadas pelo conteúdo (rules.flowcredi_product / parceiro), não por id.

-- 1) Ambiente dos parceiros integrados por API
update orchestrator_configs
set integration_details = coalesce(integration_details, '{}'::jsonb) || '{"partner_environment": "staging"}'::jsonb
where rules ? 'flowcredi_product';

update orchestrator_configs
set integration_details = coalesce(integration_details, '{}'::jsonb) || '{"partner_environment": "production"}'::jsonb
where partner_id = 2 and is_integrated = true and integration_method = 'API';

-- 2) Imóveis: limites do simulador da FlowCredi + limites por subcategoria
update orchestrator_configs
set rules = (rules - 'min_monthly_income') || '{
  "max_financing_percentage": 90,
  "min_financed_amount": 10000,
  "min_term_months": 36,
  "max_term_months": 420,
  "subcategory_limits": {
    "10110": {"max_financing_percentage": 90, "max_term_months": 420},
    "10111": {"max_financing_percentage": 90, "max_term_months": 420},
    "10120": {"max_financing_percentage": 70, "max_term_months": 120},
    "11713": {"max_financing_percentage": 70, "max_term_months": 240},
    "*":     {"max_financing_percentage": 70, "max_term_months": 240}
  }
}'::jsonb
where rules->>'flowcredi_product' = 'mortgage';

-- 3) Home Equity: prazo até 240, padrão 120
update orchestrator_configs
set rules = rules || '{"max_term_months": 240, "default_term_months": 120}'::jsonb
where rules->>'flowcredi_product' = 'home_equity';

-- 4) Aceites FlowCredi: id sem versão e link abrindo o texto oficial (GET /terms de staging)
update orchestrator_configs o
set consent_configs = (
  select jsonb_agg(
    case when c ? 'flowcredi_type' then
      (c - 'flowcredi_version')
      || jsonb_build_object('id', regexp_replace(c->>'id', '_v[0-9]+$', ''))
      || jsonb_build_object('links', (
           select coalesce(jsonb_agg(jsonb_build_object(
             'text', l->>'text',
             'type', 'terms',
             'terms_url', 'https://api.staging.flowcredi.com.br/terms-service/v1/terms')), '[]'::jsonb)
           from jsonb_array_elements(coalesce(c->'links', '[]'::jsonb)) l))
    else c end
    order by (c->>'position')::int)
  from jsonb_array_elements(o.consent_configs) c)
where o.rules ? 'flowcredi_product' and jsonb_typeof(o.consent_configs) = 'array';

-- 5) FAQs com números antigos
update orchestrator_configs
set page_faqs = replace(page_faqs::text, 'o financiamento chega a até 80% do valor do imóvel', 'o financiamento chega a até 90% do valor do imóvel')::jsonb
where rules->>'flowcredi_product' = 'mortgage';
update orchestrator_configs
set page_faqs = replace(page_faqs::text, 'e paga em 12 a 60 parcelas', 'e paga em 12 a 70 parcelas')::jsonb
where rules->>'flowcredi_product' = 'auto_equity';

-- Conferência
select id, partner_id, rules->>'flowcredi_product' produto, integration_details->>'partner_environment' ambiente,
       rules->'max_term_months' prazo_max, jsonb_path_query_array(consent_configs, '$[*].id') aceites
from orchestrator_configs
where rules ? 'flowcredi_product' or (partner_id = 2 and is_integrated = true and integration_method = 'API')
order by id;
```
