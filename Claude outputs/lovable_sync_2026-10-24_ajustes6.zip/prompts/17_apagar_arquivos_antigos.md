Apague estes 3 arquivos (foram substituídos pelos de nome novo). Não altere mais nada.

- `src/features/financial-hub/components/products/credit/home-equity/homeEquity.manifest.ts`
- `src/features/financial-hub/components/products/credit/home-equity/homeEquity.types.ts`
- `src/features/financial-hub/components/products/credit/auto-equity/autoEquity.types.ts`
