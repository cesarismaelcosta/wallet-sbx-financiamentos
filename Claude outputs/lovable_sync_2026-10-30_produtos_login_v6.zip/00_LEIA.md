# Página de produtos, login e imagens de Imóveis (2026-10-30)

Aplicar depois do functions_final. Substitui produtos_login e as versões _v2 a _v5 (não aplicar esses).

## Lovable: prompts na ordem
01 src/routes/produtos.index.lazy.tsx ... revisão de conteúdo da home de produtos
   (textos das seções, botões "Ver ..." nos que levam a ofertas, Segurança em cards,
   fontes dos detalhes um pouco maiores, Imóveis "EM ATÉ 420 MESES" / "até 35 anos")
02 src/routes/accounts.signin.lazy.tsx ... botão "Entrar" no padrão CTA do design system (cta-gradient)
03 src/routes/sandbox.lazy.tsx ... botão "Entrar" no padrão CTA + Imóveis "Financiar em até 420x"
04 supabase/functions/financial-gateway/flowcredi-home-equity-service.ts ... Home Equity: prazo máximo padrão 120 meses

## Imagens (enviar os arquivos ao Lovable, substituindo os atuais em public/assets/home/)
arquivos/public/assets/home/
  financiamentoimoveis.webp
  financiamentoimoveis-960.webp
  financiamentoimoveis-240.webp
  financiamentoimoveis-dark.webp
  financiamentoimoveis-dark-960.webp
  financiamentoimoveis-dark-240.webp
Novo selo "até 420x" (clara: texto branco no selo azul-marinho; escura: selo azul-claro).

## Configuração (rodar no SQL do Supabase de homol)
Home Equity com prazo máximo de 120 meses (e 120 já selecionado na simulação):

    update orchestrator_configs
    set rules = rules || '{"max_term_months": 120, "default_term_months": 120}'::jsonb
    where id = 7;

(confirmar antes que o id 7 em homol é o Home Equity: rules->>'flowcredi_product' = 'home_equity')

## Deploy
financial-gateway (homol). Sem migration de schema.
