# Entrada da Superbid pela rota /gate do app (2026-11-13)

A Superbid passa a postar o formulário do botão "Simular financiamento" em `<app>/gate`, e não mais no
Supabase. A rota repassa ao `financial-gateway-gate`, então o endereço do Supabase não aparece para o
parceiro nem na barra de endereço. O gate direto continua funcionando para o Sandbox e para as chamadas AJAX.

O que muda:
- `src/routes/gate.ts` (novo): rota de servidor do TanStack Start, só POST. Repassa o formulário, o
  `User-Agent` (obrigatório para o `#xt`) e o IP real do usuário assinado com `GATE_PROXY_SECRET`;
  devolve o redirecionamento do gate e leva o erro (`/financialGatewayGate`) para o domínio do app.
- `financial-gateway-gate/index.ts`: sai o `FRONTEND_URL` (a tela de erro usa só o `return_uri`
  filtrado pela allowlist); passa a aceitar o IP assinado pela rota `/gate`.
- `_shared/client-ip.ts`: nova verificação `verifyProxySignedClientIp` (chave `GATE_PROXY_SECRET`).
- Sandbox: seletor "Entrada dos formulários: Supabase direto / Via /gate" abaixo de
  "Parcelamentos e Financiamentos nas Ofertas" (padrão: Via /gate). Vale para os botões Form e Nova Aba.

## Lovable: prompts (na ordem)
01 _shared/client-ip.ts
02 financial-gateway-gate/index.ts
03 src/routes/gate.ts (arquivo novo)
04 src/routes/sandbox.lazy.tsx
05 Deploy do financial-gateway-gate

Não precisa de secret nenhum. O código aceita um IP assinado (GATE_PROXY_SECRET), mas sem essa
chave tudo funciona; só o IP gravado na visita fica o do servidor do app.

Sem migration. O secret `FRONTEND_URL` deixa de ser usado.

## Teste em homol
No Sandbox (logado no Lovable), em "Parcelamentos e Financiamentos nas Ofertas", deixe "Via /gate"
e clique em "(Nova Aba)" numa oferta aberta: a aba passa por `/gate` e abre a jornada.
"simular erro" (Form) deve cair na tela de erro do app.

O preview é privado no Lovable: um POST vindo da própria Superbid para o preview pode ser barrado
pelo login do Lovable. O teste com a Superbid vale em dev ou num domínio publicado.

## Atenção
Os tipos destes arquivos ainda não foram verificados (sem acesso ao npm/deno na sessão).
Antes de aplicar, rode em dev: `npx tsc --noEmit` e
`deno check supabase/functions/financial-gateway-gate/index.ts`.
