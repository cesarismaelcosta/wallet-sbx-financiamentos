# Ajustes depois do ponto de controle 2 (2026-10-21)

1. Cole no Lovable, na ordem:
   - prompts/01_backoffice.simulations.lazy.tsx.md  (etapa na coluna Situação)
   - prompts/02_persist-data.ts.md                  (aceites gravados também no envio do lead)
2. Deploy: financial-gateway
Sem migration.
