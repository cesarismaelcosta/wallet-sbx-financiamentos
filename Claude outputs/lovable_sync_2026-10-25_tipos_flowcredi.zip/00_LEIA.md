# Tipagem FlowCredi (2026-10-25)

Aplicar depois do balcao, layout e simular_novamente.

Só tipos: remove os 43 `any` dos 5 arquivos da FlowCredi. Sem mudança de comportamento.
Não mexe em `_shared/types.ts`.

## Lovable: prompts na ordem
01 flowcredi-service.ts ... novos tipos (FlowRules, FlowConsultation, FlowConditionDetails, FlowLeadResponse, FlowNotification)
02 flowcredi-mortgage-service.ts
03 flowcredi-home-equity-service.ts
04 flowcredi-auto-equity-service.ts
05 flowcredi-notifications.ts

## Deploy
financial-gateway (homol).

Sem migration.
