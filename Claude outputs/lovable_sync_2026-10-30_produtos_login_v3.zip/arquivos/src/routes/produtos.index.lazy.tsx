/**
 * @fileoverview 🏠 Componente: ProdutosHome (Rota: /produtos/)
 * @path src/routes/produtos/index.tsx
 * @description Ponto de entrada principal do ambiente de homologação e testes do Financial Hub.
 * Gerencia a listagem de jornadas de produtos, o roteamento inteligente e a pureza visual neutra (SBX DS).
 *
 * ============================================================================
 * 🤖 PADRÃO GEMINI PRO ARQUITETURA: ZERO-TRUST NAVIGATION & NEUTRAL PURITY
 * ============================================================================
 * Este componente atua como um despachante de intenções "cego" para o Orquestrador.
 * Ele não calcula destinos, não trafega dados pessoais e não toma decisões de negócio.
 *
 * [MECÂNICA ARQUITETURAL V4 - BLINDAGEM NEUTRA & TIPOGRAFIA EDITORIAL SERIF]:
 * 1. {Thin Payload / Zero-Trust}: O Front-end não consome nem envia o perfil do
 *    usuário (PII) nos requests de navegação (`CONSULT` ou `VISIT`). O payload envia
 *    apenas a "intenção" (ex: Clicou no Produto X). A identificação do usuário é
 *    feita com exclusividade pelo Backend (Edge) lendo o JWT.
 * 2. {Telemetria Contínua (OLAP)}: Ao disparar um clique, o componente extrai ativamente
 *    o cursor atual (`visit_update_id`) da URL e o repassa ao Orquestrador. Isso diz ao
 *    backend exatamente de onde o usuário está saindo, permitindo o fechamento perfeito
 *    do funil de conversão antes da geração da próxima página.
 * 3. {Roteamento Determinístico}: O componente nunca faz "hard redirect" por conta própria
 *    para jornadas do ecossistema. Ele envia o POST e aguarda o Orquestrador devolver a
 *    URL assinada oficial.
 * 4. {Zero-Latency Fast Path}: Ao receber a resposta positiva do Orquestrador, o componente
 *    intercepta o pacote `state` e o injeta na memória RAM (Cofre) antes de executar o
 *    `navigate`. Isso permite que a próxima tela (ex: Formulário de Seguros) abra em 0ms,
 *    poupando um request GET redundante na inicialização.
 * 5. {Neutral Purity & Serif Focus Governance}: Aplicação rigorosa de tons institucionais
 *    monocromáticos (`neutral-900`, `neutral-50`, `border-neutral-200`) e introdução
 *    da tipografia editorial em destaque (`serif`) alinhada ao design system oficial da SBX.
 *
 * @author César Ismael Pereira da Costa
 * @author Gemini Pro (Architectural Mechanics)
 */

import React, { useState, useEffect, useContext, useRef } from "react";
import { createLazyFileRoute, useNavigate } from "@tanstack/react-router";
import {
  Loader2,
  Plus,
  UserPlus,
  ArrowRight,
  TriangleAlert,
} from "lucide-react";
import { WalletLogo } from "@/components/brand/WalletLogo";
import { useTheme } from "@/design-system/sbx-design-system-9f1c03/components/ThemeProvider";
import { PanelHeader, HeaderLink } from "@/features/financial-hub/components/layout/PanelHeader";
import { useFinancialAuth } from "@/integrations/auth/FinancialAuthContext";
import { USE_COOKIE } from "@/services/session";
import { callOrchestrator, callOrchestratorConfigs } from "@/features/financial-hub/core/services/gateway";
import { setFastPathState } from "@/features/financial-hub/core/services/fastPathCache";
import { UserDataContext } from "@/routes/produtos.lazy";
import { useMediaQuery } from "@/hooks/use-media-query";
import type { CaughtError } from "@/features/financial-hub/components/shared/types";

// ============================================================================
// [REGISTRO DA ROTA TANSTACK ROUTER]
// ============================================================================
export const Route = createLazyFileRoute("/produtos/")({
  component: ProdutosHome,
});

// ============================================================================
// 🗺️ [CONFIGURAÇÕES DE FLUXOS E JORNADAS]
// ============================================================================
type ShowcaseConfig = {
  isDirect: false;
  route: string;
  flowKey: string;
  productId?: never;
};

type DirectConfig = {
  isDirect: true;
  productId: string;
  route?: never;
  flowKey?: never;
};

type FlowConfig = ShowcaseConfig | DirectConfig;

// 🖼️ [PERFORMANCE 29/09]: as imagens de produto eram os originais de ~2144x1984
// px (100-300 KB cada, ~1,1 MB só no tema claro), exibidas em 96 px no celular e
// ~480 px no desktop. Agora cada <img> usa a versão do tamanho certo, geradas ao
// lado dos originais: `-240.webp` (celular, bloco !isDesktop) e `-960.webp`
// (desktop). width/height reservam o espaço (proporção ~1,08:1) para o texto não
// "pular" quando a imagem chega.
//
// revealOnLoad: a imagem nasce transparente e aparece com fade quando termina de
// carregar (data-loaded="true" -> classe `data-[loaded=true]:opacity-100`).
// O `ref` cobre a imagem que já veio do cache/SSR antes do React ligar o onLoad
// (sem isso ela ficaria invisível); o onError libera também, para uma imagem
// quebrada não sumir em silêncio.
const revealOnLoad = {
  onLoad: (e: React.SyntheticEvent<HTMLImageElement>) => {
    e.currentTarget.dataset.loaded = "true";
  },
  onError: (e: React.SyntheticEvent<HTMLImageElement>) => {
    e.currentTarget.dataset.loaded = "true";
  },
  ref: (el: HTMLImageElement | null) => {
    if (el?.complete) el.dataset.loaded = "true";
  },
};

// Exibição de cada botão (visible / coming_soon / oculto) vem do banco:
// orchestrator_configs.home_key / home_status / home_order, lidos pela edge
// `orchestrator-configs?mode=home` (ver cabeçalho daquela função).
// Botão sem linha na tabela (ou com home_status = hidden) não aparece.
const flowsConfig: Record<string, FlowConfig> = {
  cartao: { isDirect: false, route: "/produtos/offer", flowKey: "Cartão" },
  carros: { isDirect: false, route: "/produtos/offer", flowKey: "Carros" },
  caminhoes: { isDirect: false, route: "/produtos/offer", flowKey: "Caminhões" },
  imoveis: { isDirect: false, route: "/produtos/offer", flowKey: "Imóveis" },
  floorPlan: { isDirect: false, route: "/produtos/offer", flowKey: "Vendedor" },
  equityCarro: { isDirect: true, productId: "7" },
  equityImovel: { isDirect: true, productId: "6" },
  seguroResidencial: { isDirect: true, productId: "10" },
  seguroAuto: { isDirect: true, productId: "9" },
};

type AppJourney = HeaderLink & { ativo: boolean };

// Cache em memória (por aba) da resposta de orchestrator-configs?mode=home.
// Evita chamar a edge a cada volta para a home (rate limit compartilhado com
// a jornada). Validade: 60s. F5 limpa (o módulo é recarregado).
const HOME_PRODUCTS_TTL_MS = 60_000;
let homeProductsCache: { at: number; map: Record<string, string> } | null = null;

// Botões de cada prateleira (seção) da home. A prateleira some -- junto com o
// link do menu -- quando TODOS os botões dela estão ocultos (sem linha em
// orchestrator_configs ou home_status = hidden). Seção fora deste mapa
// (ex.: "seguranca") é institucional e sempre aparece.
const SECTION_BUTTONS: Record<string, string[]> = {
  cartao: ["cartao"],
  veiculos: ["carros", "caminhoes"],
  imoveis: ["imoveis"],
  emprestimos: ["equityCarro", "equityImovel"],
  seguros: ["seguroAuto", "seguroResidencial"],
  floorplan: ["floorPlan"],
};

const homeLinks: AppJourney[] = [
  { href: "seguranca", label: "Segurança", ativo: true },
  { href: "cartao", label: "Cartão", ativo: true },
  { href: "veiculos", label: "Veículos", ativo: true },
  { href: "imoveis", label: "Imóveis", ativo: true },
  { href: "emprestimos", label: "Empréstimos", ativo: true },
  { href: "seguros", label: "Seguros", ativo: true },
  { href: "floorplan", label: "Floor Plan", ativo: false },
];

// ============================================================================
// 🏠 [COMPONENTE PRINCIPAL: PRODUTOS HOME]
// ============================================================================
export function ProdutosHome() {
  const navigate = useNavigate();
  const { sessionToken, logout, userProfile } = useFinancialAuth(); // EXTRAÍDO O USERPROFILE DO JWT
  const { userData, isVerifying } = useContext(UserDataContext) || {}; // EXTRAÍDO O USERDATA DO CONTEXTO DE REDE

  // 🚀 [PERFORMANCE]: substitui a duplicação estática (mobile+desktop sempre no DOM,
  // só escondida por classe CSS) por renderização condicional — cada seção passa a
  // baixar UMA imagem, não duas. Breakpoint = `sm` do Tailwind (640px), mesmo usado
  // pelas classes `sm:hidden` / `hidden sm:flex` abaixo.
  const isDesktop = useMediaQuery("(min-width: 640px)");

  const [isMounted, setIsMounted] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [loading, setLoading] = useState(false);
  const [loginLoading, setLoginLoading] = useState(false);
  const [activeKey, setActiveKey] = useState<string | null>(null);
  // Estado dos botões vindo de orchestrator-configs?mode=home.
  // null = carregando; homeProductsError = falha (botões ficam desabilitados).
  const [homeProducts, setHomeProducts] = useState<Record<string, string> | null>(null);
  const [homeProductsError, setHomeProductsError] = useState(false);
  // Chave do botão com falha na última tentativa -- mesma UX de CardOfferV:
  // barra de preenchimento passivo (5s) até o usuário tentar de novo ou o
  // tempo esgotar (limpa sozinho).
  const [errorKey, setErrorKey] = useState<string | null>(null);
  const [errorFillProgress, setErrorFillProgress] = useState(0);
  const errorFillRaf2Ref = useRef<number | null>(null);

  useEffect(() => {
    if (!errorKey) {
      setErrorFillProgress(0);
      return;
    }
    setErrorFillProgress(0);
    const raf1 = requestAnimationFrame(() => {
      errorFillRaf2Ref.current = requestAnimationFrame(() => setErrorFillProgress(100));
    });
    const timer = setTimeout(() => {
      setErrorKey(null);
    }, 5000);
    return () => {
      cancelAnimationFrame(raf1);
      if (errorFillRaf2Ref.current !== null) cancelAnimationFrame(errorFillRaf2Ref.current);
      clearTimeout(timer);
    };
  }, [errorKey]);

  // 🌙 Modo noturno da home: agora usa o MESMO tema global do resto do site
  // (ThemeProvider / localStorage["sbx-theme"]) em vez de um estado isolado.
  // Clicar no sol/lua aqui muda a página inteira, não só as imagens.
  const { theme, setTheme, resolvedTheme } = useTheme();
  const nightMode = resolvedTheme === "dark";
  const setNightMode = (updater: boolean | ((prev: boolean) => boolean)) => {
    const next = typeof updater === "function" ? updater(nightMode) : updater;
    setTheme(next ? "dark" : "light");
  };

  // Sincronização de montagem em ambiente cliente
  useEffect(() => {
    setIsMounted(true);
  }, []);

  // Limpeza de estados transacionais e blindagem contra persistência de cache de navegador
  useEffect(() => {
    setLoading(false);
    setLoginLoading(false);
    setActiveKey(null);

    const handlePageShow = (event: PageTransitionEvent) => {
      if (event.persisted) {
        setLoading(false);
        setLoginLoading(false);
        setActiveKey(null);
      }
    };

    window.addEventListener("pageshow", handlePageShow);
    return () => window.removeEventListener("pageshow", handlePageShow);
  }, []);

  // Telemetria de scroll para comportamentos visuais de header se necessário
  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Função de navegação determinística preservando o túnel SPA do TanStack Router
  const performNavigation = (url: string) => {
    try {
      const targetUrlObj = new URL(url, window.location.origin);

      // Se for do mesmo domínio, mesmo com "https://", vai via SPA e PRESERVA A RAM
      if (targetUrlObj.origin === window.location.origin) {
        const originalParams = new URLSearchParams(window.location.search);
        targetUrlObj.searchParams.forEach((val, key) => originalParams.set(key, val));

        navigate({
          to: targetUrlObj.pathname as any,
          search: Object.fromEntries(originalParams.entries()) as any,
        });
      } else {
        // Apenas se for domínio externo real
        window.location.href = url;
      }
    } catch {
      // Fallback caso venha uma URL relativa pura
      navigate({ to: url as any });
    }
  };

  // Gerenciador central de cliques em produtos (Handshake com Orquestrador e OLAP)
  const handleProductClick = async (configKey: keyof typeof flowsConfig) => {
    setLoading(true);
    setActiveKey(configKey);
    setErrorKey(null);

    const config = flowsConfig[configKey];
    if (!config) {
      setLoading(false);
      setActiveKey(null);
      return;
    }

    try {
      const currentHref = window.location.href;
      const urlParams = new URLSearchParams(window.location.search);
      const existingVisitId = urlParams.get("visit_id");
      const existingVisitUpdateId = urlParams.get("visit_update_id");

      // =========================================================================
      // 🚀 FLUXO DIRETO (Ex: Seguros, Equity). Pula a vitrine, vai direto pro Form.
      // =========================================================================
      if (config.isDirect) {
        const payload = {
          action: "CONSULT",
          product_id: config.productId,
          origin_url: currentHref,
          ...(existingVisitId && { visit_id: existingVisitId }),
          ...(existingVisitUpdateId && { visit_update_id: existingVisitUpdateId }),
          interaction_context: {
            origin_url: currentHref,
            utm_source: "produtos_direct",
            utm_medium: "referral",
            utm_campaign: `flow_${configKey.toLowerCase()}`,
          },
        };

        const consultResponse = await callOrchestrator(payload, "POST");

        if (consultResponse?.url) {
          if (consultResponse.state) {
            setFastPathState(consultResponse.state);
          }

          // ✨ FIX APLICADO AQUI: Passamos a URL inteira para evitar quebrar parceiros
          performNavigation(consultResponse.url);
          return;
        } else {
          throw new Error("URL de redirecionamento ausente na resposta do orquestrador.");
        }
      }

      // =========================================================================
      // 🛒 FLUXO INDIRETO (Ex: Carros). Vai para a Vitrine de Ofertas.
      // =========================================================================
      const visitPayload = {
        action: "VISIT",
        target_url: config.route,
        origin_url: currentHref,
        ...(existingVisitId && { visit_id: existingVisitId }),
        ...(existingVisitUpdateId && { visit_update_id: existingVisitUpdateId }),
        interaction_context: {
          origin_url: currentHref,
          utm_source: "produtos_direct",
          utm_medium: "referral",
          utm_campaign: `flow_${configKey.toLowerCase()}`,
        },
      };

      const visitResponse = await callOrchestrator(visitPayload, "POST");

      if (visitResponse?.url) {
        if (visitResponse.state) {
          setFastPathState(visitResponse.state);
        }

        const targetUrlObj = new URL(visitResponse.url, window.location.origin);
        targetUrlObj.searchParams.set("flow", config.flowKey);

        setLoading(false);
        // ✨ FIX APLICADO AQUI: Passamos a URL stringificada completa para o parser
        performNavigation(targetUrlObj.toString());
        return;
      } else {
        throw new Error("URL de visita ausente na resposta do orquestrador.");
      }
    } catch (caught: unknown) {
      const error = caught as CaughtError;
      if (error && error.code === "SESSION_EXPIRED" && error.fallback_url) {
        const safeUrl = new URL(error.fallback_url, window.location.origin);
        window.location.href = safeUrl.pathname + safeUrl.search;
        return;
      }

      setLoading(false);
      setActiveKey(null);
      setErrorKey(configKey);
    } finally {
      if (!config.isDirect) setLoading(false);
    }
  };

  // Carrega o estado de exibição dos botões da home (visible / coming_soon)
  useEffect(() => {
    if (!isMounted || !sessionToken) return;
    let cancelled = false;
    setHomeProductsError(false);

    if (homeProductsCache && Date.now() - homeProductsCache.at < HOME_PRODUCTS_TTL_MS) {
      setHomeProducts(homeProductsCache.map);
      return;
    }

    callOrchestratorConfigs({ mode: "home" })
      .then((res) => {
        if (cancelled) return;
        const map: Record<string, string> = {};
        (res?.products || []).forEach((p) => {
          if (p?.key) map[p.key] = p.status as string;
        });
        homeProductsCache = { at: Date.now(), map };
        setHomeProducts(map);
      })
      .catch((caught: unknown) => {
        const error = caught as CaughtError;
        if (cancelled) return;
        // Sessão expirada: mesmo tratamento do clique nos botões (volta ao login)
        if (error && error.code === "SESSION_EXPIRED" && error.fallback_url) {
          const safeUrl = new URL(error.fallback_url, window.location.origin);
          window.location.href = safeUrl.pathname + safeUrl.search;
          return;
        }
        setHomeProductsError(true);
      });
    return () => {
      cancelled = true;
    };
  }, [isMounted, sessionToken]);

  // 1. Unificamos o esqueleto do botão para evitar diferenças de espessura (anti-aliasing)
  const baseButtonClasses =
    "flex items-center justify-center gap-2 px-5 py-2 font-normal rounded-none transition-colors text-sm w-full md:w-auto";

  // 2. Renderizador atômico: Aplica as cores via condicional, preservando o esqueleto
  const renderButton = (
    label: string,
    configKey: keyof typeof flowsConfig
  ) => {
    const config = flowsConfig[configKey];
    const isLocked = loading || isVerifying;
    const isCurrentLoading = loading && activeKey === configKey;
    const isCurrentError = errorKey === configKey;

    if (isCurrentError) {
      return (
        <div className="relative w-full md:w-auto overflow-hidden rounded-none border border-neutral-200 dark:border-neutral-700 shadow-xs bg-white dark:bg-neutral-900">
          {/* Preenchimento passivo: cresce 0->100% em 5s, depois volta ao estado normal sozinho */}
          <div
            className="absolute inset-y-0 left-0 bg-neutral-100 dark:bg-neutral-800"
            style={{
              width: `${errorFillProgress}%`,
              transitionProperty: "width",
              transitionDuration: "5000ms",
              transitionTimingFunction: "linear",
            }}
          />
          <button
            type="button"
            onClick={() => handleProductClick(configKey)}
            className={`relative z-10 ${baseButtonClasses} text-neutral-900 dark:text-neutral-100`}
          >
            <TriangleAlert className="w-4 h-4 shrink-0 text-neutral-500 dark:text-neutral-400" strokeWidth={1.25} />
            <span className="font-jakarta tracking-tight text-center truncate">Não foi possível continuar.</span>
            <span className="underline underline-offset-2 decoration-neutral-400 dark:decoration-neutral-500 shrink-0">
              Tentar novamente
            </span>
          </button>
        </div>
      );
    }

    // Exibição vinda do banco (orchestrator-configs?mode=home):
    // carregando ou erro -> desabilitado | sem status -> não aparece |
    // coming_soon -> desabilitado com "Em breve" | visible -> ativo
    const homeStatus = homeProducts?.[configKey];
    const isHomeLoading = homeProducts === null || homeProductsError;
    if (!isHomeLoading && !homeStatus) return null;

    if (isHomeLoading || homeStatus === "coming_soon") {
      const isComingSoon = !isHomeLoading && homeStatus === "coming_soon";
      return (
        <button 
          disabled 
          // Mantém a mesma base, apenas muda a cor para o padrão "desabilitado"
          className={`${baseButtonClasses} border border-neutral-200 dark:border-neutral-800 text-neutral-400 dark:text-neutral-600 bg-neutral-50 dark:bg-neutral-900 cursor-not-allowed`}
        >
          <span className="font-jakarta tracking-tight text-center">{label}</span>
          {isComingSoon ? (
            <span className="shrink-0 border border-neutral-300 dark:border-neutral-700 px-1.5 py-0.5 text-[10px] font-medium uppercase tracking-wider text-neutral-500 dark:text-neutral-400">
              Em breve
            </span>
          ) : (
            <ArrowRight className="w-4 h-4" strokeWidth={1.25} />
          )}
        </button>
      );
    }

    return (
      <button
        disabled={isLocked}
        onClick={() => handleProductClick(configKey)}
        // Mantém a mesma base, aplica as cores "ativas" e lida com o lock de loading
        className={`group ${baseButtonClasses} border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 text-neutral-900 dark:text-neutral-100 hover:bg-neutral-900 dark:hover:bg-white hover:text-white dark:hover:text-neutral-900 hover:border-neutral-900 dark:hover:border-white shadow-xs ${isLocked ? "opacity-50 cursor-not-allowed shadow-none" : ""}`}
      >
        {isCurrentLoading && (
          <Loader2 className="w-4 h-4 animate-spin" strokeWidth={1.25} />
        )}
        
        <span className="font-jakarta tracking-tight text-center">
          {isVerifying ? "Carregando..." : isCurrentLoading ? "Aguarde..." : label}
        </span>

        {!isCurrentLoading && !isVerifying && (
          <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" strokeWidth={1.25} />
        )}
      </button>
    );
  };

  // Enquanto carrega (ou se der erro) nenhuma prateleira é escondida.
  const isSectionVisible = (href: string) => {
    const buttons = SECTION_BUTTONS[href];
    if (!buttons || homeProducts === null || homeProductsError) return true;
    return buttons.some((key) => !!homeProducts[key]);
  };
  const linksAtivos = homeLinks.filter((link) => link.ativo && isSectionVisible(link.href));
  const productLinks = linksAtivos.filter((link) => link.href !== "seguranca");

  return (
    <div className={`bg-white dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 antialiased font-sans overflow-x-hidden relative rounded-none transition-colors ${nightMode ? "dark" : ""}`}>
      <style>{`
        .glass { background: rgba(255, 255, 255, 0.85); backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px); }
        @keyframes float-slow { 0%, 100% { transform: translateY(0px) rotate(0deg) scale(1); } 50% { transform: translateY(-10px) rotate(2deg) scale(1.01); } }
        @keyframes float-reverse { 0%, 100% { transform: translateY(0px) rotate(0deg) scale(1.01); } 50% { transform: translateY(10px) rotate(-2deg) scale(0.99); } }
        .animate-blob-float { animation: float-slow 7s ease-in-out infinite; }
        .animate-blob-float-reverse { animation: float-reverse 8s ease-in-out infinite; }
        .blob-shadow { filter: drop-shadow(0 20px 30px rgba(15, 23, 42, 0.05)); }
      `}</style>

      {/* Cabeçalho Mestre Consolidado */}
      <PanelHeader
        showNav={true}
        showAuth={true}
        links={linksAtivos}
        sessionToken={isMounted ? sessionToken : undefined}
        userData={userData || userProfile}
        onLogout={() => logout({ purgeEnv: true })}
        onNavigate={(path) => navigate({ to: path as any })}
        nightMode={nightMode}
        onToggleNightMode={() => setNightMode((v) => !v)}
      />

      {/* Renderização Dinâmica das Seções da Vitrine Institucional */}
      {linksAtivos.map((link) => {
        if (link.href === "seguranca") {
          return (
            <section
              key="seguranca"
              id="seguranca"
              className="relative pt-28 pb-10 md:pt-32 md:pb-12 overflow-hidden bg-white dark:bg-neutral-950 border-b border-neutral-200 dark:border-neutral-800 scroll-mt-16 rounded-none"
            >
              <div className="max-w-7xl mx-auto px-6 relative z-10">
                <div className="flex flex-col lg:flex-row items-center justify-between gap-8 lg:gap-12">
                  <div className="w-full lg:w-6/12 space-y-5">
                    <div className="flex flex-row items-center gap-4 -ml-2 sm:block sm:ml-0">
                      {/* 🚀 [PERFORMANCE]: era duas cópias (esta + a do bloco desktop mais abaixo)
                          sempre no DOM, uma delas só escondida via `sm:hidden`/`hidden sm:flex`.
                          O navegador baixava as duas de qualquer forma. Agora só a versão relevante
                          para `isDesktop` é renderizada — uma única imagem por vez. Mesmo padrão
                          aplicado nas outras 6 seções de produto abaixo. */}
                      {!isDesktop && (
                        <div className="w-24 shrink-0 relative flex justify-start">
                          <div className="absolute inset-0 animate-blob-float blob-shadow flex items-center justify-center">
                            <svg
                              viewBox="0 0 200 200"
                              xmlns="http://www.w3.org/2000/svg"
                              className={`w-full h-full ${nightMode ? "fill-neutral-800" : "fill-neutral-100"}`}
                            >
                              <path
                                d="M43,-62.1C55.3,-53.4,64.8,-40.4,70.9,-25.6C77,-10.8,79.7,5.8,74.7,19.6C69.7,33.5,57,44.7,43.5,52.9C29.9,61.1,15,66.4,-1.3,68.2C-17.6,70,-35.1,68.3,-48.1,59.7C-61.1,51.1,-69.5,35.6,-73,19.1C-76.5,2.7,-75.1,-14.8,-67.7,-29C-60.3,-43.3,-46.8,-54.2,-32.8,-62.1C-18.8,-70,-9.4,-74.8,3.2,-79.2C15.8,-83.7,30.7,-87.8,43,-62.1Z"
                                transform="translate(100 100)"
                              />
                            </svg>
                          </div>
                          <div className="relative w-full p-0 flex items-center justify-center z-0">
                            <img
                              src={nightMode ? "/assets/home/conta-dark-240.webp" : "/assets/home/conta-240.webp"}
                              width={240}
                              height={222}
                              {...revealOnLoad}
                              alt="Segurança sbX Wallet"
                              fetchPriority="high"
                              decoding="async"
                              className={nightMode ? "w-full h-auto object-contain relative opacity-0 transition-opacity duration-300 data-[loaded=true]:opacity-100" : "mix-blend-multiply w-full h-auto object-contain relative opacity-0 transition-opacity duration-300 data-[loaded=true]:opacity-100"}
                            />
                          </div>
                        </div>
                      )}

                      <div className="space-y-2 flex-1 text-left">
                        <div className="inline-flex items-center space-x-2 fill-gradient px-3 py-1 rounded-full text-white text-[10px] font-bold uppercase tracking-wider">
                          <span>Conta SBX Pay</span>
                        </div>
                        <h1 className="text-2xl md:text-4xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100 leading-[1.15]">
                          Segurança para <span className="serif font-normal text-neutral-900 dark:text-neutral-100">comprar e vender.</span>
                        </h1>
                      </div>
                    </div>

                    <p className="text-sm md:text-base text-neutral-600 dark:text-neutral-400 max-w-2xl mx-auto lg:mx-0 leading-relaxed">
                      Seu dinheiro e seus dados protegidos da oferta ao pagamento, com a infraestrutura que organiza o
                      mercado de ativos reais.
                    </p>

                    <div className="flex flex-col gap-4 text-left max-w-xl mx-auto lg:mx-0">
                      <div className="bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-none p-4 flex flex-col gap-2 transition-colors hover:bg-neutral-100/50 dark:hover:bg-neutral-800/50">
                        <div className="flex items-center gap-2">
                          <Plus className="w-3.5 h-3.5 md:w-4 md:h-4 text-[#2246A7]" strokeWidth={2} />
                          <h4 className="font-mono text-[11px] md:text-[13px] uppercase tracking-[0.18em] text-neutral-900 dark:text-neutral-100 mt-0.5">
                            Seu dinheiro sempre protegido
                          </h4>
                        </div>
                        <p className="text-neutral-600 dark:text-neutral-400 text-[13px] leading-relaxed mt-1">
                          Compre com tranquilidade. Até o negócio ser concluído, o valor fica guardado em uma conta
                          regulada pelo Banco Central.
                        </p>
                      </div>
                      <div className="bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-none p-4 flex flex-col gap-2 transition-colors hover:bg-neutral-100/50 dark:hover:bg-neutral-800/50">
                        <div className="flex items-center gap-2">
                          <Plus className="w-3.5 h-3.5 md:w-4 md:h-4 text-[#2246A7]" strokeWidth={2} />
                          <h4 className="font-mono text-[11px] md:text-[13px] uppercase tracking-[0.18em] text-neutral-900 dark:text-neutral-100 mt-0.5">
                            Segurança de ponta a ponta
                          </h4>
                        </div>
                        <p className="text-neutral-600 dark:text-neutral-400 text-[13px] leading-relaxed mt-1">
                          Cada pagamento é feito com total segurança, em um ambiente auditado, e seus dados ficam protegidos o tempo todo.
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start pt-2">
                      <button
                        disabled={loginLoading || loading}
                        onClick={() => {
                          setLoginLoading(true);
                          setTimeout(() => {
                            window.open(
                              "https://accounts.superbid.net/signin?response_type=token&client_id=dzqC3VodSoXukD45BQKg3NQU6-faststore&redirect_uri=https://www.superbid.net/&authorization_uri=https://www.superbid.net/authorization/&language=pt-BR&portal_id=2&hostName=Superbid%20BR",
                              "_blank",
                            );
                            setLoginLoading(false);
                          }, 400);
                        }}
                        // AQUI ESTÁ A CORREÇÃO: Usando baseButtonClasses e as cores do botão ativo
                        className={`${baseButtonClasses} border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 text-neutral-900 dark:text-neutral-100 hover:bg-neutral-900 dark:hover:bg-white hover:text-white dark:hover:text-neutral-900 hover:border-neutral-900 dark:hover:border-white shadow-xs ${(loginLoading || loading) ? "opacity-50 cursor-not-allowed shadow-none" : ""}`}
                      >
                        {loginLoading ? (
                          <Loader2 className="w-4 h-4 animate-spin" strokeWidth={1.25} />
                        ) : (
                          <UserPlus className="w-4 h-4" strokeWidth={1.25} />
                        )}
                        <span className="font-jakarta tracking-tight">
                          {loginLoading ? "Aguarde..." : "Entrar na conta"}
                        </span>
                      </button>
                    </div>
                  </div>

                  {isDesktop && (
                    <div className="flex w-full lg:w-5/12 relative justify-center mt-8 lg:mt-0">
                      <div className="relative w-full max-w-sm p-2 flex items-center justify-center z-0">
                        <div className="absolute inset-0 animate-blob-float blob-shadow flex items-center justify-center">
                          <svg
                            viewBox="0 0 200 200"
                            xmlns="http://www.w3.org/2000/svg"
                            className={`w-full h-full ${nightMode ? "fill-neutral-800" : "fill-neutral-100"}`}
                          >
                            <path
                              d="M43,-62.1C55.3,-53.4,64.8,-40.4,70.9,-25.6C77,-10.8,79.7,5.8,74.7,19.6C69.7,33.5,57,44.7,43.5,52.9C29.9,61.1,15,66.4,-1.3,68.2C-17.6,70,-35.1,68.3,-48.1,59.7C-61.1,51.1,-69.5,35.6,-73,19.1C-76.5,2.7,-75.1,-14.8,-67.7,-29C-60.3,-43.3,-46.8,-54.2,-32.8,-62.1C-18.8,-70,-9.4,-74.8,3.2,-79.2C15.8,-83.7,30.7,-87.8,43,-62.1Z"
                              transform="translate(100 100)"
                            />
                          </svg>
                        </div>
                        <img
                          src={nightMode ? "/assets/home/conta-dark-960.webp" : "/assets/home/conta-960.webp"}
                          width={960}
                          height={888}
                          {...revealOnLoad}
                          alt="Segurança sbX Wallet"
                          fetchPriority="high"
                          decoding="async"
                          className={nightMode ? "w-[90%] h-auto mx-auto object-contain relative opacity-0 transition-opacity duration-300 data-[loaded=true]:opacity-100" : "mix-blend-multiply w-[90%] h-auto mx-auto object-contain relative opacity-0 transition-opacity duration-300 data-[loaded=true]:opacity-100"}
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </section>
          );
        }

        const indexDoProduto = productLinks.findIndex((p) => p.href === link.href);
        const isPar = indexDoProduto % 2 === 0;
        const layoutDirecao = isPar ? "lg:flex-row-reverse" : "lg:flex-row";
        const animacao = isPar ? "animate-blob-float-reverse" : "animate-blob-float";

        if (link.href === "cartao") {
          return (
            <section
              key="cartao"
              id="cartao"
              className="py-10 md:py-12 bg-white dark:bg-neutral-950 border-b border-neutral-200 dark:border-neutral-800 overflow-hidden relative scroll-mt-16 rounded-none"
            >
              <div className="max-w-7xl mx-auto px-6 relative z-10">
                <div className={`flex flex-col ${layoutDirecao} items-center justify-between gap-8 lg:gap-12`}>
                  <div className="w-full lg:w-6/12 space-y-5">
                    <div className="flex flex-row items-center gap-4 -ml-2 sm:block sm:ml-0">
                      {!isDesktop && (
                        <div className="w-24 shrink-0 relative flex justify-start">
                          <div className={`absolute inset-0 ${animacao} blob-shadow flex items-center justify-center`}>
                            <svg
                              viewBox="0 0 200 200"
                              xmlns="http://www.w3.org/2000/svg"
                              className={`w-full h-full ${nightMode ? "fill-neutral-800" : "fill-neutral-100"}`}
                            >
                              <path
                                d="M54.5,-73.4C69.3,-64,79.1,-46.8,82,-28.9C84.9,-11,80.9,7.6,73.8,24.1C66.7,40.7,56.5,55.3,42.4,63.4C28.2,71.5,10.1,73,-6.9,71.2C-23.9,69.5,-39.8,64.4,-51.9,54.7C-64,45.1,-72.3,31,-75.4,15.4C-78.4,-0.2,-76.3,-17.3,-68.8,-32.1C-61.2,-46.9,-48.3,-59.4,-33.5,-68.8C-18.7,-78.2,-2.1,-84.5,14.9,-82.1C32,-79.7,46.8,-76.1,54.5,-73.4Z"
                                transform="translate(100 100)"
                              />
                            </svg>
                          </div>
                          <div className="relative w-full p-0 flex items-center justify-center z-0">
                            <img
                              src={nightMode ? "/assets/home/cartao-dark-240.webp" : "/assets/home/cartao-240.webp"}
                              width={240}
                              height={222}
                              {...revealOnLoad}
                              alt="Cartão"
                              loading="lazy"
                              decoding="async"
                              className={nightMode ? "w-full h-auto object-contain relative opacity-0 transition-opacity duration-300 data-[loaded=true]:opacity-100" : "mix-blend-multiply w-full h-auto object-contain relative opacity-0 transition-opacity duration-300 data-[loaded=true]:opacity-100"}
                            />
                          </div>
                        </div>
                      )}
                      <div className="space-y-2 flex-1">
                        <div className="inline-flex items-center space-x-2 fill-gradient px-3 py-1 rounded-full text-white text-[10px] font-bold uppercase tracking-wider">
                          <span>Até R$ 120 mil</span>
                        </div>
                        <h2 className="text-lg md:text-3xl font-bold text-neutral-900 dark:text-neutral-100 tracking-tight leading-snug">
                          Parcele em <span className="serif font-normal text-neutral-900 dark:text-neutral-100">até 18x no cartão.</span>
                        </h2>
                      </div>
                    </div>
                    <p className="text-sm md:text-base text-neutral-600 dark:text-neutral-400 leading-relaxed">
                      Encontrou um bom negócio? Use o limite do seu cartão de crédito e pague em parcelas, com toda a
                      segurança.
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                      <div className="bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-none p-4 flex flex-col gap-2 transition-colors hover:bg-neutral-100/50 dark:hover:bg-neutral-800/50">
                        <div className="flex items-center gap-2">
                          <Plus className="w-3.5 h-3.5 md:w-4 md:h-4 text-[#2246A7]" strokeWidth={2} />
                          <span className="font-mono text-[11px] md:text-[13px] uppercase tracking-[0.18em] text-neutral-900 dark:text-neutral-100 mt-0.5">
                            Para você e sua empresa
                          </span>
                        </div>
                        <p className="text-neutral-600 dark:text-neutral-400 text-[13px] leading-relaxed mt-1">
                          Parcelamento disponível para o seu cartão ou para o cartão da sua empresa.
                        </p>
                      </div>
                      <div className="bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-none p-4 flex flex-col gap-2 transition-colors hover:bg-neutral-100/50 dark:hover:bg-neutral-800/50">
                        <div className="flex items-center gap-2">
                          <Plus className="w-3.5 h-3.5 md:w-4 md:h-4 text-[#2246A7]" strokeWidth={2} />
                          <span className="font-mono text-[11px] md:text-[13px] uppercase tracking-[0.18em] text-neutral-900 dark:text-neutral-100 mt-0.5">
                            Compra protegida
                          </span>
                        </div>
                        <p className="text-neutral-600 dark:text-neutral-400 text-[13px] leading-relaxed mt-1">
                          Seu banco faz uma verificação extra para confirmar que a compra é sua.
                        </p>
                      </div>
                    </div>
                    <div className="pt-2">
                      {renderButton("Ver ofertas parceladas", "cartao")}
                    </div>
                  </div>
                  {isDesktop && (
                    <div className="flex w-full lg:w-5/12 relative justify-center mt-8 lg:mt-0">
                      <div className="relative w-full max-w-sm p-2 flex items-center justify-center z-0">
                        <div className={`absolute inset-0 ${animacao} blob-shadow flex items-center justify-center`}>
                          <svg
                            viewBox="0 0 200 200"
                            xmlns="http://www.w3.org/2000/svg"
                            className={`w-full h-full ${nightMode ? "fill-neutral-800" : "fill-neutral-100"}`}
                          >
                            <path
                              d="M54.5,-73.4C69.3,-64,79.1,-46.8,82,-28.9C84.9,-11,80.9,7.6,73.8,24.1C66.7,40.7,56.5,55.3,42.4,63.4C28.2,71.5,10.1,73,-6.9,71.2C-23.9,69.5,-39.8,64.4,-51.9,54.7C-64,45.1,-72.3,31,-75.4,15.4C-78.4,-0.2,-76.3,-17.3,-68.8,-32.1C-61.2,-46.9,-48.3,-59.4,-33.5,-68.8C-18.7,-78.2,-2.1,-84.5,14.9,-82.1C32,-79.7,46.8,-76.1,54.5,-73.4Z"
                              transform="translate(100 100)"
                            />
                          </svg>
                        </div>
                        <img
                          src={nightMode ? "/assets/home/cartao-dark-960.webp" : "/assets/home/cartao-960.webp"}
                          width={960}
                          height={888}
                          {...revealOnLoad}
                          alt="Cartão"
                          loading="lazy"
                          decoding="async"
                          className={nightMode ? "w-[90%] h-auto mx-auto object-contain relative opacity-0 transition-opacity duration-300 data-[loaded=true]:opacity-100" : "mix-blend-multiply w-[90%] h-auto mx-auto object-contain relative opacity-0 transition-opacity duration-300 data-[loaded=true]:opacity-100"}
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </section>
          );
        }

        if (link.href === "veiculos") {
          return (
            <section
              key="veiculos"
              id="veiculos"
              className="py-10 md:py-12 bg-white dark:bg-neutral-950 border-b border-neutral-200 dark:border-neutral-800 overflow-hidden relative scroll-mt-16 rounded-none"
            >
              <div className="max-w-7xl mx-auto px-6 relative z-10">
                <div className={`flex flex-col ${layoutDirecao} items-center justify-between gap-8 lg:gap-12`}>
                  <div className="w-full lg:w-6/12 space-y-5">
                    <div className="flex flex-row items-center gap-4 -ml-2 sm:block sm:ml-0">
                      {!isDesktop && (
                        <div className="w-24 shrink-0 relative flex justify-start">
                          <div className={`absolute inset-0 ${animacao} blob-shadow flex items-center justify-center`}>
                            <svg
                              viewBox="0 0 200 200"
                              xmlns="http://www.w3.org/2000/svg"
                              className={`w-full h-full ${nightMode ? "fill-neutral-800" : "fill-neutral-100"}`}
                            >
                              <path
                                d="M55.6,-68.8C70.6,-58.5,80.4,-40.4,82,-21.8C83.7,-3.3,77.3,15.7,68.4,32.7C59.5,49.7,48.2,64.7,32.9,71.5C17.6,78.3,-1.7,76.9,-19.7,71.2C-37.7,65.5,-54.3,55.5,-65.4,40.7C-76.5,25.9,-82,6.3,-79.8,-11.9C-77.5,-30,-67.4,-46.8,-52.9,-57.1C-38.3,-67.3,-19.1,-71.1,0.5,-71.7C20.1,-72.3,40.3,-69.7,55.6,-68.8Z"
                                transform="translate(100 100)"
                              />
                            </svg>
                          </div>
                          <div className="relative w-full p-0 flex items-center justify-center z-0">
                            <img
                              src={nightMode ? "/assets/home/financiamentoveiculos-dark-240.webp" : "/assets/home/financiamentoveiculos-240.webp"}
                              width={240}
                              height={222}
                              {...revealOnLoad}
                              alt="Veículos"
                              loading="lazy"
                              decoding="async"
                              className={nightMode ? "w-full h-auto object-contain relative opacity-0 transition-opacity duration-300 data-[loaded=true]:opacity-100" : "mix-blend-multiply w-full h-auto object-contain relative opacity-0 transition-opacity duration-300 data-[loaded=true]:opacity-100"}
                            />
                          </div>
                        </div>
                      )}
                      <div className="space-y-2 flex-1">
                        <div className="inline-flex items-center space-x-2 fill-gradient px-3 py-1 rounded-full text-white text-[10px] font-bold uppercase tracking-wider">
                          <span>EM ATÉ 60x</span>
                        </div>
                        <h2 className="text-lg md:text-3xl font-bold text-neutral-900 dark:text-neutral-100 tracking-tight leading-snug">
                          Financie seu <span className="serif font-normal text-neutral-900 dark:text-neutral-100">carro ou caminhão.</span>
                        </h2>
                      </div>
                    </div>
                    <p className="text-sm md:text-base text-neutral-600 dark:text-neutral-400 leading-relaxed max-w-2xl">
                      Escolha o veículo e deixe o financiamento com a gente. Comparamos as condições dos principais
                      bancos do país e apresentamos a melhor opção para você.
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6 w-full max-w-2xl">
                      <div className="bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-none p-4 flex flex-col gap-2 transition-colors hover:bg-neutral-100/50 dark:hover:bg-neutral-800/50">
                        <div className="flex items-center gap-2">
                          <Plus className="w-3.5 h-3.5 md:w-4 md:h-4 text-[#2246A7]" strokeWidth={2} />
                          <span className="font-mono text-[11px] md:text-[13px] uppercase tracking-[0.18em] text-neutral-900 dark:text-neutral-100 mt-0.5">
                            Para você e sua empresa
                          </span>
                        </div>
                        <p className="text-neutral-600 dark:text-neutral-400 text-[13px] leading-relaxed mt-1">
                          Um especialista acompanha você do pedido até a assinatura.
                        </p>
                      </div>
                      <div className="bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-none p-4 flex flex-col gap-2 transition-colors hover:bg-neutral-100/50 dark:hover:bg-neutral-800/50">
                        <div className="flex items-center gap-2">
                          <Plus className="w-3.5 h-3.5 md:w-4 md:h-4 text-[#2246A7]" strokeWidth={2} />
                          <span className="font-mono text-[11px] md:text-[13px] uppercase tracking-[0.18em] text-neutral-900 dark:text-neutral-100 mt-0.5">
                            Facilidade
                          </span>
                        </div>
                        <p className="text-neutral-600 dark:text-neutral-400 text-[13px] leading-relaxed mt-1">
                          Escolha a entrada e as parcelas, converse pelo WhatsApp e assine o contrato on-line.
                        </p>
                      </div>
                    </div>
                    <div className="flex flex-col md:flex-row gap-4 w-full max-w-2xl mt-6">
                      {renderButton("Ver carros financiados", "carros")}
                      {renderButton("Ver caminhões financiados", "caminhoes")}
                    </div>
                  </div>
                  {isDesktop && (
                    <div className="flex w-full lg:w-5/12 relative justify-center mt-8 lg:mt-0">
                      <div className="relative w-full max-w-sm p-2 flex items-center justify-center z-0">
                        <div className={`absolute inset-0 ${animacao} blob-shadow flex items-center justify-center`}>
                          <svg
                            viewBox="0 0 200 200"
                            xmlns="http://www.w3.org/2000/svg"
                            className={`w-full h-full ${nightMode ? "fill-neutral-800" : "fill-neutral-100"}`}
                          >
                            <path
                              d="M55.6,-68.8C70.6,-58.5,80.4,-40.4,82,-21.8C83.7,-3.3,77.3,15.7,68.4,32.7C59.5,49.7,48.2,64.7,32.9,71.5C17.6,78.3,-1.7,76.9,-19.7,71.2C-37.7,65.5,-54.3,55.5,-65.4,40.7C-76.5,25.9,-82,6.3,-79.8,-11.9C-77.5,-30,-67.4,-46.8,-52.9,-57.1C-38.3,-67.3,-19.1,-71.1,0.5,-71.7C20.1,-72.3,40.3,-69.7,55.6,-68.8Z"
                              transform="translate(100 100)"
                            />
                          </svg>
                        </div>
                        <img
                          src={nightMode ? "/assets/home/financiamentoveiculos-dark-960.webp" : "/assets/home/financiamentoveiculos-960.webp"}
                          width={960}
                          height={888}
                          {...revealOnLoad}
                          alt="Veículos"
                          loading="lazy"
                          decoding="async"
                          className={nightMode ? "w-[90%] h-auto mx-auto object-contain relative opacity-0 transition-opacity duration-300 data-[loaded=true]:opacity-100" : "mix-blend-multiply w-[90%] h-auto mx-auto object-contain relative opacity-0 transition-opacity duration-300 data-[loaded=true]:opacity-100"}
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </section>
          );
        }

        if (link.href === "imoveis") {
          return (
            <section
              key="imoveis"
              id="imoveis"
              className="py-10 md:py-12 bg-white dark:bg-neutral-950 border-b border-neutral-200 dark:border-neutral-800 overflow-hidden relative scroll-mt-16 rounded-none"
            >
              <div className="max-w-7xl mx-auto px-6 relative z-10">
                <div className={`flex flex-col ${layoutDirecao} items-center justify-between gap-8 lg:gap-12`}>
                  <div className="w-full lg:w-6/12 space-y-5">
                    <div className="flex flex-row items-center gap-4 -ml-2 sm:block sm:ml-0">
                      {!isDesktop && (
                        <div className="w-24 shrink-0 relative flex justify-start">
                          <div className={`absolute inset-0 ${animacao} blob-shadow flex items-center justify-center`}>
                            <svg
                              viewBox="0 0 200 200"
                              xmlns="http://www.w3.org/2000/svg"
                              className={`w-full h-full ${nightMode ? "fill-neutral-800" : "fill-neutral-100"}`}
                            >
                              <path
                                d="M48.2,-64.1C61.4,-53.4,70.1,-37.2,73.1,-20.1C76.1,-3,73.4,15,65,30.3C56.6,45.6,42.5,58.3,26,65.6C9.6,72.9,-9.2,74.8,-27.1,69.5C-45,64.3,-62.1,51.8,-70.6,35.1C-79.1,18.4,-79.1,-2.6,-73.2,-20.9C-67.4,-39.1,-55.8,-54.6,-40.8,-64.7C-25.8,-74.8,-7.4,-79.5,10.1,-78.9C27.6,-78.3,45.2,-72.4,48.2,-64.1Z"
                                transform="translate(100 100)"
                              />
                            </svg>
                          </div>
                          <div className="relative w-full p-0 flex items-center justify-center z-0">
                            <img
                              src={nightMode ? "/assets/home/financiamentoimoveis-dark-240.webp" : "/assets/home/financiamentoimoveis-240.webp"}
                              width={240}
                              height={222}
                              {...revealOnLoad}
                              alt="Imóveis"
                              loading="lazy"
                              decoding="async"
                              className={nightMode ? "w-full h-auto object-contain relative opacity-0 transition-opacity duration-300 data-[loaded=true]:opacity-100" : "mix-blend-multiply w-full h-auto object-contain relative opacity-0 transition-opacity duration-300 data-[loaded=true]:opacity-100"}
                            />
                          </div>
                        </div>
                      )}
                      <div className="space-y-2 flex-1">
                        <div className="inline-flex items-center space-x-2 fill-gradient px-3 py-1 rounded-full text-white text-[10px] font-bold uppercase tracking-wider">
                          <span>EM ATÉ 420 MESES</span>
                        </div>
                        <h2 className="text-lg md:text-3xl font-bold text-neutral-900 dark:text-neutral-100 tracking-tight leading-snug">
                          Financie <span className="serif font-normal text-neutral-900 dark:text-neutral-100">seu imóvel.</span>
                        </h2>
                      </div>
                    </div>
                    <p className="text-sm md:text-base text-neutral-600 dark:text-neutral-400 leading-relaxed">
                      Imóveis com valores abaixo do mercado, com 35 anos para pagar. Buscamos as melhores
                      condições nos principais bancos do país.
                    </p>
                    <div className="pt-2">{renderButton("Ver imóveis financiados", "imoveis")}</div>
                  </div>
                  {isDesktop && (
                    <div className="flex w-full lg:w-5/12 relative justify-center mt-8 lg:mt-0">
                      <div className="relative w-full max-w-sm p-2 flex items-center justify-center z-0">
                        <div className={`absolute inset-0 ${animacao} blob-shadow flex items-center justify-center`}>
                          <svg
                            viewBox="0 0 200 200"
                            xmlns="http://www.w3.org/2000/svg"
                            className={`w-full h-full ${nightMode ? "fill-neutral-800" : "fill-neutral-100"}`}
                          >
                            <path
                              d="M48.2,-64.1C61.4,-53.4,70.1,-37.2,73.1,-20.1C76.1,-3,73.4,15,65,30.3C56.6,45.6,42.5,58.3,26,65.6C9.6,72.9,-9.2,74.8,-27.1,69.5C-45,64.3,-62.1,51.8,-70.6,35.1C-79.1,18.4,-79.1,-2.6,-73.2,-20.9C-67.4,-39.1,-55.8,-54.6,-40.8,-64.7C-25.8,-74.8,-7.4,-79.5,10.1,-78.9C27.6,-78.3,45.2,-72.4,48.2,-64.1Z"
                              transform="translate(100 100)"
                            />
                          </svg>
                        </div>
                        <img
                          src={nightMode ? "/assets/home/financiamentoimoveis-dark-960.webp" : "/assets/home/financiamentoimoveis-960.webp"}
                          width={960}
                          height={888}
                          {...revealOnLoad}
                          alt="Imóveis"
                          loading="lazy"
                          decoding="async"
                          className={nightMode ? "w-[90%] h-auto mx-auto object-contain relative opacity-0 transition-opacity duration-300 data-[loaded=true]:opacity-100" : "mix-blend-multiply w-[90%] h-auto mx-auto object-contain relative opacity-0 transition-opacity duration-300 data-[loaded=true]:opacity-100"}
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </section>
          );
        }

        if (link.href === "emprestimos") {
          return (
            <section
              key="emprestimos"
              id="emprestimos"
              className="py-10 md:py-12 bg-white dark:bg-neutral-950 border-b border-neutral-200 dark:border-neutral-800 overflow-hidden relative scroll-mt-16 rounded-none"
            >
              <div className="max-w-7xl mx-auto px-6 relative z-10">
                <div className={`flex flex-col ${layoutDirecao} items-center justify-between gap-8 lg:gap-12`}>
                  <div className="w-full lg:w-6/12 space-y-5">
                    <div className="flex flex-row items-center gap-4 -ml-2 sm:block sm:ml-0">
                      {!isDesktop && (
                        <div className="w-24 shrink-0 relative flex justify-start">
                          <div className={`absolute inset-0 ${animacao} blob-shadow flex items-center justify-center`}>
                            <svg
                              viewBox="0 0 200 200"
                              xmlns="http://www.w3.org/2000/svg"
                              className={`w-full h-full ${nightMode ? "fill-neutral-800" : "fill-neutral-100"}`}
                            >
                              <path
                                d="M42.2,-61.7C55,-54.6,65.8,-42.6,71.7,-28.4C77.5,-14.2,78.3,2.2,74.5,17.4C70.7,32.6,62.3,46.5,49.9,55.9C37.5,65.3,21.1,70.2,4.4,70.9C-12.4,71.7,-29.4,68.3,-43.3,59.8C-57.2,51.3,-68,37.6,-72.7,21.9C-77.4,6.2,-76,-11.5,-68.8,-26.3C-61.6,-41.1,-48.5,-53.1,-34.4,-59.5C-20.2,-65.9,-5.1,-66.7,10.2,-66.3C25.5,-65.9,39.4,-68.8,42.2,-61.7Z"
                                transform="translate(100 100)"
                              />
                            </svg>
                          </div>
                          <div className="relative w-full p-0 flex items-center justify-center z-0">
                            <img
                              src={nightMode ? "/assets/home/carhomeequity-dark-240.webp" : "/assets/home/carhomeequity-240.webp"}
                              width={240}
                              height={222}
                              {...revealOnLoad}
                              alt="Rentabilize Ativos"
                              loading="lazy"
                              decoding="async"
                              className={nightMode ? "w-full h-auto object-contain relative opacity-0 transition-opacity duration-300 data-[loaded=true]:opacity-100" : "mix-blend-multiply w-full h-auto object-contain relative opacity-0 transition-opacity duration-300 data-[loaded=true]:opacity-100"}
                            />
                          </div>
                        </div>
                      )}
                      <div className="space-y-2 flex-1">
                        <div className="inline-flex items-center space-x-2 fill-gradient px-3 py-1 rounded-full text-white text-[10px] font-bold uppercase tracking-wider">
                          <span>TAXAS MENORES</span>
                        </div>
                        <h2 className="text-lg md:text-3xl font-bold text-neutral-900 dark:text-neutral-100 tracking-tight leading-snug">
                          Seu carro ou imóvel <span className="serif font-normal text-neutral-900 dark:text-neutral-100">vira crédito.</span>
                        </h2>
                      </div>
                    </div>
                    <p className="text-sm md:text-base text-neutral-600 dark:text-neutral-400 leading-relaxed max-w-2xl">
                      Use seu carro ou imóvel como garantia e consiga um empréstimo com taxas menores e até 240x para
                      pagar. É um jeito de aproveitar novas oportunidades sem descapitalizar.
                    </p>
                    <div className="flex flex-col md:flex-row gap-4 w-full max-w-2xl">
                      {renderButton("Crédito com seu carro", "equityCarro")}
                      {renderButton("Crédito com seu imóvel", "equityImovel")}
                    </div>
                  </div>
                  {isDesktop && (
                    <div className="flex w-full lg:w-5/12 relative justify-center mt-8 lg:mt-0">
                      <div className="relative w-full max-w-sm p-2 flex items-center justify-center z-0">
                        <div className={`absolute inset-0 ${animacao} blob-shadow flex items-center justify-center`}>
                          <svg
                            viewBox="0 0 200 200"
                            xmlns="http://www.w3.org/2000/svg"
                            className={`w-full h-full ${nightMode ? "fill-neutral-800" : "fill-neutral-100"}`}
                          >
                            <path
                              d="M42.2,-61.7C55,-54.6,65.8,-42.6,71.7,-28.4C77.5,-14.2,78.3,2.2,74.5,17.4C70.7,32.6,62.3,46.5,49.9,55.9C37.5,65.3,21.1,70.2,4.4,70.9C-12.4,71.7,-29.4,68.3,-43.3,59.8C-57.2,51.3,-68,37.6,-72.7,21.9C-77.4,6.2,-76,-11.5,-68.8,-26.3C-61.6,-41.1,-48.5,-53.1,-34.4,-59.5C-20.2,-65.9,-5.1,-66.7,10.2,-66.3C25.5,-65.9,39.4,-68.8,42.2,-61.7Z"
                              transform="translate(100 100)"
                            />
                          </svg>
                        </div>
                        <img
                          src={nightMode ? "/assets/home/carhomeequity-dark-960.webp" : "/assets/home/carhomeequity-960.webp"}
                          width={960}
                          height={888}
                          {...revealOnLoad}
                          alt="Rentabilize Ativos"
                          loading="lazy"
                          decoding="async"
                          className={nightMode ? "w-[90%] h-auto mx-auto object-contain relative opacity-0 transition-opacity duration-300 data-[loaded=true]:opacity-100" : "mix-blend-multiply w-[90%] h-auto mx-auto object-contain relative opacity-0 transition-opacity duration-300 data-[loaded=true]:opacity-100"}
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </section>
          );
        }

        if (link.href === "floorplan") {
          return (
            <section
              key="floorplan"
              id="floorplan"
              className="py-10 md:py-12 bg-white dark:bg-neutral-950 border-b border-neutral-200 dark:border-neutral-800 overflow-hidden relative rounded-none"
            >
              <div className="max-w-7xl mx-auto px-6 relative z-10">
                <div className={`flex flex-col ${layoutDirecao} items-center justify-between gap-8 lg:gap-12`}>
                  <div className="w-full lg:w-6/12 space-y-5">
                    <div className="flex flex-row items-center gap-4 -ml-2 sm:block sm:ml-0">
                      {!isDesktop && (
                        <div className="w-24 shrink-0 relative flex justify-start">
                          <div className={`absolute inset-0 ${animacao} blob-shadow flex items-center justify-center`}>
                            <svg
                              viewBox="0 0 200 200"
                              xmlns="http://www.w3.org/2000/svg"
                              className={`w-full h-full ${nightMode ? "fill-neutral-800" : "fill-neutral-100"}`}
                            >
                              <path
                                d="M49.2,-65.8C62.7,-56.3,71.9,-39.9,75.1,-22.4C78.4,-4.9,75.7,13.7,68,30C60.3,46.3,47.5,60.2,31.7,68.4C15.8,76.6,-3.2,79.1,-21.8,75C-40.4,71,-58.6,60.3,-69.5,44.7C-80.4,29.1,-84,8.5,-80.7,-10.1C-77.4,-28.7,-67.2,-45.3,-52.9,-55.1C-38.6,-64.9,-20.2,-67.9,-1.2,-66.5C17.8,-65.1,35.6,-75.3,49.2,-65.8Z"
                                transform="translate(100 100)"
                              />
                            </svg>
                          </div>
                          <div className="relative w-full p-0 flex items-center justify-center z-0">
                            <img
                              src="/assets/home/floorplan-240.webp"
                              width={240}
                              height={222}
                              {...revealOnLoad}
                              alt="Floor Plan"
                              loading="lazy"
                              decoding="async"
                              className={nightMode ? "w-full h-auto object-contain relative opacity-0 transition-opacity duration-300 data-[loaded=true]:opacity-100" : "mix-blend-multiply w-full h-auto object-contain relative opacity-0 transition-opacity duration-300 data-[loaded=true]:opacity-100"}
                            />
                          </div>
                        </div>
                      )}
                      <div className="space-y-2 flex-1">
                        <div className="inline-flex items-center space-x-2 fill-gradient px-3 py-1 rounded-full text-white text-[10px] font-bold uppercase tracking-wider">
                          <span>Lojistas AutoArremate</span>
                        </div>
                        <h2 className="text-lg md:text-3xl font-bold text-neutral-900 dark:text-neutral-100 tracking-tight leading-snug">
                          Floor plan <span className="serif font-normal text-neutral-900 dark:text-neutral-100">com prazo de 90 dias.</span>
                        </h2>
                      </div>
                    </div>
                    <p className="text-sm md:text-base text-neutral-600 dark:text-neutral-400 leading-relaxed">
                      Você é lojista? Aproveite nossa linha de crédito exclusiva para a compra de veículos na nossa
                      plataforma com pagamento em até 90 dias.
                    </p>
                    <div className="pt-2">{renderButton("Ver condições", "floorPlan")}</div>
                  </div>
                  {isDesktop && (
                    <div className="flex w-full lg:w-5/12 relative justify-center mt-8 lg:mt-0">
                      <div className="relative w-full max-w-sm p-2 flex items-center justify-center z-0">
                        <div className={`absolute inset-0 ${animacao} blob-shadow flex items-center justify-center`}>
                          <svg
                            viewBox="0 0 200 200"
                            xmlns="http://www.w3.org/2000/svg"
                            className={`w-full h-full ${nightMode ? "fill-neutral-800" : "fill-neutral-100"}`}
                          >
                            <path
                              d="M49.2,-65.8C62.7,-56.3,71.9,-39.9,75.1,-22.4C78.4,-4.9,75.7,13.7,68,30C60.3,46.3,47.5,60.2,31.7,68.4C15.8,76.6,-3.2,79.1,-21.8,75C-40.4,71,-58.6,60.3,-69.5,44.7C-80.4,29.1,-84,8.5,-80.7,-10.1C-77.4,-28.7,-67.2,-45.3,-52.9,-55.1C-38.6,-64.9,-20.2,-67.9,-1.2,-66.5C17.8,-65.1,35.6,-75.3,49.2,-65.8Z"
                              transform="translate(100 100)"
                            />
                          </svg>
                        </div>
                        <img
                          src="/assets/home/floorplan-960.webp"
                          width={960}
                          height={888}
                          {...revealOnLoad}
                          alt="Floor Plan"
                          loading="lazy"
                          decoding="async"
                          className={nightMode ? "w-[90%] h-auto mx-auto object-contain relative opacity-0 transition-opacity duration-300 data-[loaded=true]:opacity-100" : "mix-blend-multiply w-[90%] h-auto mx-auto object-contain relative opacity-0 transition-opacity duration-300 data-[loaded=true]:opacity-100"}
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </section>
          );
        }

        if (link.href === "seguros") {
          return (
            <section
              key="seguros"
              id="seguros"
              className="py-10 md:py-12 bg-white dark:bg-neutral-950 overflow-hidden relative scroll-mt-16 rounded-none"
            >
              <div className="max-w-7xl mx-auto px-6 relative z-10">
                <div className={`flex flex-col ${layoutDirecao} items-center justify-between gap-8 lg:gap-12`}>
                  <div className="w-full lg:w-6/12 space-y-5">
                    <div className="flex flex-row items-center gap-4 -ml-2 sm:block sm:ml-0">
                      {!isDesktop && (
                        <div className="w-24 shrink-0 relative flex justify-start">
                          <div className={`absolute inset-0 ${animacao} blob-shadow flex items-center justify-center`}>
                            <svg
                              viewBox="0 0 200 200"
                              xmlns="http://www.w3.org/2000/svg"
                              className={`w-full h-full ${nightMode ? "fill-neutral-800" : "fill-neutral-100"}`}
                            >
                              <path
                                d="M41,-57C53.7,-49,64.9,-37.1,70.9,-22.4C76.9,-7.7,77.7,9.8,72.9,25.1C68.1,40.4,57.7,53.4,44.1,62C30.5,70.7,13.7,74.9,-1.9,77.5C-17.5,80.1,-35.1,81.1,-48.5,73.1C-61.9,65.1,-71.2,48.1,-75.4,30.3C-79.6,12.5,-78.7,-6.1,-72.6,-21.8C-66.5,-37.5,-55.2,-50.2,-41.2,-57.8C-27.2,-65.4,-10.6,-67.9,3,-72C16.6,-76.1,28.3,-65,41,-57Z"
                                transform="translate(100 100)"
                              />
                            </svg>
                          </div>
                          <div className="relative w-full p-0 flex items-center justify-center z-0">
                            <img
                              src={nightMode ? "/assets/home/seguros-dark-240.webp" : "/assets/home/seguros-240.webp"}
                              width={240}
                              height={222}
                              {...revealOnLoad}
                              alt="Proteção sbX"
                              loading="lazy"
                              decoding="async"
                              className={nightMode ? "w-full h-auto object-contain relative opacity-0 transition-opacity duration-300 data-[loaded=true]:opacity-100" : "mix-blend-multiply w-full h-auto object-contain relative opacity-0 transition-opacity duration-300 data-[loaded=true]:opacity-100"}
                            />
                          </div>
                        </div>
                      )}
                      <div className="space-y-2 flex-1">
                        <div className="inline-flex items-center space-x-2 fill-gradient px-3 py-1 rounded-full text-white text-[10px] font-bold uppercase tracking-wider">
                          <span>9 SEGURADORAS</span>
                        </div>
                        <h2 className="text-lg md:text-3xl font-bold text-neutral-900 dark:text-neutral-100 tracking-tight leading-snug">
                          Seu patrimônio <span className="serif font-normal text-neutral-900 dark:text-neutral-100">protegido.</span>
                        </h2>
                      </div>
                    </div>
                    <p className="text-sm md:text-base text-neutral-600 dark:text-neutral-400">
                      Compare seguros de 9 seguradoras direto na SBX Wallet e proteja seu carro ou imóvel contra
                      imprevistos.
                    </p>
                    <div className="bg-neutral-50 dark:bg-neutral-900 p-5 rounded-none border border-neutral-200 dark:border-neutral-800 flex flex-col gap-2 transition-colors hover:bg-neutral-100/50 dark:hover:bg-neutral-800/50">
                      <div className="flex items-center gap-2">
                        <Plus className="w-3.5 h-3.5 md:w-4 md:h-4 text-[#2246A7] shrink-0" strokeWidth={2} />
                        <h3 className="font-mono text-[11px] md:text-[13px] uppercase tracking-[0.18em] text-neutral-900 dark:text-neutral-100 mt-0.5">
                          Cotação on-line e sem compromisso
                        </h3>
                      </div>
                      <p className="text-neutral-600 dark:text-neutral-400 text-[13px] leading-relaxed mt-1">
                        Comprou ou já tem um carro ou imóvel? Simule em poucos minutos, sem burocracia e sem custo.
                      </p>
                    </div>
                    <div className="flex flex-col md:flex-row gap-4 w-full max-w-2xl">
                      {renderButton("Seguro residencial", "seguroResidencial")}
                      {renderButton("Seguro de veículos", "seguroAuto")}
                    </div>
                  </div>
                  {isDesktop && (
                    <div className="flex w-full lg:w-5/12 relative justify-center mt-8 lg:mt-0">
                      <div className="relative w-full max-w-sm p-2 flex items-center justify-center z-0">
                        <div className={`absolute inset-0 ${animacao} blob-shadow flex items-center justify-center`}>
                          <svg
                            viewBox="0 0 200 200"
                            xmlns="http://www.w3.org/2000/svg"
                            className={`w-full h-full ${nightMode ? "fill-neutral-800" : "fill-neutral-100"}`}
                          >
                            <path
                              d="M41,-57C53.7,-49,64.9,-37.1,70.9,-22.4C76.9,-7.7,77.7,9.8,72.9,25.1C68.1,40.4,57.7,53.4,44.1,62C30.5,70.7,13.7,74.9,-1.9,77.5C-17.5,80.1,-35.1,81.1,-48.5,73.1C-61.9,65.1,-71.2,48.1,-75.4,30.3C-79.6,12.5,-78.7,-6.1,-72.6,-21.8C-66.5,-37.5,-55.2,-50.2,-41.2,-57.8C-27.2,-65.4,-10.6,-67.9,3,-72C16.6,-76.1,28.3,-65,41,-57Z"
                              transform="translate(100 100)"
                            />
                          </svg>
                        </div>
                        <img
                          src={nightMode ? "/assets/home/seguros-dark-960.webp" : "/assets/home/seguros-960.webp"}
                          width={960}
                          height={888}
                          {...revealOnLoad}
                          alt="Proteção sbX"
                          loading="lazy"
                          decoding="async"
                          className={nightMode ? "w-[90%] h-auto mx-auto object-contain relative opacity-0 transition-opacity duration-300 data-[loaded=true]:opacity-100" : "mix-blend-multiply w-[90%] h-auto mx-auto object-contain relative opacity-0 transition-opacity duration-300 data-[loaded=true]:opacity-100"}
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </section>
          );
        }

        return null;
      })}

      {/* Rodapé Institucional Preto Grupo (#1D1D1B) */}
      <footer className="w-full py-10 mt-auto bg-[#1D1D1B] border-t border-neutral-800 text-white rounded-none">
        <div className="container mx-auto px-6 flex flex-col items-center gap-4 text-center">
          <img
            src="/assets/home/sbx-e-trade-white.png"
            alt="SBX e-trade"
            loading="lazy"
            decoding="async"
            className="h-16 w-16 md:h-20 md:w-20 object-contain"
          />
          <div className="flex flex-col gap-1 max-w-xl text-[11px] font-mono text-neutral-400">
            <p className="font-medium text-white">&copy; 2026 sbXPAY. Todos os direitos reservados.</p>
            <p className="leading-relaxed">
              sbXPAY Instituição de Pagamento Ltda. é uma instituição autorizada e regulada pelo Banco Central do
              Brasil.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}