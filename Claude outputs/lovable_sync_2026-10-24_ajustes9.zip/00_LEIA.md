# Ajustes 9 (2026-10-24) · tipos centrais (área 1 dos `any`)

Aplicar DEPOIS do ajustes8.

Só tipos do TypeScript: nada muda no que roda no navegador.

## Lovable: prompts na ordem
01 types.ts ... tipos centrais novos (aceites, regras, configs, FAQ, resposta do gateway, dados da jornada)
02 gateway.ts ... callSimulation e callOrchestrator com retorno tipado
03 WizardProvider.tsx ... wizard tipado com os dados da jornada
04 OrchestratorWrapper.tsx ... idem
05 FinancialHubContext.tsx ... contexto tipado
06 FinancialHubLayout.tsx ... renderHub tipado (inclui o ajustes8)
07 PanelFAQ.tsx ... aceita FAQ null
08 card.types.ts ... usa os tipos centrais
09 simulacao.types.ts ... usa os tipos centrais

Sem migration e sem deploy de função.
