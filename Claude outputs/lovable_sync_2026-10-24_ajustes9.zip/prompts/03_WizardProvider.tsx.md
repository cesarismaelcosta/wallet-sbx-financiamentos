Substitua todo o conteúdo de o arquivo `src/features/financial-hub/components/shared/WizardProvider.tsx` com exatamente o conteúdo abaixo. Não altere nada além deste arquivo e não rode formatação.

```
/**
 * @fileoverview Componente: WizardProvider
 * @path src/features/financial-hub/components/shared/WizardProvider.tsx
 * * @description Provedor de contexto global com a API completa de motor de jornada (Engine).
 */

import React, { createContext, useContext, useState, useEffect, useCallback, useMemo, ReactNode } from "react";
import { HubData } from "@/features/financial-hub/components/shared/types";

// 1. Tipagens do Estado
export interface WizardState<T = HubData> {
  isReady?: boolean;
  meta: {
    step: number;
    [key: string]: unknown;
  };
  data: HubData & T;
}

// 2. Tipagens do Contrato (API exposta pelo hook)
export interface WizardContextValue<T = HubData> {
  state: WizardState<T>;
  update: (patch: Partial<WizardState<T>>) => void;
  updateData: (dataPatch: Partial<WizardState<T>["data"]>) => void;
  goTo: (step: number) => void;
  next: () => void;
  back: () => void;
  reset: (initialData?: Partial<HubData>) => void;
}

const WizardContext = createContext<WizardContextValue | undefined>(undefined);

// 3. Provedor
export function WizardProvider({ children, initialData = {} }: { children: ReactNode; initialData?: Partial<HubData> }) {
  const [state, setState] = useState<WizardState>({
    isReady: false,
    meta: { step: 1 },
    data: { page_configs: {}, ...initialData },
  });

  /**
   * CORREÇÃO DE CICLO DE VIDA (Async Hydration):
   * Garante que se o 'initialData' mudar (por exemplo, quando o Gateway termina de 
   * buscar o simData da API), o estado do Wizard seja atualizado em tempo de execução.
   */
  useEffect(() => {
    if (initialData && Object.keys(initialData).length > 0) {
      setState((s) => ({
        ...s,
        isReady: true,
        data: {
          ...s.data,
          ...initialData,
        },
      }));
    }
  }, [initialData]);

  // Atualiza partes mescladas do estado completo
  const update: WizardContextValue["update"] = useCallback((patch) => {
    setState((s) => ({
      ...s,
      ...patch,
      meta: { ...s.meta, ...(patch.meta || {}) },
      data: { ...s.data, ...(patch.data || {}) },
    }));
  }, []);

  const updateData: WizardContextValue["updateData"] = useCallback((dataPatch) => {
    setState((s) => ({ ...s, data: { ...s.data, ...dataPatch } }));
  }, []);

  const goTo: WizardContextValue["goTo"] = useCallback((step) => {
    setState((s) => ({ ...s, meta: { ...s.meta, step } }));
  }, []);

  const next: WizardContextValue["next"] = useCallback(() => {
    setState((s) => ({ ...s, meta: { ...s.meta, step: s.meta.step + 1 } }));
  }, []);

  const back: WizardContextValue["back"] = useCallback(() => {
    setState((s) => ({ ...s, meta: { ...s.meta, step: Math.max(1, s.meta.step - 1) } }));
  }, []);

  const reset: WizardContextValue["reset"] = useCallback((initial = {}) => {
    setState({ isReady: true, meta: { step: 1 }, data: { page_configs: {}, ...initial } });
  }, []);

  // 🧹 Memoização do value inteiro. Evita que todo componente filho re-renderize
  // só porque o Provider foi reavaliado (mesmo padrão de FinancialAuthContext.tsx).
  const contextValue = useMemo(
    () => ({ state, update, updateData, goTo, next, back, reset }),
    [state, update, updateData, goTo, next, back, reset],
  );

  return (
    <WizardContext.Provider value={contextValue}>
      {children}
    </WizardContext.Provider>
  );
}

// 4. Hook de Consumo Seguro
export const useWizard = <T = HubData>() => {
  const context = useContext(WizardContext);
  if (!context) {
    throw new Error("useWizard deve ser utilizado dentro de um WizardProvider");
  }
  return context as unknown as WizardContextValue<T>;
};
```
