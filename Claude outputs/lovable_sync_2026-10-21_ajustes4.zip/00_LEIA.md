# Ajustes 4 (2026-10-21) · cabeçalho dos e-mails

## 1. Imagem (dev e homol)
imagem/wallet-sbx-header-email.png → bucket `logos`, com esse mesmo nome.
Se já existir uma versão antiga lá, substitua.

## 2. Lovable: prompts 01 a 05, na ordem
01 credit-card-notifications.ts ... cabeçalho = imagem branca com a logo (960x114)
02 flowcredi-notifications.ts ..... idem
03 fandi-notifications.ts ......... idem
04 partner-notifications.ts ....... idem (2 e-mails)
05 _shared/alert.ts ............... idem

Em todos: altura reservada (sem "pulo") e texto "Wallet sbX" no lugar do ícone
enquanto a imagem carrega.

## 3. Deploy
Suba a imagem ANTES do deploy (senão o e-mail sai sem logo).
financial-gateway, notification-gateway e notification-system-message
(as duas últimas usam _shared/alert.ts)
