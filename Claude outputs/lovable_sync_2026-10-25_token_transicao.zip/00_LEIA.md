# Token de transição (2026-10-25)

Aplicar depois do tipos_functions.

Só tipo: userName e login passam a ser opcionais no token de transição
(o sbx-auth-exchange não os envia). Zera o último erro de tipo.

## Lovable: prompts
01 _shared/jwt.ts

## Deploy
Todas as edge functions que usam jwt.ts (gate, sbx-auth, sbx-auth-exchange e as protegidas por sessão).

Sem migration.
