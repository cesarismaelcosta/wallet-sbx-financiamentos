# Ponte /gate para o botão da Superbid (2026-11-14)

NÃO aplicar os zips lovable_sync_2026-11-13_gate_superbid (v1 e v2): foram substituídos por este.

A Superbid passa a postar o formulário do "Simular financiamento" em `<app>/gate`. A ponte guarda os
campos na própria aba e o NAVEGADOR chama o `financial-gateway-gate` (modo AJAX): o IP gravado é o do
usuário, o endereço do Supabase não aparece para a Superbid nem na barra, e não há chave nova.

O que muda:
- `src/routes/gate.ts` (novo): POST /gate só aceita origem do próprio app ou de `superbid.net`
  (lista em `src/config/routes.ts`), resposta sem cache, sem iframe (X-Frame-Options: DENY);
  GET /gate mostra o skeleton da jornada, chama o gate, grava a sessão e abre a jornada
  (ou a tela de erro, que volta para a oferta).
- `src/config/routes.ts`: `PARTNER_ORIGIN_DOMAINS = ["superbid.net"]`.
- `PanelHeader.tsx`: modo skeleton (`authPlaceholder`): logo e menu apagados e sem clique,
  sol funcionando, círculo azul claro no lugar do avatar, linha preta de carregamento.
- `FinancialHubLayout.tsx`: skeleton com o mesmo container/grade das jornadas; skeleton mantido
  enquanto a visita carrega (corpo não fica vazio); menu das jornadas em constante única.
- Sandbox: botão "Ponte /gate (Nova Aba)" nos cards de oferta; perfil recarregado após F5.

## Lovable: prompts (na ordem)
01 src/routes/gate.ts (arquivo novo)
02 src/config/routes.ts
03 PanelHeader.tsx
04 FinancialHubLayout.tsx
05 src/routes/sandbox.lazy.tsx

Sem Edge Function, sem deploy de função, sem secret, sem migration.

## Teste em homol
Sandbox (logado no Lovable) > card de oferta aberta > "Ponte /gate (Nova Aba)":
skeleton > jornada logada, sem tela branca e sem o cabeçalho "andar".
F5 no Sandbox: o card "Perfil Carregado da sbX" preenche de novo.

## Observações
- Tipos: `npx tsc --noEmit` sem erros nos arquivos deste zip (os 14 erros restantes são da
  pasta protegida do design system, pré-existentes).
- Superbid em produção: postar em `https://<domínio do app>/gate` (código do botão no manual).
