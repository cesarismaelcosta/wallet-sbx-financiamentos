# Ajustes 12 (2026-10-24) · área 3 dos `any` (painéis compartilhados)

Aplicar DEPOIS do ajustes11.

Só tipos do TypeScript: nada muda no que roda no navegador.

## Lovable: prompts na ordem
01 SliderCustomizado.tsx ... 2 trocas pontuais
02 icons-map.ts ... arquivo inteiro
03 renderes/CardOfferV.tsx ... 6 trocas pontuais
04 renderes/ChartsSimulation.tsx ... arquivo inteiro
05 renderes/ChartsTraffic.tsx ... arquivo inteiro
06 renderes/PanelAcceptedConsents.tsx ... arquivo inteiro
07 renderes/PanelConsents.tsx ... arquivo inteiro
08 renderes/PanelEntity.tsx ... arquivo inteiro
09 renderes/PanelFlowcredi.tsx ... arquivo inteiro
10 renderes/PanelFooter.tsx ... arquivo inteiro
11 renderes/PanelOffer.tsx ... arquivo inteiro
12 renderes/PanelProduct.tsx ... arquivo inteiro
13 renderes/PanelSeller.tsx ... arquivo inteiro
14 renderes/PanelSimulation.tsx ... arquivo inteiro
15 renderes/PanelVisit.tsx ... arquivo inteiro
16 types.ts ... arquivo inteiro

Sem migration e sem deploy de função.
