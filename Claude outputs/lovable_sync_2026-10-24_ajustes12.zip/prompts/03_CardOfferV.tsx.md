Edite só o arquivo `src/features/financial-hub/components/shared/renderes/CardOfferV.tsx`. Faça apenas as trocas abaixo, exatamente como estão, sem alterar mais nada e sem rodar formatação.

### Troca 1
Troque:

```
interface CardOfferVProps {
  item: any;
```

por:

```
/** Oferta como vem da busca de ofertas da Superbid (campos usados no card). */
interface CardOfferData {
  offer_id?: string | number;
  offer_description?: string;
  offer_value?: number;
  offer_type_id?: number;
  is_shopping?: boolean;
  lot_number?: string | number;
  price_formatted?: string;
  system_metric?: string;
  photos?: { link?: string; highlight?: boolean }[];
  location?: { city?: string; state?: string };
  offer_status?: { sold?: boolean };
  offer_status_sold?: boolean;
  [key: string]: unknown;
}

/** Evento (leilão) da oferta. */
interface CardEventData {
  event_end_date?: string;
  modality_id?: number;
  modality_desc?: string;
  [key: string]: unknown;
}

/** Item da lista de ofertas: oferta + evento + vendedor. */
export interface CardOfferItem {
  offer?: CardOfferData;
  event?: CardEventData;
  seller?: { trade_name?: string; [key: string]: unknown };
  is_simulated?: boolean;
  [key: string]: unknown;
}

interface CardOfferVProps {
  item: CardOfferItem;
```

### Troca 2
Troque:

```
  onSimulate: (item: any, idx: number) => void;
```

por:

```
  onSimulate: (item: CardOfferItem, idx: number) => void;
```

### Troca 3
Troque:

```
const getSuperbidUrl = (offerData: any) => {
```

por:

```
const getSuperbidUrl = (offerData: CardOfferData | undefined) => {
```

### Troca 4
Troque:

```
const getOfferCategory = (offerData: any, eventData: any, formattedDate: string): OfferCategory => {
```

por:

```
const getOfferCategory = (offerData: CardOfferData, eventData: CardEventData, formattedDate: string): OfferCategory => {
```

### Troca 5
Troque:

```
      .sort((a: any, b: any) => (a.highlight === b.highlight ? 0 : a.highlight ? -1 : 1))
      .map((p: any) => p.link);
```

por:

```
      .sort((a, b) => (a.highlight === b.highlight ? 0 : a.highlight ? -1 : 1))
      .map((p) => p.link);
```

### Troca 6
Troque:

```
  const offerData = item.offer || {};
  const eventData = item.event || {};
```

por:

```
  const offerData: CardOfferData = item.offer || {};
  const eventData: CardEventData = item.event || {};
```
