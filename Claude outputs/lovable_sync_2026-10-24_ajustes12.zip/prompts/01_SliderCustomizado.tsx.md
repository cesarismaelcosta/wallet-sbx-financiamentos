Edite só o arquivo `src/features/financial-hub/components/shared/SliderCustomizado.tsx`. Faça apenas as trocas abaixo, exatamente como estão, sem alterar mais nada e sem rodar formatação.

### Troca 1
Troque:

```
export const SliderCustomizado = ({ 
```

por:

```
interface SliderCustomizadoProps {
  value: number | null | undefined;
  onValueChange?: (value: number) => void;
  onValueCommit?: (value: number) => void;
  min?: number | null;
  max?: number | null;
  step?: number;
  isCurrency?: boolean;
  disabled?: boolean;
  active?: boolean;
}

export const SliderCustomizado = ({ 
```

### Troca 2
Troque:

```
}: any) => {
```

por:

```
}: SliderCustomizadoProps) => {
```
