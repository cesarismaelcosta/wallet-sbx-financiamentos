# FlowCredi: padrões do app, Car Equity e telas (2026-11-20 · v2)

Aplicar DEPOIS do zip `lovable_sync_2026-11-20_flowcredi_processos` (já aplicado em homol).
Este zip corrige o que saiu fora do padrão e traz os ajustes feitos nos testes em dev.

## O que muda

Padrões do app
- Sem chaves com nome de parceiro: sai `flowcredi_product` (o parceiro 3 é roteado pelo produto:
  1 Imóveis, 6 Home Equity, 7 Car Equity); sai `flowcredi_bank_by_seller` (banco fixo por vendedor =
  linha SELLER no orchestrator com `rules.fixed_bank`); `flowcredi_bank` vira `fixed_bank`;
  `flowcredi_type` vira `terms_type` nos aceites.
- Limites só no `rules` (Imóveis: faixa de valor; Home Equity: percentual por tipo, tipos bloqueados,
  mínimos; Car Equity: elegibilidade). Telas e servidor leem de lá.
- Nomes no padrão: webhook `financial-gateway-webhook/flowcredi-service.ts` (como `fandi-service.ts`);
  utilitário genérico `shared/partner-terms.ts`; vocabulário "lead" no serviço (`sendLead`, `maskLead`).
- Modal de termos genérico: "Texto oficial · versão X", sem nome de parceiro fixo.

Telas
- Imóveis e Home Equity: rótulos com * e rodapé no fim do box.
- Car Equity tela 1: só placa, UF de licenciamento e ano de fabricação (como no site da FlowCredi);
  rodapé com a elegibilidade (ano mínimo e UFs aceitas, vindos do `rules`).
- Car Equity tela 2: bancos em ordem alfabética, "Outros" abre "Qual banco?"; valor mínimo do veículo.
- Régua de passos sem o "5" vazio; Car Equity com "70 meses" nos textos.
- Lista de imóveis: tag "Fora da faixa" (sem botão) fora da faixa de valor do `rules`.
- Backoffice (rotas): editor de termos com tipo de link "Termo oficial (API)" (URL) e campo
  "Tipo do termo (API)".

Servidor
- Imóveis: cidade "Santo André - SP" com UF vazia vira cidade + UF.

## Lovable: prompts (na ordem)
01–05 Edge Function `financial-gateway`
06–07 Edge Function `financial-gateway-webhook` (06 é arquivo novo)
08–21 Telas e backoffice (09 é arquivo novo)
22 Apagar os 2 arquivos renomeados
23 SQL de configuração (só dados em `orchestrator_configs`)
24 Deploy das duas funções

Sem migration. Sem secret nova.

## Teste em homol
1. Imóveis: simular e enviar; abrir os termos (modal "Texto oficial · versão X").
2. Home Equity: Sala Comercial (limite 40%), Galpão (bloqueado), envio.
3. Car Equity: tela 1 só com placa, UF e ano; ano 2014 não libera; envio com veículo não quitado
   e banco "Outros".
4. Lista de imóveis: imóvel abaixo de R$ 50 mil com a tag "Fora da faixa".
5. Backoffice > rotas > config de Imóveis: termos mostram "Termo oficial (API)" e o tipo do termo.

## Observações
- Tipos: rodar `npx tsc --noEmit` antes de aplicar (telas não verificadas com tsc completo).
- Os ids dos aceites continuam `flowcredi_politica_privacidade` etc.: são os termos da FlowCredi
  (dado), não chave de regra.
