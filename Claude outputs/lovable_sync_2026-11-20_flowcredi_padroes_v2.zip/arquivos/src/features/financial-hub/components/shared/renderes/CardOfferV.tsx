/**
 * @fileoverview Componente de apresentação: CardOfferV (Vertical)
 * @path src/features/financial-hub/components/shared/renderers/CardOfferV.tsx
 * @version 2.1.0
 *
 * ============================================================================
 * 🤖 GEMINI ARCHITECTURE SPECIFICATION: SWIPE & IMAGE ERROR HANDLING
 * ============================================================================
 *
 * [EVOLUÇÃO v2.1.0 - TOUCH SWIPE E PREVENÇÃO DE FALSOS POSITIVOS]:
 * 1. {Ref-based Swipe}: Substituição de `useState` por `useRef` (touchStartX/EndX)
 *    durante o evento de `onTouchMove`. Isso evita a re-renderização frenética
 *    a 60fps que abortava o I/O da tag <img> e causava falsos `onError`.
 * 2. {Unbreakable Arrows}: Os controles do carrossel (< e >) foram desvinculados
 *    do estado genérico de erro (`!hasError`). Se há >1 foto, as setas
 *    aparecem sempre, garantindo a navegabilidade mesmo se uma URL quebrar.
 * 3. {Error Reset}: O estado `imageError` é resetado para `false` a cada
 *    mudança de slide, permitindo que a próxima imagem tente renderizar limpa.
 * 4. {DOM Keying}: Adição do atributo `key={mainPhoto}` na <img> para forçar
 *    o reconciler do React a destruir e recriar a tag em cada troca de foto,
 *    evitando travamento do browser em imagens corrompidas.
 * 5. {Pan Lock}: Adição da classe Tailwind `touch-pan-y` no container do carrossel
 *    para evitar que a página inteira se mova indesejadamente durante o arrasto.
 *
 * REGRAS DO SEMÁFORO DE MODALIDADE (ModalityTag):
 * - MERCADO BALCÃO / COMPRE JÁ (offerTypeId 8, 9, 10 + isShopping): Fundo rosado.
 * - TOMADA DE PREÇO (modalityId 5): Fundo azul gelo.
 * - LEILÃO TRADICIONAL (offerTypeId 1): Fundo laranja claro + Data Fim.
 *
 * [NEUTRAL PURITY]: Paleta migrada de tokens semanticos vivos (bg-card/text-foreground/bg-primary/bg-muted/border-border) para tons
 * neutros fixos do Tailwind. Motivo: este card e renderizado em rota de cliente (produtos.offer) e nao pode
 * herdar o dark mode ativado via localStorage["sbx-theme"] pelo ThemeToggle do backoffice -- o card fica
 * imune ao tema, igual ao restante dos componentes do financial-hub.
 *
 * [ERROR STATE v2.2.0]: Nova prop `hasError` (setada pelo pai apos falha na simulação)
 * substitui o botão por uma barra que se preenche em 5s (progresso passivo de auto-retorno,
 * sem cor de erro -- mesma convenção neutra do resto do app) com um link "Tentar novamente"
 * que já dispara `onSimulate` de novo, cancelando o preenchimento.
 *
 * @author Cesar Ismael Pereira da Costa
 * @author Gemini Pro
 */

import React, { useState, useRef, useMemo, useEffect } from "react";
import {
  MapPin,
  ArrowLeft,
  ArrowRight,
  ExternalLink,
  Gavel,
  Mail,
  Tag,
  Handshake,
  Plus,
  Loader2,
  TriangleAlert,
} from "lucide-react";
import { Button } from "@/components/ui/button";

// =========================================================================
// [INTERFACES E HELPERS]
// =========================================================================
/** Oferta como vem da busca de ofertas da Superbid (campos usados no card). */
interface CardOfferData {
  offer_id?: string | number;
  offer_description?: string;
  offer_value?: number;
  offer_type_id?: number;
  is_shopping?: boolean;
  lot_number?: string | number;
  price_formatted?: string;
  system_metric?: string;
  photos?: { link?: string; highlight?: boolean }[];
  location?: { city?: string; state?: string };
  offer_status?: { sold?: boolean };
  offer_status_sold?: boolean;
  [key: string]: unknown;
}

/** Evento (leilão) da oferta. */
interface CardEventData {
  event_end_date?: string;
  modality_id?: number;
  modality_desc?: string;
  [key: string]: unknown;
}

/** Item da lista de ofertas: oferta + evento + vendedor. */
export interface CardOfferItem {
  offer?: CardOfferData;
  event?: CardEventData;
  seller?: { trade_name?: string; [key: string]: unknown };
  is_simulated?: boolean;
  [key: string]: unknown;
}

interface CardOfferVProps {
  item: CardOfferItem;
  idx: number;
  isCartao: boolean;
  loading: boolean;
  disabled?: boolean;
  hasError?: boolean;
  onErrorTimeout?: () => void;
  onSimulate: (item: CardOfferItem, idx: number) => void;
  /** Faixa de valor financiável do produto (vem do `rules` da config). Fora dela: selo "Fora da faixa" e sem botão. */
  valueRange?: { min?: number; max?: number };
}

const getSuperbidUrl = (offerData: CardOfferData | undefined) => {
  if (!offerData?.offer_id) return "#";
  const slug = (offerData.offer_description || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
  return `https://www.superbid.net/oferta/${slug}-${offerData.offer_id}`;
};

const formatEventDate = (dateString?: string) => {
  if (!dateString) return "—";
  try {
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return "—";
    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const hours = String(date.getHours()).padStart(2, "0");
    const minutes = String(date.getMinutes()).padStart(2, "0");
    return `${day}/${month} - ${hours}:${minutes}`;
  } catch {
    return "—";
  }
};

// =========================================================================
// [CLASSIFICAÇÃO DA OFERTA]: fonte única, usada pela tag E pelo painel de
// preço -- antes cada um tinha sua própria condição escrita à mão
// (isLeilao/isTomadaDePreco no componente principal vs. os ifs do
// ModalityTag) e podiam discordar entre si quando `is_shopping` chegava
// `null`/`undefined` em vez de `false`, mostrando uma tag "Tomada de preço"
// junto com o rótulo de preço errado, por exemplo.
// =========================================================================
type OfferCategory =
  | "compre_ja_balcao"
  | "compre_ja"
  | "mercado_balcao"
  | "tomada_de_preco"
  | "leilao_tradicional"
  | "sem_categoria";

const getOfferCategory = (offerData: CardOfferData, eventData: CardEventData, formattedDate: string): OfferCategory => {
  if (offerData?.is_shopping === true) {
    if (offerData.offer_type_id === 10) return "compre_ja_balcao";
    if (offerData.offer_type_id === 8) return "compre_ja";
    return "mercado_balcao";
  }
  if (eventData?.modality_id === 5 || eventData?.modality_desc === "Tomada de preço") {
    return "tomada_de_preco";
  }
  if (formattedDate === "—") return "sem_categoria";
  return "leilao_tradicional";
};

// =========================================================================
// [COMPONENTE SECUNDÁRIO]: ModalityTag
// =========================================================================
function ModalityTag({ category, formattedDate }: { category: OfferCategory; formattedDate: string }) {
  switch (category) {
    case "compre_ja_balcao":
      return (
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-none text-[11px] font-semibold bg-rose-100 text-[#003B73]">
          <Handshake size={13} className="text-slate-700" strokeWidth={2.5} />
          <Plus size={10} className="text-slate-700" strokeWidth={3} />
          <Tag size={13} className="text-slate-700" strokeWidth={2.5} />
          <span className="tracking-tight">Mercado Balcão ou Compre Já</span>
        </div>
      );
    case "compre_ja":
      return (
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-none text-[11px] font-semibold bg-rose-100 text-[#003B73]">
          <Tag size={13} className="text-slate-700" strokeWidth={2.5} />
          <span className="tracking-tight">Compre já</span>
        </div>
      );
    case "mercado_balcao":
      return (
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-none text-[11px] font-semibold bg-rose-100 text-[#003B73]">
          <Handshake size={13} className="text-slate-700" strokeWidth={2.5} />
          <span className="tracking-tight">Mercado Balcão</span>
        </div>
      );
    case "tomada_de_preco":
      return (
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-none text-[11px] font-semibold bg-sky-100 text-[#003B73]">
          <Mail size={13} className="text-slate-700" strokeWidth={2.5} />
          <span className="tracking-tight">Tomada de preço</span>
        </div>
      );
    case "leilao_tradicional":
      return (
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-none text-[11px] font-semibold bg-orange-100 text-[#003B73]">
          <Gavel size={13} className="text-slate-700" strokeWidth={2.5} />
          <span className="tracking-tight">{formattedDate}</span>
        </div>
      );
    default:
      return <div />;
  }
}

// =========================================================================
// [COMPONENTE PRINCIPAL]: CardOfferV
// =========================================================================
function CardOfferVComponent({ item, idx, isCartao, loading, disabled, hasError: hasSimulationError, onErrorTimeout, onSimulate, valueRange }: CardOfferVProps) {
  const offerData: CardOfferData = item.offer || {};
  const eventData: CardEventData = item.event || {};
  const sellerData = item.seller || {};

  // -------------------------------------------------------------------------
  // ESTADO LOCAL: CONTROLE DO CARROSSEL
  // -------------------------------------------------------------------------
  const [photoIndex, setPhotoIndex] = useState(0);
  const [imageError, setImageError] = useState(false);

  // -------------------------------------------------------------------------
  // ESTADO LOCAL: PREENCHIMENTO PASSIVO DO ESTADO DE ERRO (auto-retorno em 5s)
  // -------------------------------------------------------------------------
  const [fillProgress, setFillProgress] = useState(0);

  const fillRaf2Ref = useRef<number | null>(null);

  useEffect(() => {
    if (!hasSimulationError) {
      setFillProgress(0);
      return;
    }
    setFillProgress(0);
    // Duplo rAF: garante que o browser pinte o estado em 0% ANTES de setar
    // 100%, senão a transição CSS de width não anima (parte já "cheia").
    const raf1 = requestAnimationFrame(() => {
      fillRaf2Ref.current = requestAnimationFrame(() => setFillProgress(100));
    });
    const timer = setTimeout(() => {
      onErrorTimeout?.();
    }, 5000);
    return () => {
      cancelAnimationFrame(raf1);
      if (fillRaf2Ref.current !== null) cancelAnimationFrame(fillRaf2Ref.current);
      clearTimeout(timer);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hasSimulationError]);

  // ✨ [SWIPE CONTROL]: Referências para rastreio touch (Zero Re-render)
  const touchStartX = useRef<number | null>(null);
  const touchEndX = useRef<number | null>(null);

  // 🚀 [PERFORMANCE]: antes rodava (sort + map) em TODA renderização do card,
  // inclusive nas que nada têm a ver com fotos (troca de slide via swipe,
  // reset de `imageError`). Como `offerData.photos` só muda quando o item em
  // si muda, memoiza por essa dependência.
  const sortedPhotos = useMemo(() => {
    const rawPhotos = offerData.photos || [];
    return [...rawPhotos]
      .sort((a, b) => (a.highlight === b.highlight ? 0 : a.highlight ? -1 : 1))
      .map((p) => p.link);
  }, [offerData.photos]);

  const mainPhoto =
    sortedPhotos.length > 0
      ? sortedPhotos[photoIndex % sortedPhotos.length]
      : "https://placehold.co/300x200?text=Sem+Foto";
  const hasError = imageError || !sortedPhotos.length;

  // ✨ [ACTION]: Avançar e Recuar limpando estado de erro anterior
  // (guard de `sortedPhotos.length === 0` evita `(prev ± 1) % 0` -> NaN
  // preso no estado, caso o swipe dispare numa foto sem álbum)
  const handleNextPhoto = (e?: React.SyntheticEvent) => {
    if (e) e.stopPropagation();
    if (sortedPhotos.length === 0) return;
    setPhotoIndex((prev) => (prev + 1) % sortedPhotos.length);
    setImageError(false);
  };

  const handlePrevPhoto = (e?: React.SyntheticEvent) => {
    if (e) e.stopPropagation();
    if (sortedPhotos.length === 0) return;
    setPhotoIndex((prev) => (prev - 1 + sortedPhotos.length) % sortedPhotos.length);
    setImageError(false);
  };

  // -------------------------------------------------------------------------
  // MÓDULO DE INTERATIVIDADE TOUCH (SWIPE)
  // -------------------------------------------------------------------------
  const minSwipeDistance = 40;

  const onTouchStart = (e: React.TouchEvent) => {
    touchEndX.current = null;
    touchStartX.current = e.targetTouches[0].clientX;
  };

  const onTouchMove = (e: React.TouchEvent) => {
    touchEndX.current = e.targetTouches[0].clientX;
  };

  const onTouchEnd = () => {
    // `=== null` (não `!valor`) -- um swipe começando/terminando exatamente
    // no pixel x=0 é uma posição válida, e `!0` seria `true` por engano.
    if (touchStartX.current === null || touchEndX.current === null) return;
    const distance = touchStartX.current - touchEndX.current;

    if (distance > minSwipeDistance) handleNextPhoto();
    else if (distance < -minSwipeDistance) handlePrevPhoto();
  };

  // -------------------------------------------------------------------------
  // PREPARAÇÃO DE DADOS VIZUAIS
  // -------------------------------------------------------------------------
  const city = offerData.location?.city || "";
  const state = offerData.location?.state || "";
  const locationDisplay = city.includes(" - ") ? city : [city, state].filter(Boolean).join(" - ");
  const offerDesc = offerData.offer_description || "Produto sem descrição";
  const sellerName = sellerData.trade_name;

  const formattedDate = formatEventDate(eventData.event_end_date);
  const offerCategory = getOfferCategory(offerData, eventData, formattedDate);
  const isLeilao = offerCategory === "leilao_tradicional";
  const isTomadaDePreco = offerCategory === "tomada_de_preco";

  let priceLabel = "Valor de venda:";
  if (isLeilao) priceLabel = "Lance atual:";
  else if (isTomadaDePreco) priceLabel = "Valor de referência:";
  else if (offerData.is_shopping === true) priceLabel = "Valor de venda por unidade:";

  const priceFormatted =
    offerData.price_formatted ||
    `R$ ${(offerData.offer_value || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`;
  const showMetric = !isLeilao && !isTomadaDePreco && !!offerData.system_metric;

  // Oferta vendida (a busca da Superbid lista algumas mesmo com searchType=opened, ex.: Mercado Balcão):
  // selo "Vendido", foto em cinza, preço riscado e sem botão de simular (espaço mantido para alinhar o grid).
  const isSold = Boolean(offerData.offer_status?.sold ?? offerData.offer_status_sold);
  // Valor fora da faixa financiável do produto: selo "Fora da faixa" e sem botão (mesmo espaço do vendido)
  const offerValue = Number(offerData.offer_value ?? 0);
  const isOutOfRange =
    !isSold && !!valueRange && offerValue > 0 &&
    ((!!valueRange.min && offerValue < valueRange.min) || (!!valueRange.max && offerValue > valueRange.max));

  return (
    <div className="rounded-none border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 overflow-hidden shadow-xs hover:shadow-md transition-shadow flex flex-col justify-between group">
      <div className="flex flex-col h-full">
        {/* ================================================================ */}
        {/* RENDERIZAÇÃO DA MÍDIA (CARROSSEL)                                */}
        {/* ================================================================ */}
        <div
          className="relative h-44 w-full bg-neutral-100 dark:bg-neutral-800 overflow-hidden shrink-0 rounded-none touch-pan-y"
          onTouchStart={onTouchStart}
          onTouchMove={onTouchMove}
          onTouchEnd={onTouchEnd}
        >
          {hasError ? (
            <div className="absolute inset-0 bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center text-neutral-500 dark:text-neutral-400 text-xs font-bold uppercase tracking-wider">
              Foto Indisponível
            </div>
          ) : (
            <img
              key={mainPhoto}
              src={mainPhoto}
              alt={offerDesc}
              loading="lazy"
              decoding="async"
              width="400"
              height="300"
              className={`h-full w-full object-cover transition-opacity duration-300 ${isSold ? "grayscale opacity-70" : ""}`}
              onError={() => setImageError(true)}
            />
          )}

          <span className="absolute bottom-2 left-2 bg-neutral-900/80 backdrop-blur-sm text-white font-mono text-[9px] font-light uppercase tracking-[0.18em] px-2 py-1 rounded-none z-10">
            Lote #{offerData.lot_number || offerData.offer_id}
          </span>

          {isSold && (
            <span className="absolute top-2 right-2 bg-[#2246A7] text-white font-mono text-[9px] font-light uppercase tracking-[0.18em] px-2 py-1 rounded-none z-10">
              Vendido
            </span>
          )}

          {isOutOfRange && (
            <span className="absolute top-2 right-2 bg-[#2246A7] text-white font-mono text-[9px] font-light uppercase tracking-[0.18em] px-2 py-1 rounded-none z-10">
              Fora da faixa
            </span>
          )}

          {item.is_simulated && (
            <span className="absolute bottom-2 right-2 bg-white dark:bg-neutral-900 text-neutral-900 dark:text-neutral-100 text-[10px] font-normal px-2.5 py-0.5 rounded-none z-10 shadow lowercase">
              com simulação
            </span>
          )}

          {/* ✨ [UNBREAKABLE ARROWS]: Mostra os botões se houver mais de uma foto, ignorando erros da imagem atual */}
          {sortedPhotos.length > 1 && (
            <>
              <button
                type="button"
                onClick={handlePrevPhoto}
                aria-label="Foto anterior"
                className="absolute left-2 top-1/2 -translate-y-1/2 bg-neutral-900/40 hover:bg-neutral-900/60 backdrop-blur-sm text-white p-1.5 rounded-none transition-all opacity-100 sm:opacity-0 sm:group-hover:opacity-100 cursor-pointer border-none z-20"
              >
                <ArrowLeft size={16} strokeWidth={1.5} />
              </button>
              <button
                type="button"
                onClick={handleNextPhoto}
                aria-label="Próxima foto"
                className="absolute right-2 top-1/2 -translate-y-1/2 bg-neutral-900/40 hover:bg-neutral-900/60 backdrop-blur-sm text-white p-1.5 rounded-none transition-all opacity-100 sm:opacity-0 sm:group-hover:opacity-100 cursor-pointer border-none z-20"
              >
                <ArrowRight size={16} strokeWidth={1.5} />
              </button>
            </>
          )}
        </div>

        <div className="h-px w-full bg-neutral-200 dark:bg-neutral-800" />

        {/* ================================================================ */}
        {/* METADADOS E INFORMAÇÕES DA OFERTA                                */}
        {/* ================================================================ */}
        <div className="p-4 flex flex-col grow justify-between space-y-3">
          <div className="space-y-3">
            {/* Tag e Link Intactos no mesmo lugar */}
            <div className="flex items-center justify-between w-full">
              <ModalityTag category={offerCategory} formattedDate={formattedDate} />
              <a
                href={getSuperbidUrl(offerData)}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Ver oferta no Superbid"
                className="text-neutral-500 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-100 transition-colors p-1 ml-auto"
                onClick={(e) => e.stopPropagation()}
              >
                <ExternalLink size={18} strokeWidth={1.5} />
              </a>
            </div>

            <h3 className="font-normal text-[13px] md:text-sm text-neutral-900 dark:text-neutral-100 leading-snug line-clamp-2 uppercase min-h-[2.75em]">
              {offerDesc}
            </h3>

            {/* AQUI: Vendedor primeiro (text-xs), Localização depois (text-[11px]) */}
            <div className="space-y-1 mt-2">
              <div className="text-xs text-neutral-500 dark:text-neutral-400 truncate uppercase">{sellerName ||" "}</div>
              <div className="flex items-center gap-1 text-[11px] text-neutral-500 dark:text-neutral-400 truncate">
                <MapPin size={12} strokeWidth={1.5} className="shrink-0" />
                <span className="truncate">{locationDisplay}</span>
              </div>
            </div>
          </div>

          {/* ================================================================ */}
          {/* PAINEL DE PRECIFICAÇÃO                                           */}
          {/* ================================================================ */}
          <div className="pt-3 border-t border-neutral-200 dark:border-neutral-800 mt-auto">
            <div className="text-[10px] text-neutral-500 dark:text-neutral-400 font-normal uppercase mb-1">{priceLabel}</div>
            <div
              className={`text-lg md:text-xl font-bold tracking-tight ${
                isSold ? "text-neutral-400 dark:text-neutral-500 line-through" : "text-neutral-900 dark:text-neutral-100"
              }`}
            >
              {priceFormatted}
              {showMetric && (
                <span className="text-[11px] font-medium text-neutral-500 dark:text-neutral-400 ml-1 uppercase">
                  /{offerData.system_metric}
                </span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* ================================================================ */}
      {/* CALL TO ACTION (CTA)                                             */}
      {/* ================================================================ */}
      <div className="p-4 pt-0">
        {isSold || isOutOfRange ? (
          <div className="h-11" aria-hidden="true" />
        ) : hasSimulationError ? (
          <div className="relative w-full h-11 overflow-hidden rounded-none border border-neutral-200 dark:border-neutral-700 shadow-xs bg-white dark:bg-neutral-900">
            {/* Preenchimento passivo: cresce 0->100% em 5s, depois retorna ao estado normal (onErrorTimeout) */}
            <div
              className="absolute inset-y-0 left-0 bg-neutral-100 dark:bg-neutral-800"
              style={{
                width: `${fillProgress}%`,
                transitionProperty: "width",
                transitionDuration: "5000ms",
                transitionTimingFunction: "linear",
              }}
            />
            <button
              type="button"
              onClick={() => onSimulate(item, idx)}
              className="relative z-10 flex items-center justify-center gap-2 w-full h-full px-3 text-[13px] font-medium text-neutral-900 dark:text-neutral-100 cursor-pointer"
            >
              <TriangleAlert size={15} strokeWidth={1.5} className="shrink-0 text-neutral-500 dark:text-neutral-400" />
              <span className="truncate">Não foi possível simular agora.</span>
              <span className="underline underline-offset-2 decoration-neutral-400 dark:decoration-neutral-500 shrink-0">
                Tentar novamente
              </span>
            </button>
          </div>
        ) : (
          <Button
            onClick={() => onSimulate(item, idx)}
            disabled={loading || disabled}
            variant="outline"
            className="group flex items-center justify-center gap-2 w-full rounded-none shadow-xs bg-white dark:bg-neutral-900 text-neutral-900 dark:text-neutral-100 border border-neutral-200 dark:border-neutral-700 hover:bg-neutral-900 hover:text-white hover:border-neutral-900 dark:hover:bg-white dark:hover:text-neutral-900 dark:hover:border-white font-medium text-[13px] h-11 cursor-pointer transition-all duration-300 ease-out"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Aguarde...</span>
              </>
            ) : (
              <>
                <span>
                  {item.is_simulated ? "Refazer Simulação" : isCartao ? "Simular parcelamento" : "Simular financiamento"}
                </span>
                <ArrowRight
                  size={15}
                  strokeWidth={1.5}
                  className="transition-transform duration-300 group-hover:translate-x-1"
                />
              </>
            )}
          </Button>
        )}
      </div>
    </div>
  );
}

// 🚀 [PERFORMANCE]: memoiza o card — sem isso, qualquer mudança de estado no
// pai (abrir dropdown, trocar página, scroll infinito acrescentando itens)
// re-renderizava a grade inteira (até 24+ cards), mesmo os que não mudaram
// nada. Só funciona porque `onSimulate` agora chega estável (useCallback no
// pai) em vez de uma arrow function nova por item a cada render.
export const CardOfferV = React.memo(CardOfferVComponent);
