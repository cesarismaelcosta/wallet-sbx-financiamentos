-- Homol · configs dos produtos do parceiro 3 (FlowCredi) — complemento do zip lovable_sync_2026-11-20_flowcredi_processos
-- Configs localizadas por parceiro + tipo/lookup: Imóveis = CATEGORY 13, Home Equity = PRODUCT 6, Car Equity = PRODUCT 7.

-- 1) Chaves com nome de parceiro: sai o rótulo de produto (o roteamento é pelo produto) e o banco fixo por vendedor;
--    flowcredi_bank (se existir) vira fixed_bank.
update orchestrator_configs
set rules = (rules - 'flowcredi_product' - 'flowcredi_bank_by_seller' - 'flowcredi_bank')
            || case when rules ? 'flowcredi_bank' then jsonb_build_object('fixed_bank', rules->'flowcredi_bank') else '{}'::jsonb end
where partner_id = 3 and rules is not null;

-- 2) Aceites: flowcredi_type -> terms_type
update orchestrator_configs o
set consent_configs = (
  select jsonb_agg(
    case when c ? 'flowcredi_type'
      then (c - 'flowcredi_type' - 'flowcredi_version') || jsonb_build_object('terms_type', c->'flowcredi_type')
      else c - 'flowcredi_version' end
    order by (c->>'position')::int)
  from jsonb_array_elements(o.consent_configs) c)
where o.partner_id = 3 and jsonb_typeof(o.consent_configs) = 'array';

-- 3) Limites no rules (uma fonte só)
update orchestrator_configs
set rules = coalesce(rules, '{}'::jsonb) || '{"min_property_value": 50000, "max_property_value": 20000000}'::jsonb
where partner_id = 3 and config_type = 'CATEGORY' and lookup_id::text = '13';

update orchestrator_configs
set rules = coalesce(rules, '{}'::jsonb) || '{
  "loan_percentage_by_type": {"Sala Comercial": 40, "Loja": 40, "Terreno": 30},
  "blocked_property_types": ["Galpão", "Rural"],
  "min_loan_term_months": 12,
  "min_property_value": 50000,
  "min_loan_amount": 10000
}'::jsonb
where partner_id = 3 and config_type = 'PRODUCT' and lookup_id::text = '6';

-- 4) Car Equity: elegibilidade do veículo e textos de 70 meses
update orchestrator_configs
set rules = coalesce(rules, '{}'::jsonb) || '{"max_vehicle_age_years": 11, "allowed_licensing_states": ["SP","PR","MG","SC","RS"], "min_vehicle_value": 30000}'::jsonb,
    page_configs = replace(replace(page_configs::text,
      'Até 60 meses para pagar', 'Até 70 meses para pagar'),
      ' e invista na Superbid pagando em até 60 meses', ' e invista na Superbid pagando em até 70 meses')::jsonb
where partner_id = 3 and config_type = 'PRODUCT' and lookup_id::text = '7';

-- Conferência (não deve sobrar chave flowcredi_ em rules nem terms em consent sem terms_type)
select id, config_type, lookup_id, rules,
       jsonb_path_query_array(consent_configs, '$[*].terms_type') terms_types,
       integration_details->>'partner_environment' ambiente
from orchestrator_configs where partner_id = 3 order by id;
