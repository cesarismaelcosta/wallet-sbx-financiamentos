Faça o deploy das Edge Functions `financial-gateway` e `financial-gateway-webhook`. Não altere código.
