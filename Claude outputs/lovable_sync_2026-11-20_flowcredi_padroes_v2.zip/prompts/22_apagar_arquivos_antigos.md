Apague estes dois arquivos (foram renomeados nos prompts anteriores e não são mais usados):

- `supabase/functions/financial-gateway-webhook/flowcredi-webhook-service.ts`
- `src/features/financial-hub/components/shared/flowcredi/flowTerms.tsx`

Não altere mais nada.
