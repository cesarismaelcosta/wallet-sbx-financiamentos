Substitua todo o conteúdo do arquivo `src/features/financial-hub/components/products/credit/home-equity/home-equity.types.ts` com exatamente o conteúdo abaixo. Não altere nada além deste arquivo e não rode formatação.

O que muda: Percentual por tipo de imóvel vindo do rules.

```
/**
 * @fileoverview Constantes da jornada de Home Equity (FlowCredi)
 * @path src/features/financial-hub/components/products/credit/home-equity/home-equity.types.ts
 */

/** Tipos aceitos pela FlowCredi (enum tipo_imovel do /cgi/lead). */
export const PROPERTY_TYPES = ["Apartamento", "Casa", "Casa em condomínio", "Sala Comercial", "Loja", "Terreno", "Galpão", "Rural", "Outros"];

export const UF_LIST = [
  "AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA",
  "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO",
];

export const inputClass =
  "h-10 rounded-none bg-white dark:bg-neutral-800 border-neutral-200 dark:border-neutral-700 text-brand-accent font-semibold disabled:bg-neutral-100 dark:disabled:bg-neutral-900 disabled:text-neutral-500";
export const labelClass = "text-[11px] font-medium text-neutral-900 dark:text-neutral-100 uppercase tracking-wider font-sans";
export const digitsToMoney = (v: string) => Number(v.replace(/\D/g, "") || "0") / 100;

/** % máximo do imóvel para o tipo (rules.loan_percentage_by_type; sem o tipo, rules.max_loan_percentage). */
export const loanPctOf = (propertyType: string | undefined, rules: { max_loan_percentage?: number; loan_percentage_by_type?: Record<string, number> }) =>
  Number(rules.loan_percentage_by_type?.[propertyType ?? ""] ?? rules.max_loan_percentage ?? 60);

/** Crédito máximo: % do imóvel (por tipo) menos o saldo devedor. */
export const maxCreditOf = (propertyValue: number, balance: number, maxPct: number) =>
  Math.max(0, Math.floor(((propertyValue * maxPct) / 100 - balance) / 1000) * 1000);
```
