Substitua todo o conteúdo do arquivo `src/features/financial-hub/components/products/credit/auto-equity/steps/Step1Vehicle.tsx` com exatamente o conteúdo abaixo. Não altere nada além deste arquivo e não rode formatação.

O que muda: Só placa, UF de licenciamento e ano de fabricação (como no site da FlowCredi); rodapé com a elegibilidade.

```
/**
 * @fileoverview Step 1 — Seu veículo (Car Equity · FlowCredi)
 * @path src/features/financial-hub/components/products/credit/auto-equity/steps/Step1Vehicle.tsx
 *
 * Identificação do veículo em garantia, digitada pelo cliente: placa, UF de licenciamento e
 * ano de fabricação (como no site da FlowCredi + mínimo da API de Processos). Elegibilidade
 * (ano mínimo, UFs aceitas) vem de `rules`. Valor e situação do veículo ficam no Step 2
 * (definem o limite do crédito). Ficam em `data.flowInputs`.
 */

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useWizard } from "@/features/financial-hub/components/shared/WizardProvider";
import { FlowInputs, FlowWizardData } from "@/features/financial-hub/components/shared/flowcredi/flowcredi.types";
import { UF_LIST, PLATE_RE, inputClass, labelClass, selectItemClass, vehicleEligibility } from "../auto-equity.types";

const YEAR_NOW = new Date().getFullYear();
const validYear = (y: string, min = 1950) => /^\d{4}$/.test(y) && Number(y) >= min && Number(y) <= YEAR_NOW + 1;

export function Step1Vehicle() {
  const { state, update } = useWizard<FlowWizardData>();
  const data = state?.data ?? {};
  const saved: Partial<FlowInputs> = data.flowInputs ?? {};
  const elig = vehicleEligibility(data.rules);
  const states = elig.states ?? UF_LIST;

  const [plate, setPlate] = useState<string>(saved.vehicle_plate ?? "");
  const [uf, setUf] = useState<string>(states.includes(saved.vehicle_state ?? "") ? (saved.vehicle_state as string) : "");
  const [year, setYear] = useState<string>(saved.vehicle_year ?? "");

  const valid = PLATE_RE.test(plate) && states.includes(uf) && validYear(year, elig.minYear ?? 1950);

  const handleContinue = () => {
    if (!valid) return;
    update({
      meta: { ...state.meta, step: Number(state.meta?.step ?? 1) + 1 },
      data: {
        ...data,
        flowProduct: "auto_equity",
        flowInputs: {
          ...saved,
          vehicle_plate: plate,
          vehicle_state: uf,
          vehicle_year: year,
        },
      },
    });
  };

  const field = (id: string, label: string, value: string, onChange: (v: string) => void, extra: React.InputHTMLAttributes<HTMLInputElement> = {}) => (
    <div className="space-y-1">
      <Label htmlFor={id} className={labelClass}>
        {label}
      </Label>
      <Input id={id} autoComplete="off" value={value} onChange={(e) => onChange(e.target.value)} className={inputClass} {...extra} />
    </div>
  );

  return (
    <div className="w-full space-y-8 animate-in fade-in duration-500">
      <div className="bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-none p-4 sm:p-5 space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 sm:gap-x-6 gap-y-3">
          {field("ae-plate", "Placa", plate, (v) => setPlate(v.toUpperCase().replace(/[^A-Z0-9-]/g, "").slice(0, 8)))}

          <div className="space-y-1">
            <Label className={labelClass}>UF de licenciamento{elig.states ? " *" : ""}</Label>
            <Select value={uf} onValueChange={setUf}>
              <SelectTrigger className={inputClass}>
                <SelectValue placeholder="Selecione" />
              </SelectTrigger>
              <SelectContent className="rounded-none border-neutral-200 dark:border-neutral-800 max-h-72">
                {states.map((u) => (
                  <SelectItem key={u} value={u} className={selectItemClass}>
                    {u}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {field("ae-year", `Ano de fabricação${elig.minYear ? " *" : ""}`, year, (v) => setYear(v.replace(/\D/g, "").slice(0, 4)), { inputMode: "numeric" })}
        </div>

        {/* * Elegibilidade do parceiro (rules): só aparece o que estiver configurado */}
        {(elig.minYear || elig.states) && (
          <p className="text-[11px] text-neutral-500 dark:text-neutral-400">
            * Veículos{elig.minYear ? ` a partir de ${elig.minYear}` : ""}
            {elig.states
              ? `${elig.minYear ? "," : ""} licenciados em ${elig.states.length > 1 ? `${elig.states.slice(0, -1).join(", ")} ou ${elig.states[elig.states.length - 1]}` : elig.states[0]}`
              : ""}
            .
          </p>
        )}
      </div>

      <Button
        type="button"
        onClick={handleContinue}
        disabled={!valid}
        className="w-full h-12 rounded-none text-white shadow-xs transition-all active:scale-[0.98] cta-gradient disabled:opacity-50"
      >
        Continuar
      </Button>
    </div>
  );
}
```
