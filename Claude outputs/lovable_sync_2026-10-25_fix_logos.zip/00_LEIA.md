# Fix logos FlowCredi (2026-10-25)

Aplicar depois do tipos_shared.

Corrige o erro de tipo em flowcredi-service.ts:310 (mapeamento das logos dos bancos)
apontado pelo Lovable. Só tipo, sem mudança de comportamento.

## Lovable: prompts
01 flowcredi-service.ts

## Deploy
financial-gateway (homol).

Sem migration.
