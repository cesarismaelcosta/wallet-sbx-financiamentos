# Tipagem das edge functions + token do sbx-auth-exchange (2026-10-25) — pacote único

Aplicar depois do fix_logos.
Substitui tipos_functions, token_transicao, exchange_nome_login e exchange_nome_login_v2 (não aplicar esses).

- Só tipos nas edge functions: zera os erros de tipo e tira os `any` (ficam só os `sql`/`t` do postgres).
- sbx-auth-exchange (modo issue): o token de transição passa a levar nome e login, com os mesmos
  valores do token definitivo (sessão). Esse token só trafega no corpo da resposta, nunca na URL.

## Lovable: prompts na ordem
01 _shared/types.ts
02 _shared/hydrate-data.ts
03 _shared/alert.ts
04 _shared/jwt.ts
05 financial-gateway-gate/index.ts
06 financial-gateway-webhook/fandi-service.ts
07 sbx-auth/index.ts
08 sbx-auth-exchange/index.ts
09 sbx-offer/index.ts
10 sbx-offer-query/index.ts
11 sbx-event/index.ts
12 orchestrator-configs/index.ts
13 log-access/index.ts
14 manage-backoffice-users/index.ts
15 notification-dispatcher/index.ts
16 notification-gateway/index.ts
17 notification-system-message/index.ts

## Deploy
Todas as edge functions.

Sem migration.
