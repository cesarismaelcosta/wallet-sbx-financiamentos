# Taxa Balcão (2026-10-25)

Aplicar depois do ajustes15.

Imóveis: o card de cada banco passa a mostrar a "Taxa Balcão" (se o banco não tiver, a menor taxa).
Home Equity não muda. Simulações antigas não mudam.

## Lovable: prompts na ordem
01 flowcredi-service.ts ... Taxa Balcão como condição selecionada de cada banco (sem Balcão → menor taxa)
02 flowcredi-mortgage-service.ts ... só comentário
03 FlowOffersStep.tsx ... só comentários

## Deploy
financial-gateway (homol).

Sem migration.
