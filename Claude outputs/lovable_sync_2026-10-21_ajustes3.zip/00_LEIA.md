# Ajustes 3 (2026-10-21) · só o que mudou depois do ajustes2 aplicado em homologação

## 1. Banco (dev e homol)
supabase/migrations/20261025160000_flowcredi_status_ajustes.sql
- leads já gravados: Enviado → Pendente envio (nenhum saiu de fato)
- simulações FlowCredi sem "retorno do parceiro" escrito por nós
- home equity / Car Equity sem entrada

## 2. Lovable: prompts 01 a 08, na ordem
01 FlowLeadStep.tsx ............. tela "Seus dados" (CPF · Nome / Celular · Nascimento · E-mail)
02 PanelFlowcredi.tsx ........... quadro do lead aceita Pendente envio; status lido de status_types
03 homeEquity.manifest.ts ....... frase do step "Seus dados"
04 Step5Confirm.tsx (home equity) dado do imóvel na tela final
05 auto-equity.manifest.ts ...... frase do step "Seus dados"
06-08 serviços FlowCredi ........ lead Pendente envio (envio desligado), sem texto próprio de
                                   retorno do parceiro, sem entrada em home/car equity

## 3. Deploy
financial-gateway (perto da migration)
