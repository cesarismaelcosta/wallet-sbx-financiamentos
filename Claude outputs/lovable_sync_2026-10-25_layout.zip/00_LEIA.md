# Layout (2026-10-25)

Aplicar depois do pacote da Taxa Balcão.

## Lovable: prompts na ordem
01 FlowOffersStep.tsx ... botão Continuar com altura certa no celular
02 FlowLeadStep.tsx ... botão Enviar solicitação com altura certa no celular
03 CardOfferV.tsx ... descrição do lote em 2 linhas sem aparecer a 3ª

Sem migration e sem deploy de função.
