Edite só o arquivo `src/features/financial-hub/components/shared/renderes/CardOfferV.tsx`. Faça apenas a troca abaixo, exatamente como está, sem alterar mais nada e sem rodar formatação.

Troque:

```
leading-snug line-clamp-2 uppercase min-h-10">
```

por:

```
leading-snug line-clamp-2 uppercase min-h-[2.75em]">
```
