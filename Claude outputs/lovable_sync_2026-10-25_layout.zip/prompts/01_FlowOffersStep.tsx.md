Edite só o arquivo `src/features/financial-hub/components/shared/flowcredi/FlowOffersStep.tsx`. Faça apenas a troca abaixo, exatamente como está, sem alterar mais nada e sem rodar formatação.

Troque:

```
className="h-12 w-full sm:w-auto flex-1 rounded-none cta-gradient text-white font-bold shadow-xs transition-all active:scale-[0.98]"
```

por:

```
className="h-12 w-full sm:w-auto sm:flex-1 rounded-none cta-gradient text-white font-bold shadow-xs transition-all active:scale-[0.98]"
```
