# Tipagem gateway + orchestrator (2026-10-25)

Aplicar depois do tipos_flowcredi.

Só tipos, sem mudança de comportamento. Zera os erros de tipo (strict) do financial-gateway e do orchestrator.
Não mexe em src/integrations/supabase/types.ts nem no design system.

## Lovable: prompts na ordem
01 _shared/types.ts ... campos que o código já usa declarados no SimulationPayload/OrchestratorPayload
02 _shared/hydrate-data.ts ... visitExists boolean, visitId/visitUpdateId/offerId opcionais
03 _shared/gatekeeper.ts ... sessionUserId aceita null/undefined
04 orchestrator/index.ts
05 orchestrator/persist-data.ts
06 financial-gateway/simulation-handler.ts
07 financial-gateway/persist-data.ts
08 financial-gateway/fandi-service.ts
09 financial-gateway/email-offer-button.ts
10 financial-gateway/partner-notifications.ts
11 financial-gateway/fandi-notifications.ts

## Deploy
financial-gateway e orchestrator (homol).

Sem migration.
