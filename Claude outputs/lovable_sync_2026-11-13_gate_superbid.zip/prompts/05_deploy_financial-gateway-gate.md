Faça o deploy da edge function `financial-gateway-gate`. Não altere nenhum arquivo.
