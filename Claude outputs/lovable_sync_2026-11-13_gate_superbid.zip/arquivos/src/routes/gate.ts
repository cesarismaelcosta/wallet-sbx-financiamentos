/**
 * @fileoverview Porta de entrada do gateway no domínio do app (rota de servidor)
 * @path src/routes/gate.ts
 *
 * Recebe o POST de formulário de parceiros (ex.: botão "Simular financiamento"
 * da Superbid) e repassa para a Edge Function `financial-gateway-gate`, para
 * que o parceiro e a barra de endereço vejam só o domínio do app — nunca o
 * endereço do Supabase.
 *
 * O que a rota garante:
 * 1. Repassa `Content-Type`, `Accept` e `User-Agent`. O `User-Agent` é
 *    obrigatório: o token de transição (`#xt`) fica preso ao navegador e a
 *    troca no `sbx-auth-exchange` falha se ele mudar no caminho.
 * 2. Repassa o IP real do usuário assinado com `GATE_PROXY_SECRET`
 *    (`x-proxy-client-ip*`). O gate só aceita esse IP com assinatura válida;
 *    sem a chave configurada, o gate usa o IP da borda (o deste servidor).
 * 3. Devolve o redirecionamento do gate sem segui-lo (`redirect: "manual"`).
 * 4. Erro do gate (`/financialGatewayGate?...`) volta para o domínio do app,
 *    mesmo quando o `return_uri` aponta para o parceiro.
 *
 * Só POST: chamadas AJAX (cookie/CORS) continuam indo direto no gate.
 *
 * @author César Ismael Pereira da Costa
 * @author Claude
 */

import { createFileRoute } from "@tanstack/react-router";

const GATE_FUNCTION_PATH = "/functions/v1/financial-gateway-gate";
const ERROR_PAGE_PATH = "/financialGatewayGate";
const PROXY_IP_PREFIX = "gate-proxy-ip:v1";
const FORWARDED_HEADERS = ["content-type", "accept", "user-agent"] as const;

/** Variável de ambiente do servidor (Cloudflare Workers com nodejs_compat / Node no dev). */
function serverEnv(name: string): string {
  return (typeof process !== "undefined" && process.env?.[name]) || "";
}

/** IP do usuário como chegou a este servidor. */
function requestClientIp(request: Request): string {
  return (
    request.headers.get("cf-connecting-ip") ||
    request.headers.get("x-forwarded-for")?.split(",")[0] ||
    request.headers.get("x-real-ip") ||
    ""
  ).trim();
}

async function hmacHex(secret: string, message: string): Promise<string> {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(message));
  return Array.from(new Uint8Array(sig))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

/** Leva o redirecionamento de erro do gate para o domínio do app; o resto passa intacto. */
function toAppErrorPage(location: string, appOrigin: string): string {
  try {
    const url = new URL(location);
    if (url.pathname === ERROR_PAGE_PATH) return `${appOrigin}${url.pathname}${url.search}`;
  } catch (_) {
    // Location relativo ou inválido: devolve como veio.
  }
  return location;
}

function errorRedirect(appOrigin: string, code: string): Response {
  return new Response(null, {
    status: 302,
    headers: {
      Location: `${appOrigin}${ERROR_PAGE_PATH}?status=error&code=${encodeURIComponent(code)}`,
      "Cache-Control": "no-store",
    },
  });
}

async function forwardToGate(request: Request): Promise<Response> {
  const appOrigin = new URL(request.url).origin;
  const supabaseUrl = (import.meta.env.VITE_SUPABASE_URL as string | undefined) || "";
  if (!supabaseUrl) {
    console.error("[gate] VITE_SUPABASE_URL ausente.");
    return errorRedirect(appOrigin, "GENERIC_ERROR");
  }

  const headers = new Headers();
  for (const name of FORWARDED_HEADERS) {
    const value = request.headers.get(name);
    if (value) headers.set(name, value);
  }

  const ip = requestClientIp(request);
  const secret = serverEnv("GATE_PROXY_SECRET");
  if (ip && secret) {
    const ts = Math.floor(Date.now() / 1000).toString();
    headers.set("x-proxy-client-ip", ip);
    headers.set("x-proxy-client-ip-ts", ts);
    headers.set("x-proxy-client-ip-sig", await hmacHex(secret, `${PROXY_IP_PREFIX}|${ip}|${ts}`));
  }

  let upstream: Response;
  try {
    upstream = await fetch(`${supabaseUrl}${GATE_FUNCTION_PATH}`, {
      method: "POST",
      headers,
      body: await request.arrayBuffer(),
      redirect: "manual",
    });
  } catch (caught: unknown) {
    console.error("[gate] Falha ao chamar o financial-gateway-gate:", (caught as Error)?.message);
    return errorRedirect(appOrigin, "GENERIC_ERROR");
  }

  const out = new Headers({ "Cache-Control": "no-store" });
  const location = upstream.headers.get("location");
  if (location) out.set("Location", toAppErrorPage(location, appOrigin));
  const contentType = upstream.headers.get("content-type");
  if (contentType) out.set("Content-Type", contentType);

  const isRedirect = upstream.status >= 300 && upstream.status < 400;
  return new Response(isRedirect ? null : upstream.body, { status: upstream.status, headers: out });
}

export const Route = createFileRoute("/gate")({
  server: {
    handlers: {
      POST: ({ request }) => forwardToGate(request),
    },
  },
});
