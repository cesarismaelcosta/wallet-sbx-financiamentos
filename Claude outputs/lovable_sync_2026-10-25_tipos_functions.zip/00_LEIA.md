# Tipagem das demais edge functions (2026-10-25)

Aplicar depois do fix_logos.

Só tipos, sem mudança de comportamento. Corrige 13 dos 14 erros de tipo e tira os `any`
das demais functions (ficam só os `sql`/`t` do postgres).

## Lovable: prompts na ordem
01 _shared/types.ts
02 _shared/hydrate-data.ts
03 _shared/alert.ts
04 financial-gateway-gate/index.ts
05 financial-gateway-webhook/fandi-service.ts
06 sbx-auth/index.ts
07 sbx-auth-exchange/index.ts
08 sbx-offer/index.ts
09 sbx-offer-query/index.ts
10 sbx-event/index.ts
11 orchestrator-configs/index.ts
12 log-access/index.ts
13 manage-backoffice-users/index.ts
14 notification-dispatcher/index.ts
15 notification-gateway/index.ts
16 notification-system-message/index.ts

## Deploy
Todas as edge functions.

Sem migration.
