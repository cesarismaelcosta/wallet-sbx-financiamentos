# Ajustes 2 (2026-10-21) · tudo depois do lovable_sync_2026-10-21_ajustes.zip

## 1. Banco (dev e homol), nesta ordem
1. supabase/migrations/20261025150000_flowcredi_lead_sem_retorno_parceiro.sql (se ainda não rodou)
2. supabase/migrations/20261025160000_flowcredi_status_ajustes.sql
   - leads já gravados: Enviado → Pendente envio (nenhum saiu de fato)
   - simulações FlowCredi sem "retorno do parceiro" escrito por nós
   - home equity / Car Equity sem entrada

## 2. Lovable: prompts 01 a 09, na ordem
01 FlowLeadStep.tsx ......... tela "Seus dados" (CPF · Nome / Celular · Nascimento · E-mail)
02 PanelFlowcredi.tsx ....... quadro do lead com o status lido de status_types
03 homeEquity.manifest.ts ... frase do step "Seus dados"
04 Step5Confirm.tsx (home equity) dado do imóvel na tela final
05 auto-equity.manifest.ts .. frase do step "Seus dados"
06-09 serviços FlowCredi .... lead Pendente envio (envio desligado), sem texto próprio de
                              retorno do parceiro, sem entrada em home/car equity

## 3. Deploy
financial-gateway
