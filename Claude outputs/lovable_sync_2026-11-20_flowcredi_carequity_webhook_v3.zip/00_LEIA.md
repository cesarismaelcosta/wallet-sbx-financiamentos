# FlowCredi: telas do Car Equity, aceites, webhook assinado e AGENTS.md (2026-11-20 · v3)

Aplicar DEPOIS de `lovable_sync_2026-11-20_flowcredi_processos` e `lovable_sync_2026-11-20_flowcredi_padroes_v2`.

## O que muda

Car Equity
- Tela 1 (Seu veículo): Placa | UF de licenciamento; Ano de fabricação (lista) | Valor do veículo;
  Está no seu nome? | Está quitado? Rodapé: "* Somente veículos a partir de 2015, com valor mínimo de
  R$ 30.000,00, licenciados em MG, PR, RS, SC ou SP." (valores do `rules`).
- Tela 2 (Seu crédito): Saldo devedor | Banco do financiamento (só se não quitado); "Qual banco?" (só se
  "Outros"); Valor do crédito * com slider; Parcelas | Motivo. Rodapé: "* Crédito até R$ X (valor do
  veículo menos o saldo devedor)".

Todos os produtos
- Troca de passo: rola ao topo do wizard e foca o primeiro campo.

Servidor
- Aceites registrados na API de Termos da FlowCredi ANTES de criar o processo; só segue com 201.
  Recusa → nenhum processo, tela mostra "Não foi possível registrar seus aceites na FlowCredi. Tente
  novamente em instantes." e o registro fica como Falha (8) com o detalhe dos termos.
- Car Equity passa a gravar `gateway_response` (processo e retorno dos termos) em `simulations.raw_payload`.
- Webhook `financial-gateway-webhook/flowcredi`: valida a assinatura (HMAC-SHA256, janela de 5 minutos).

Repositório
- `AGENTS.md` (regras para qualquer IA) e `CLAUDE.md` na raiz.

## Lovable: prompts (na ordem)
01–03 Edge Function `financial-gateway`
04 Edge Function `financial-gateway-webhook`
05–07 Telas
08–09 Arquivos novos na raiz (`AGENTS.md`, `CLAUDE.md`)
10 Deploy das duas funções

Sem migration. Sem SQL.

## Antes de testar em homol (manual)
- Secret `FLOWCREDI_WEBHOOK_SECRET` no Supabase de homol (projeto `qadgbfhjtgufioxtyamq`). Sem ela o
  webhook responde 503 a todos os avisos.
- Colar um resumo do `AGENTS.md` em Lovable > Project Settings > Knowledge.
- Assinatura do webhook na FlowCredi: depende da liberação de acesso pedida a eles (hoje 403).

## Teste em homol
1. Car Equity tela 1: ano em lista (até 2015), valor do veículo e as duas perguntas na mesma tela;
   "Continuar" leva ao topo da tela 2 com foco no primeiro campo.
2. Car Equity tela 2: quitado → só crédito, parcelas e motivo; não quitado → saldo e banco; "Outros" →
   "Qual banco?".
3. Envio do Car Equity: "Solicitação enviada"; no banco, `raw_payload.gateway_response` com o processo e
   os termos (201).

## Observações
- Rodar `npx tsc --noEmit` antes de aplicar (erros no design system protegido são antigos).
