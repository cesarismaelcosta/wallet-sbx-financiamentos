Crie o arquivo `CLAUDE.md` com exatamente o conteúdo abaixo. Não altere nada além deste arquivo e não rode formatação.

O que muda: Arquivo NOVO na raiz: aponta para o AGENTS.md.

```
# CLAUDE.md

As regras deste repositório estão em [AGENTS.md](./AGENTS.md). Leia esse arquivo inteiro antes de
qualquer alteração e siga-o à risca.

```
