# Botão "Simular novamente" em azul (2026-10-25)

Mesmo azul e mesmo hover dos botões "Voltar" (#2246A7, fundo #E7F2FD).

## Lovable: prompts na ordem
01 products/financial/veiculos/steps/Step2Confirm.tsx ... Veículos (negado)
02 products/financial/partner/steps/Step2Confirm.tsx ... Partner (negado)
03 shared/flowcredi/FlowOffersStep.tsx ... Imóveis/Home Equity (sem ofertas)

Sem migration e sem deploy de função.
