Edite só o arquivo `src/features/financial-hub/components/products/financial/partner/steps/Step2Confirm.tsx`. No botão "Simular novamente", faça apenas a troca abaixo, exatamente como está, sem alterar mais nada e sem rodar formatação.

Troque:

```
className="text-neutral-900 dark:text-neutral-100 hover:bg-neutral-100 dark:hover:bg-neutral-800 hover:text-neutral-900 dark:hover:text-neutral-100 transition-all focus-visible:ring-2 focus-visible:ring-neutral-900 dark:focus-visible:ring-neutral-100 focus-visible:ring-offset-2"
```

por:

```
className="text-[#2246A7] hover:bg-[#E7F2FD] dark:hover:bg-neutral-800 hover:text-[#2246A7] transition-all rounded-none font-medium"
```
