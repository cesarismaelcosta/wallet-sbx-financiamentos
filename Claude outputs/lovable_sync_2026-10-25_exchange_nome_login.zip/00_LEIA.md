# Token de transição do sbx-auth-exchange (2026-10-25)

Aplicar depois do tipos_functions. Substitui o token_transicao (não aplicar aquele).

O modo "issue" passa a colocar nome e login no token de transição (que só trafega no corpo
da resposta, nunca na URL), como o gate já faz. A sessão gerada no "redeem" sai com nome e login.
Zera o último erro de tipo.

## Lovable: prompts
01 sbx-auth-exchange/index.ts

## Deploy
sbx-auth-exchange (homol).

Sem migration.
