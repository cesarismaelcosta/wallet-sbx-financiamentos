# Ajustes 10 (2026-10-24) · área 2 dos `any` (jornadas por dentro)

Aplicar DEPOIS do ajustes9.

Só tipos do TypeScript: nada muda no que roda no navegador.
Novo arquivo: products/financial/veiculos/veiculos.types.ts (mesmo padrão de card.types / simulacao.types).

## Lovable: prompts na ordem
01 core/hooks/useSafeCall.ts
02 core/services/fastPathCache.ts
03 core/hooks/useOrchestrator.ts
04 core/hooks/useNavigation.ts
05 core/hooks/useOrchestratorHistorySync.ts
06 core/services/gateway.ts
07 components/layout/BaseWizardLayout.tsx
08 components/layout/ButtonWhatsApp.tsx
09 components/layout/DynamicConsents.tsx
10 components/layout/PanelProductOffer.tsx
11 components/layout/FinancialHubLayout.tsx
12 components/layout/PanelHeader.tsx
13 components/shared/WizardEngine.tsx
14 components/shared/WizardHeader.tsx
15 components/shared/types.ts
16 components/shared/flowcredi/flowcredi.types.ts
17 components/shared/flowcredi/FlowLeadStep.tsx
18 components/shared/flowcredi/FlowOffersStep.tsx
19 components/shared/flowcredi/DetailSheet.tsx
20 components/products/credit/auto-equity/steps/Step1Vehicle.tsx
21 components/products/credit/auto-equity/steps/Step2Credit.tsx
22 components/products/credit/auto-equity/steps/Step3Income.tsx
23 components/products/credit/auto-equity/steps/Step5Confirm.tsx
24 components/products/credit/home-equity/steps/Step1Property.tsx
25 components/products/credit/home-equity/steps/Step2Simulation.tsx
26 components/products/credit/home-equity/steps/Step5Confirm.tsx
27 components/products/financial/imoveis/steps/Step1Simulation.tsx
28 components/products/financial/imoveis/steps/Step4Confirm.tsx
29 components/products/financial/card/steps/Step1Simulation.tsx
30 components/products/financial/partner/steps/Step1Simulation.tsx
31 components/products/financial/partner/steps/Step2Confirm.tsx
32 components/products/financial/partner/simulacao.types.ts
33 components/products/financial/veiculos/steps/Step1Simulation.tsx
34 components/products/financial/veiculos/steps/Step2Confirm.tsx
35 components/products/financial/veiculos/veiculos.types.ts
36 components/products/insurance/auto/steps/Step1PartnersPanel.tsx

Sem migration e sem deploy de função.
