import { useWizard } from "@/features/financial-hub/components/shared/WizardProvider";
import { callOrchestrator, GatewayErrorResponse } from "@/features/financial-hub/core/services/gateway";
import { useState } from "react";

/**
 * Registro de intenções de navegação.
 * Define o mapeamento entre a ação de negócio e o comportamento do evento.
 */
export const NAVIGATION_INTENTS = {
  REDIRECT_PARTNER_PAGE: {
    action: 'REDIRECT',
    action_description: 'REDIRECT_PARTNER_PAGE',
    target: '_self' // Substitui a aba atual para manter o fluxo
  },
  REDIRECT_PARTNER_WHATSAPP: {
    action: 'CONTACT',
    action_description: 'REDIRECT_PARTNER_WHATSAPP',
    target: '_blank' // Abre em nova aba para não perder a página
  }
} as const;

/**
 * Hook customizado para centralizar a lógica de redirecionamento e rastreamento.
 * Este hook garante que toda saída para parceiros ou suporte humano seja
 * devidamente registrada no backend via `orchestrateNavigation` antes da execução.
 */
export function useNavigation() {
  const { state } = useWizard();
  const [loading, setLoading] = useState(false);

  /**
   * Executa a orquestração do evento e gerencia o redirecionamento.
   * @param intent - A intenção de navegação (ver NAVIGATION_INTENTS).
   * @param externalUrl - (Opcional) URL externa para abrir (ex: WhatsApp).
   * @param consentsData - Dados de consentimentos da visita para enviar junto.
   */
  const handleRedirect = async (
    intent: typeof NAVIGATION_INTENTS[keyof typeof NAVIGATION_INTENTS], 
    externalUrl?: string,
    consentsData?: Record<string, unknown>[]  
  ) => {

    setLoading(true);
    
    // ✨ [CART PRESERVATION]: Failsafe buscando da URL caso o state.data perca a referência
    const urlParams = new URLSearchParams(window.location.search);
    const fallbackVisitId = urlParams.get('visit_id');

    // 1. Monta o payload padronizado com os dados do estado do Wizard
    const payload = {
      ...state.data,
      visit_id: state.data?.visit_id || fallbackVisitId, // Garante amarração ao Backoffice
      action: intent.action,
      action_description: intent.action_description,
      origin_url: window.location.origin + window.location.pathname,
      target_url: externalUrl,
      consents: consentsData || [],
      timestamp: new Date().toISOString()
    };

    try {
      // 2. Dispara a orquestração (Obrigatório para rastreio)
      // Se o token estiver expirado, o Gateway lançará um erro aqui.
      await callOrchestrator(payload, "POST");
      
      // 3. Executa a navegação apenas se o rastreio for bem-sucedido
      if (externalUrl) {
        window.open(externalUrl, intent.target);
      }
    } catch (caught: unknown) {
      const error = caught as Partial<GatewayErrorResponse> | null;
      // =========================================================================
      // INTERCEPTADOR DE SESSÃO
      // A fonte da verdade é o Backend (Gateway). Se ele envia um fallback_url,
      // nós obedecemos e redirecionamos. Não calculamos rotas no frontend.
      // =========================================================================
      
      const redirectUrl = error?.fallback_url;

      if ((error?.code === 'SESSION_EXPIRED' || error?.code === 'UNAUTHORIZED') && redirectUrl) {
        window.location.href = redirectUrl;
        return new Promise(() => {}); 
      }

      // 4. LOG ESTRUTURADO
      console.error("[useNavigation.ts | handleRedirect] Falha na orquestração:", {
        message: error?.message,
        code: error?.code,
        status: error?.status,
        details: error?.details
      });

      // 5. PROPAGAÇÃO DO ERRO
      throw error;
      
    } finally {
      // Gerencia o loading: se abriu em nova aba, libera o botão imediatamente.
      // Se for navegação interna, o loading permanece até a troca de página.
      if (intent.target === '_blank') {
        setLoading(false);
      }
    }
  };

  return { handleRedirect, loading };
}