# Ajustes 5 (2026-10-24) · simulação de imóveis

Lovable: prompt 01.
01 Step1Simulation.tsx (imóveis) ... abre com 80% financiado e prazo padrão quando o lote carrega

Sem migration e sem deploy de função.
