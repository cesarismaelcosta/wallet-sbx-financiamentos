# Tipagem _shared (2026-10-25)

Aplicar depois do tipos_gateway_unico.

Só tipos, sem mudança de comportamento. Tira os `any` de supabase/functions/_shared
(fica só o `sql` do postgres em hydrate-data.ts).

## Lovable: prompts na ordem
01 _shared/types.ts
02 _shared/s2s.ts
03 _shared/hydrate-data.ts
04 _shared/orchestrator-configs.ts
05 _shared/gatekeeper.ts
06 _shared/alert.ts
07 _shared/simulation-bounds.ts
08 _shared/logger.ts
09 _shared/jwt.ts
10 _shared/server.ts
11 _shared/infrastructure.ts
12 _shared/session-guard.ts
13 financial-gateway/flowcredi-service.ts
14 financial-gateway/credit-card-notifications.ts

## Deploy
Todas as edge functions (o _shared é usado por todas).

Sem migration.
