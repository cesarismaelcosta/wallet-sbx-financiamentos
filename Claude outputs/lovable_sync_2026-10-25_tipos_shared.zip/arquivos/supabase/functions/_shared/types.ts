/**
 * @interface OriginDetails
 * @description Padronização dos dados de infraestrutura e origem (Origin-Tracing).
 */
export interface OriginDetails {
  ip_address: string;
  country: string;
  state: string;
  city: string;
  user_agent: string;
  device_type: string;
  operating_system: string;
  metadata: {
    timestamp: string;
    tls_version?: string | null;
    [key: string]: unknown;
  };
}

/**
 * @interface Entity
 * @description Representa o proponente.
 * A mudança para 'number | string' no entity_id é para suportar o tipo TEXT do banco.
 */
export interface Entity {
  entity_id: number | string;
  name: string;
  document: string;
  phone: string;
  email: string;
  birth_date: string; // ISO String ou YYYY-MM-DD
  gender: string;
  entity_type?: string; // F (pessoa física) | J (pessoa jurídica)
  [key: string]: unknown; // Permite campos extras genéricos (ex: renda, profissão)
}

/**
 * @interface Manager
 * @description Representa o operador/gerenciador da oferta (manager_details).
 * Esta entidade é responsável pela operação do leilão ou evento.
 */
export interface Manager {
  manager_name: string;
  [key: string]: unknown; // Captura metadados específicos para a coluna JSONB manager_details
}

/**
 * @interface Seller
 * @description Representa o vendedor/proprietário real do bem (seller_details).
 * Importante para fluxos onde o operador (Manager) é diferente do dono do produto.
 */
export interface Seller {
  seller_id: string;
  legal_name: string;
  trade_name: string;
  economic_group: string;
  [key: string]: unknown; // Captura metadados específicos para a coluna JSONB seller_details/seller_details
}

/**
 * @interface Event
 * @description Snapshot do contexto temporal e descritivo do evento (event_details).
 * Focada estritamente em metadados do leilão ou campanha.
 */
export interface Event {
  event_id: string;
  event_description: string;
  event_start_date: string;
  event_end_date: string;
  [key: string]: unknown; // Captura campos como 'numero_leilao' ou 'tipo_evento' (event_details)
}

/**
 * @interface Vehicle
 * @description Atributos técnicos específicos para o nicho de veículos.
 */
export interface Vehicle {
  manufacture_year: number;
  model_year: number;
  fipe_code: string;
  fipe_value?: number;
  [key: string]: unknown; // Captura cor, placa, chassi ou quilometragem
}

/**
 * @interface Offer
 * @description A oferta comercial genérica.
 * Não mapeamos detalhes específicos (veículo, imóvel) aqui para manter a
 * flexibilidade total via index signature.
 */
export interface Offer {
  offer_id: string;
  offer_description: string;
  offer_value: number;
  category_id?: number; // Injetado pelo Orquestrador após o de-para
  category: string; // Texto vindo do site
  subcategory_id?: number | string;
  subcategory?: string;
  vehicle_details?: Partial<Vehicle>; // atributos do veículo (lotes de veículos)
  location?: { state?: string; city?: string; [key: string]: unknown }; // localização do bem
  [key: string]: unknown; // Aqui entrará 'vehicle', 'equity' ou qualquer outro detalhe enviado
}

/**
 * @interface InteractionContext
 * @description Define a origem e o contexto da interação do usuário.
 * É o rastreador que determina as regras de validação que serão aplicadas.
 *
 * @property {string} utm_source - O canal de entrada:
 *   - 'offer': Clique originado de um lote/item específico no site.
 *   - 'banner', 'whatsapp', 'email', 'sms': Origens de campanhas de marketing.
 * @property {string} origin_url - A URL exata onde o usuário estava (referência de origem).
 */
export interface InteractionContext {
  utm_source: "direct" | "offer" | "lp" | "banner" | "whatsapp" | "email" | "sms";
  utm_medium: "none" | "organic" | "home" | "event" | "offer";
  utm_campaign: string;
  origin_url: string;
}

/**
 * @interface OrchestratorPayload
 * @description O contrato mestre de entrada para o ecossistema sbX.
 * Reflete a estrutura de snapshots (details) das novas tabelas.
 */
export interface OrchestratorPayload {
  // IDENTIFICAÇÃO (Sempre Obrigatórios)
  interaction_context: InteractionContext; // Obrigatório: GPS da visita (origem/canal)
  entity?: Entity; // Obrigatório: Snapshot do proponente (entity_details)

  // CONTEXTO DE NEGÓCIO (Opcionais na raiz, validados por regra)
  manager?: Manager; // Obrigatório se utm_source === 'offer' (manager_details)
  seller?: Seller; // Opcional: Dono do bem (seller_details)
  event?: Event; // Opcional: Contexto do leilão (event_details)
  offer?: Offer; // Opcional: Detalhes do bem e preço (offer_details)

  // Opcional: Detalhes do bem e preço (offer_details)
  consents?: Array<{
    consent_id: string;
    accepted: boolean;
    legal_text_snapshot?: unknown;
    accepted_at?: string;
    [key: string]: unknown;
  }>;

  // Campos de contexto injetados pelo Orquestrador
  rules?: JourneyRules;
  page_configs?: PageConfigs;
  consent_configs?: unknown;
  page_faqs?: unknown;

  // ROTEAMENTO
  is_integrated?: boolean; // Indica se a visita veio de um parceiro integrado (ex: Fandi, Cartão)
  integration_method?: string | null; // integration_method = 'API', 'EMAIL', 'FILE', 'MANUAL'
  integration_details?: Record<string, unknown>; // Permite enviar detalhes específicos do parceiro (ex: nome do parceiro, CNPJ, ponto de venda, webhook URL, etc.)
  product_id?: number;
  partner_id?: number;
  action?: "VISIT" | "CONSULT" | "REDIRECT" | "SIMULATE" | "CONTACT";
  action_description?: string; // Campo adicional para descrever a ação com mais detalhes (ex: 'REDIRECT_TO_WHATSAPP', 'SIMULATION_ELIGIBILITY_CHECK', etc.)
  visit_id?: string;
  visit_update_id?: string; // Identificador da visit_update da página atual
  origin_visit_update_id?: string; // Identificador da visit_update da página anterior
  simulation_id?: string;
  origin_url?: string;
  target_url?: string;
  // Auditoria/roteamento: anexados pelo Orquestrador e pelo Gateway
  raw_client_payload?: Record<string, unknown>; // thin payload original do cliente
  hydration_source?: string | null; // origem da oferta na hidratação (payload_offer_id | db_last_offer)
  config_matched_by?: string | null; // eixo que casou em orchestrator_configs
  orchestrator_config_id?: number | null;
}

/**
 * @interface OrchestratorResponse
 * @description Define o comando de saída enviado pelo Orquestrador para o cliente.
 * Determina como a transição de contexto (redirecionamento) deve ser executada.
 */
export interface OrchestratorResponse {
  /**
   * @property {string} action - O tipo de comportamento esperado:
   *   - 'REDIRECT': Navegação direta (ex: via location.href).
   *   - 'POST_REDIRECT': Requer submissão de formulário via POST (usado para dados sensíveis).
   */
  action: "REDIRECT" | "POST_REDIRECT";

  /** @property {string} url - O destino final já resolvido pela inteligência de roteamento. */
  url: string;

  /** @property {string} method - Método HTTP para a execução da ação ('GET' ou 'POST'). */
  method: "GET" | "POST";

  /**
   * @property {object} payload - Bloco de dados opcional para transporte de contexto.
   * @property {string} payload.visit_id - A chave mestra gerada para rastreabilidade da jornada.
   * @property {any} [payload.key] - Permite injetar outros identificadores necessários na página de destino.
   */
  payload?: {
    visit_id: string;
    [key: string]: unknown;
  };
}

/**
 * @interface SimulationResponse
 * @description Representa cada linha de consulta individual (Marketplace).
 * Cada item aqui será uma linha na tabela 'simulation_consults'.
 */
export interface SimulationResponse {
  success: boolean;
  message?: string;
  consults: Consultation[];
  // Audit Trail individual para esta linha
  raw: Record<string, unknown>;
}

/**
 * ETAPAS E STATUS DO FUNIL (ids de stage_types / status_types)
 * @description Cada status pertence a uma etapa (status_types.stage_id); Pendente envio,
 * Cancelada e Falha valem em qualquer etapa. Ver migration 20261025120000_stage_status_types.sql.
 */
export const STAGE = {
  PRE_ANALISE: 1,
  SIMULACAO: 2,
  PROPOSTA: 3,
  FORMALIZACAO: 4,
  PAGA: 5,
  LEAD: 6,
} as const;

export const STATUS = {
  PENDENTE_ENVIO: 0,
  APROVADA: 1, // Proposta
  RECUSADA: 2, // Proposta
  EM_ANALISE: 3, // Proposta
  PENDENTE_DOCUMENTOS: 4, // Proposta
  CONTRATO_ASSINADO: 5, // Formalização
  PAGA: 6, // Paga
  CANCELADA: 7,
  FALHA: 8,
  COM_CONDICOES: 9, // Simulação
  SEM_CONDICOES: 10, // Simulação
  ENVIADO: 11, // Lead
  PRE_APROVADO: 12, // Pré-análise
  NEGADO: 13, // Pré-análise
  EM_FORMALIZACAO: 14, // Formalização
} as const;

/** Etapa de cada status (status_types.stage_id). Ausente = vale em qualquer etapa. */
export const STAGE_OF_STATUS: Record<number, number> = {
  [STATUS.COM_CONDICOES]: STAGE.SIMULACAO,
  [STATUS.SEM_CONDICOES]: STAGE.SIMULACAO,
  [STATUS.ENVIADO]: STAGE.LEAD,
  [STATUS.PRE_APROVADO]: STAGE.PRE_ANALISE,
  [STATUS.NEGADO]: STAGE.PRE_ANALISE,
  [STATUS.EM_ANALISE]: STAGE.PROPOSTA,
  [STATUS.PENDENTE_DOCUMENTOS]: STAGE.PROPOSTA,
  [STATUS.APROVADA]: STAGE.PROPOSTA,
  [STATUS.RECUSADA]: STAGE.PROPOSTA,
  [STATUS.EM_FORMALIZACAO]: STAGE.FORMALIZACAO,
  [STATUS.CONTRATO_ASSINADO]: STAGE.FORMALIZACAO,
  [STATUS.PAGA]: STAGE.PAGA,
};

/**
 * @interface Consultation
 * @description Representa cada linha de consulta individual (Marketplace).
 * Cada item aqui será uma linha na tabela 'simulation_consults'.
 */
export interface Consultation {
  status_id: number | null; // ID sbX (1: Aprovado, 2: Negado, 8: Falha)
  is_selected: boolean | null; // Indica se esta consulta foi a escolhida pelo usuário (relevante para múltiplas opções)
  external_operation_id: string | null; // ID no parceiro (proposta)
  message: string | null; // Mensagem do banco/parceiro

  // Barramento Financeiro Específico desta Consulta
  financial_institution_id: number | null;
  financial_institution_name: string | null;
  requested_value: number | null;
  down_payment_amount: number | null;
  down_payment_percentage: number | null;
  financed_amount: number | null;
  installments: number | null;
  cet_rate: number | null;
  installment_value: number | null; // 1ª parcela (no PRICE, a parcela fixa)
  amortization_type?: string | null; // SAC | PRICE
  last_installment_value?: number | null; // última parcela
}

/**
 * @interface SimulationFinancials
 * @description Define os campos financeiros obrigatórios para cálculos e auditoria.
 */
export interface SimulationFinancials {
  requested_value: number | null; // Valor total do bem
  down_payment_amount: number | null; // Valor da entrada em R$
  down_payment_percentage: number | null; // % da entrada
  installments: number | null; // Número de parcelas
  financed_amount: number | null; // Valor que será efetivamente financiado
  cet_rate?: number | null; // Taxa CET (opcional na entrada, obrigatória no retorno)
  simulated_at?: string | null; // Timestamp da simulação
  installment_value?: number | null; // valor da parcela escolhida
  selected?: { banco?: string; idProduto?: string; idSeguradora?: string }; // condição escolhida na gaveta (FlowCredi)
  [key: string]: unknown | null; // Flexibilidade para taxas extras (IOF, TAC, etc)
}

/**
 * export interface: VehicleCollateral
 * @description Define a estrutura esperada para dados de garantia de veículos (Car Equity).
 */
export interface VehicleCollateral {
  license_plate: string; // Placa do veículo
  brand: string; // Marca (ex: Toyota)
  model: string; // Modelo (ex: Corolla)
  model_year: number; // Ano do modelo
  manufacture_year: number; // Ano de fabricação
  fipe_code: string; // Código Tabela FIPE
  fipe_value: number; // Valor de mercado FIPE
  kinship_degree: string; // Relação de parentesco do proprietário
}

/**
 * export interface: HomeCollateral
 * @description Define a estrutura esperada para dados de garantia de imóveis (Home Equity).
 */
export interface HomeCollateral {
  real_estate_type: string; // Tipo: HOUSE, APARTMENT, etc.
  estimated_value: number; // Valor estimado do imóvel
  debt_amount: number; // Saldo devedor atual
  has_deed: string; // Possui escritura? (YES/NO)
  address: string; // Logradouro
  number: string; // Número
  complement?: string; // Complemento (opcional)
  neighborhood: string; // Bairro
  city: string; // Cidade
  state: string; // Estado (UF)
  postal_code: string; // CEP
  country: string; // País
  owners: string[]; // Lista de proprietários
}

/**
 * @interface PageConfigs
 * @description Configuração visual da página da jornada (orchestrator_configs.page_configs).
 */
export interface PageConfigs {
  footer?: { template_text?: string; links?: { text: string; url: string }[] };
  offer_panel?: { partner?: { name?: string; label?: string } };
  partner?: { name?: string; label?: string };
  integration_details?: IntegrationDetails;
  [key: string]: unknown;
}

/** Dados do parceiro integrado (contato, webhook etc.). */
export interface IntegrationDetails {
  urlWhatsApp?: string;
  whatsapp_number?: string;
  [key: string]: unknown;
}

/**
 * @interface JourneyRules
 * @description Regras da jornada (orchestrator_configs.rules) lidas pelos motores de simulação.
 */
export interface JourneyRules {
  id?: string | number;
  payment_factors?: Record<string, number>; // prazo (meses) -> fator da parcela
  allow_custom_value?: boolean;
  max_offer_cap_percent?: number;
  min_down_payment_percentage?: number;
  max_down_payment_percentage?: number;
  max_financed_amount?: number;
  [key: string]: unknown;
}

/**
 * @interface SimulationPayload
 * @description Contrato mestre para o ecossistema sbX.
 * O uso de [key: string]: any permite que campos extras enviados pelo
 * front-end sejam aceitos sem quebrar a validação do TypeScript.
 */
export interface SimulationPayload {
  visit_id: string;
  simulation_id: string;
  is_integrated: boolean; // Indica se a simulação veio de um parceiro integrado (ex: Fandi, Cartão)
  integration_method: string; // integration_method = 'API', 'EMAIL', 'FILE', 'MANUAL'
  partner_id: number;
  product_id: number;
  action?: "VISIT" | "CONSULT" | "REDIRECT" | "SIMULATE" | "CONTACT";
  action_description?: string;

  // CONTEXTO DE VISITA (Sempre obrigatórios)
  interaction_context: InteractionContext; // Obrigatório: GPS da visita (origem/canal)
  entity?: Entity; // Obrigatório: Snapshot do proponente (entity_details)

  // CONTEXTO DE NEGÓCIO (Opcionais na raiz, validados por regra)
  manager?: Manager; // Obrigatório se utm_source === 'offer' (manager_details)
  seller?: Seller; // Opcional: Dono do bem (seller_details)
  event?: Event; // Opcional: Contexto do leilão (event_details)
  offer?: Offer; // Opcional: Detalhes do bem e preço (offer_details)
  simulation_details: SimulationFinancials;
  consents?: Array<{
    consent_id: string;
    accepted: boolean;
    legal_text_snapshot?: unknown;
    accepted_at?: string;
    [key: string]: unknown;
  }>;
  // Campos de contexto injetados pelo Orquestrador
  rules?: JourneyRules;
  page_configs?: PageConfigs;
  consent_configs?: unknown;
  page_faqs?: unknown;
  step?: "EXECUTE_SIMULATION" | "SUBMIT_LEAD";
  // Auditoria/roteamento: anexados pelo Orquestrador e pelo Gateway
  raw_client_payload?: Record<string, unknown>; // thin payload original do cliente
  hydration_source?: string | null; // origem da oferta na hidratação (payload_offer_id | db_last_offer)
  config_matched_by?: string | null; // eixo que casou em orchestrator_configs
  orchestrator_config_id?: number | null;
  integration_details?: IntegrationDetails;
  origin_url?: string;
  visit_update_id?: string;
  simulation_update_id?: string;
  target_url?: string;
  __integrity_validated?: boolean; // marca do Gateway: integridade já validada nesta requisição
  [key: string]: unknown; // Permite novos nós na raiz do payload
}

/**
 * @interface SimulationConsent
 * @description Estrutura para gravação na tabela 'simulation_consents'.
 * Garante o snapshot jurídico completo de cada termo aceito.
 */
export interface SimulationConsent {
  simulation_id: number;
  consent_id: string;
  accepted: boolean;
  accepted_at: string;
  partner_id: number;
  product_id: number;
  entity_id: string | null;
  document: string | null;
  name: string | null;
  phone: string | null;
  email: string | null;
  birth_date: string | null;
  gender: string | null;
  entity_details: unknown;
  ip_address: string;
  country: string;
  state: string;
  city: string;
  user_agent: string;
  device_type: string;
  operating_system: string;
  origin_details: unknown;
  manager_details: unknown;
  seller_details: unknown;
  event_details: unknown;
  offer_details: unknown;
  page_snapshot: {
    branding: unknown;
    rules: unknown;
    faq: unknown;
    consents_rendered: unknown;
    legal_text: unknown;
    [key: string]: unknown;
  };
  raw_payload: unknown;
}

/**
 * @interface SimulationUpdate
 * @description Estrutura para a tabela de logs 'simulation_updates'.
 */
export interface SimulationUpdate {
  simulation_id: number;
  operation: "INSERT" | "UPDATE" | "DELETE";
  stage_id: number;
  status_id: number;
  simulation_details: SimulationFinancials;
  ip_address: string;
  country: string;
  state: string;
  city: string;
  user_agent: string;
  device_type: string;
  operating_system: string;
  origin_details: unknown;
  raw_payload: unknown;
}

/**
 * @interface EmailTemplateResult
 * @description Estrutura de retorno padronizada para as funções geradoras de template de e-mail.
 * Encapsula o HTML processado e os metadados dos anexos embutidos (CID), garantindo que o
 * serviço de disparo permaneça agnóstico em relação ao conteúdo visual e regras de negócio.
 */
export interface EmailTemplateResult {
  html: string;
  attachments: Array<{
    content_id: string; // O CID para embutir no HTML
    storage_path: string; // O caminho da imagem no Bucket
  }>;
}

/**
 * @fileoverview Contratos de Dados (Shared Types) - Ecossistema sbX
 * Centraliza as interfaces de dados que trafegam entre o Upstream (Superbid),
 * o Gateway (BFF) e o Frontend.
 *
 * * [PADRONIZAÇÃO]:
 * 1. Interfaces seguem a nomenclatura BFF (Backend For Frontend).
 * 2. Campos são mapeados para facilitar a legibilidade no frontend (camelCase).
 * 3. Esta estrutura elimina a redundância de buscar dados repetidamente.
 */

// =========================================================================
// [1] USUÁRIO: Perfil Identitário
// =========================================================================
export interface BFFUserProfile {
  entity_id: string; // ID único do usuário no ecossistema
  entity_type: "F" | "J"; // Tipo de entidade: "F" (Física) ou "J" (Jurídica)
  name: string; // Nome completo
  document: string; // CPF/CNPJ (Mapeado)
  email: string; // E-mail principal de contato
  phone: string; // Telefone formatado
  birth_date: string; // Data de nascimento ISO
  gender: "M" | "F"; // Gênero
  login: string; // Usuário de login
  mothers_name: string; // Nome da mãe
  address: {
    street: string;
    number: string;
    complement: string;
    neighborhood: string;
    city: string;
    state: string;
    zip_code: string;
    country: string;
  } | null;
  metadata: {
    processedAt: string;
    originIp: string;
  };
}

// =========================================================================
// [2] OFERTA: Detalhamento do Lote e Entidades Associadas
// =========================================================================
export interface BFFOfferPhoto {
  highlight: boolean;
  link: string;
  thumbnail?: string;
  file_name?: string;
  type: string;
  content_type: string;
}

export interface BFFOfferDetails {
  offer: {
    offer_id: string;
    lot_number: string | number;
    offer_description: string;
    offer_detailed_description: string;
    offer_value: number;
    category_id: number;
    category: string;
    offer_status: string;
    sale_status: string;
    end_date: string;
    photos: BFFOfferPhoto[];
  };
  manager: {
    manager_id: number;
    manager_name: string;
  };
  event: {
    event_id: string;
    event_description: string;
    event_start_date: string;
    event_end_date: string;
    modality_id: number | null;
    status_id: number | null;
    event_short_description: string;
    event_full_description: string;
    event_image_url: string;
  };
  seller: {
    seller_id: string;
    legal_name: string;
    trade_name: string;
    economic_group: string;
  };
}

// =========================================================================
// [3] REIDRATAÇÃO: O Payload "Barba, Cabelo e Bigode"
// =========================================================================
/**
 * Interface de resposta unificada para a Edge Function de Exchange.
 * Permite que o frontend inicialize a aplicação com tudo o que precisa
 * em uma única chamada de rede (Zero-latency start).
 */
export interface BFFRehydrationPayload {
  user_profile: BFFUserProfile;
  offer_details: BFFOfferDetails | null; // Nullável caso a chamada seja apenas de autenticação
}

// =========================================================================
// [4] RESPONSE: Estrutura final da Edge Function (sbx-auth-exchange)
// =========================================================================
export interface BFFAuthExchangeResponse {
  success: boolean;
  session_token: string;
  user_id: string;
  expires_at: number;
  server_now_ms: number;
  rehydration_payload: BFFRehydrationPayload; // Aqui reside o combo completo
}

/**
 * =========================================================================
 * 🤖 GEMINI ARCHITECTURE SPECIFICATION: ZERO-TRUST PAYLOAD CONTRACTS
 * =========================================================================
 * Contratos complementares adicionados para suportar o modelo Zero-Trust sem
 * quebrar a base de código legada (React Frontend).
 *
 * [MUDANÇAS ARQUITETURAIS]:
 * 1. {ThinPayload}: O único contrato aceitável no Frontend. Garante a dieta
 *    de rede e impede Mass Assignment.
 * 2. {EnrichedPayload}: O contrato restrito do Backend. Representa a junção
 *    perfeita entre o pedido do usuário e a verdade irrefutável do servidor.
 */

// =========================================================================
// [ZERO-TRUST] CONTRATOS DE PAYLOAD (THIN / ENRICHED)
// =========================================================================

/**
 * @interface ThinPayload
 * @description O ÚNICO formato que o cliente tem permissão de enviar.
 * Só intenção, ponteiros e escolhas do usuário. Zero PII, zero valor de oferta.
 * É exatamente a superfície que `pickThin` deixa passar.
 *
 * FONTE ÚNICA DO CONTRATO: `pickThin` em `_shared/hydrate-data.ts`. O front
 * (THIN_KEYS em src/features/financial-hub/core/services/gateway.ts) apenas
 * espelha esta lista. Chaves de contexto de negócio (`entity_id`,
 * `category_id`, `event_id`, `seller_id`) NÃO fazem parte do contrato: são
 * derivadas server-side de `ctx.trusted*` e ignoradas se enviadas.
 */
export interface ThinPayload {
  visit_id: string;
  visit_update_id: string;
  /** Cursor da página anterior; usado para encadear visit_updates na auditoria. */
  origin_visit_update_id?: string | null;
  offer_id?: string | number | null;
  action?: "VISIT" | "CONSULT" | "REDIRECT" | "SIMULATE" | "CONTACT";
  action_description?: string;
  simulation_id?: string | null;
  simulation_update_id?: string | null;
  product_id?: number;
  partner_id?: number;
  step?: string;
  origin_url?: string;
  target_url?: string;
  interaction_context?: Record<string, unknown>;
  consents?: Array<Record<string, unknown>>;
  /** Apenas inputs do usuário: prazo, entrada, opções. NUNCA preço da oferta. */
  simulation_details?: Record<string, unknown>;
}

/**
 * @interface EnrichedPayload
 * @description O payload reconstruído SERVER-SIDE após a hidratação.
 * É o que trafega internamente entre gateway -> handlers -> persistência.
 * Nunca é aceito na entrada HTTP e nunca é devolvido cru ao cliente.
 */
export interface EnrichedPayload extends ThinPayload {
  entity: Entity;
  offer: Offer | null;
  manager: Manager | null;
  seller: Seller | null;
  event: Event | null;
  origin_details: OriginDetails;
  /** Configuração de jornada resolvida server-side (rules / page_configs). */
  resolved_config?: {
    partner_id: number;
    product_id: number;
    is_integrated: boolean;
    integration_method: string;
    integration_details: Record<string, unknown>;
    rules: Record<string, unknown>;
    page_configs: Record<string, unknown>;
  };
  /** Procedência da oferta usada, para auditoria forense. */
  hydration_source?: "payload_offer_id" | "db_last_offer" | "no_offer";
}
