Edite só o arquivo `src/routes/produtos.offer.lazy.tsx`. Não altere nada além desta linha e não rode formatação.

Dentro do `logSystemError({ ... })` do catch da busca de ofertas, troque:

```
          payload: { user_id: userId || "UNAUTHENTICATED", flow_key: flowKey },
```

por:

```
          raw_payload: { user_id: userId || "UNAUTHENTICATED", flow_key: flowKey },
```
