# Ajustes 7 (2026-10-24) · padrão do app e regras do React

Substitui o ajustes5 e o ajustes6: aplique só este. O prompt 10 traz a versão final do arquivo do ajustes5.

## Lovable: prompts na ordem
01 home-equity.manifest.ts ... novo nome de homeEquity.manifest.ts
02 home-equity.types.ts ... novo nome de homeEquity.types.ts
03 auto-equity.types.ts ... novo nome de autoEquity.types.ts
04 Step1Property.tsx ... import do arquivo renomeado
05 Step2Simulation.tsx ... import do arquivo renomeado
06 Step1Vehicle.tsx ... import do arquivo renomeado
07 Step2Credit.tsx ... import do arquivo renomeado
08 Step3Income.tsx ... import do arquivo renomeado
09 emprestimos.home-equity.lazy.tsx ... import do manifesto renomeado
10 Step1Simulation.tsx ... abre com 80% financiado + aviso do React corrigido (substitui o ajustes5)
11 FlowLeadStep.tsx ... validação dos aceites no padrão de Veículos
12 financiamentos.veiculos.lazy.tsx ... trava depois do useEffect (regra do React)
13 financiamentos.cartao.lazy.tsx ... idem
14 financiamentos.simulacao.lazy.tsx ... idem
15 seguros.auto.lazy.tsx ... idem
16 emprestimos.auto-equity.lazy.tsx ... idem
17 apagar homeEquity.manifest.ts, homeEquity.types.ts, autoEquity.types.ts
18 produtos.offer.lazy.tsx ... campo do log de erro da busca (payload → raw_payload; troca de 1 linha)

Nenhuma tela muda de comportamento, exceto Imóveis (abre com 80% financiado).
Sem migration e sem deploy de função.
