# Tipagem gateway + orchestrator, parte 2 (2026-10-25)

Aplicar depois do tipos_gateway.

Só tipos, sem mudança de comportamento. Tira os `any` do financial-gateway e do orchestrator,
exceto os 12 da conexão com o banco (sql/t do postgres).

## Lovable: prompts na ordem
01 _shared/types.ts ... JourneyRules (regras da jornada)
02 orchestrator/index.ts
03 orchestrator/persist-data.ts
04 financial-gateway/index.ts
05 financial-gateway/simulation-handler.ts
06 financial-gateway/persist-data.ts
07 financial-gateway/fandi-service.ts
08 financial-gateway/partner-service.ts
09 financial-gateway/credit-card-service.ts

## Deploy
financial-gateway e orchestrator (homol).

Sem migration.
