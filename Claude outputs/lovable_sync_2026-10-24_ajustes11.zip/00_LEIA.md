# Ajustes 11 (2026-10-24)

Aplicar DEPOIS do ajustes10.

## Lovable: prompts na ordem
01 card/card.types.ts ... rules pode vir null (faltou no ajustes10 — corrige o erro de tipo do cartão)
02 partner/steps/Step2Confirm.tsx ... tira a leitura de campos antigos do retorno que o servidor não manda mais
03 veiculos/steps/Step2Confirm.tsx ... idem + valorOferta (nunca gravado em Veículos)
04 veiculos/veiculos.types.ts ... sem valorOferta

Os valores mostrados nas telas de confirmação não mudam (os campos retirados sempre vinham vazios).
Sem migration e sem deploy de função.
