Regenere o arquivo `src/integrations/supabase/types.ts` a partir do banco Supabase conectado a este projeto (tipos atuais de tabelas, views e funções). Não altere nenhum outro arquivo.

Se não for possível regenerar, me avise antes de alterar qualquer coisa.
