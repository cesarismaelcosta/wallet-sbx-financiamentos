# Ajustes 13 (2026-10-24) · área 4 dos `any` (backoffice) + correções do ajustes12

Aplicar DEPOIS do ajustes12.

Só tipos do TypeScript: nada muda no que roda no navegador.

## Lovable: prompts na ordem
01 features/financial-hub/components/shared/renderes/ChartsSimulation.tsx ... rótulos dos gráficos aceitam os tipos do recharts de homol (erros do ajustes12)
02 features/financial-hub/components/shared/renderes/ChartsTraffic.tsx ... idem
03 features/financial-hub/components/shared/types.ts ... tipos centrais: listas podem vir null, id opcional do parceiro
04 routes/backoffice.alerts.lazy.tsx
05 routes/backoffice.audit.lazy.tsx
06 routes/backoffice.consults.lazy.tsx
07 routes/backoffice.routes.lazy.tsx
08 routes/backoffice.simulations.lazy.tsx
09 routes/backoffice.users.lazy.tsx
10 supabase/types.ts ... pedir ao Lovable para regenerar a partir do banco de homol (a versão de dev vai em referencia_dev/ só para comparar)

Sem migration e sem deploy de função.
