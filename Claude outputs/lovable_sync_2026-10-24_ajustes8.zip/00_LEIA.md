# Ajustes 8 (2026-10-24) · regras do React e limpeza

Aplicar DEPOIS do ajustes7.

- Busca da tela de rotas do backoffice não quebra mais com lookup_id numérico
- FinancialHubLayout: useEffect do redirecionamento em componente próprio (regra dos hooks)
- Avisos de dependência: rotas de produto ajustadas; efeitos que rodam de propósito só em certos momentos ganharam comentário explicando (sem mudar o código)
- Limpeza: let → const, bloco vazio comentado, 2 comentários de aviso sem uso removidos

## Lovable: prompts na ordem
01 FinancialHubLayout.tsx (layout) ... arquivo inteiro
02 Step1Simulation.tsx (cartão) ... arquivo inteiro
03 Step1Simulation.tsx (partner) ... arquivo inteiro
04 Step1Simulation.tsx (veículos) ... arquivo inteiro
05 useOrchestratorHistorySync.ts (hooks) ... arquivo inteiro
06 AuthContext.tsx (auth) ... arquivo inteiro
07 backoffice.login.lazy.tsx (routes) ... arquivo inteiro
08 backoffice.audit.lazy.tsx (routes) ... arquivo inteiro
09 backoffice.consults.lazy.tsx (routes) ... arquivo inteiro
10 backoffice.index.lazy.tsx (routes) ... arquivo inteiro
11 backoffice.users.lazy.tsx (routes) ... arquivo inteiro
12 sandbox.lazy.tsx (routes) ... arquivo inteiro
13 produtos.lazy.tsx (routes) ... arquivo inteiro
14 backoffice.routes.lazy.tsx ... 4 troca(s) pontual(is)
15 backoffice.simulations.lazy.tsx ... 1 troca(s) pontual(is)
16 produtos.offer.lazy.tsx ... 1 troca(s) pontual(is)
17 produtos.index.lazy.tsx ... 1 troca(s) pontual(is)
18 financiamentos.veiculos.lazy.tsx ... 1 troca(s) pontual(is)
19 financiamentos.cartao.lazy.tsx ... 1 troca(s) pontual(is)
20 financiamentos.simulacao.lazy.tsx ... 1 troca(s) pontual(is)
21 seguros.auto.lazy.tsx ... 1 troca(s) pontual(is)
22 emprestimos.auto-equity.lazy.tsx ... 1 troca(s) pontual(is)
23 financiamentos.imoveis.lazy.tsx ... 1 troca(s) pontual(is)
24 emprestimos.home-equity.lazy.tsx ... 1 troca(s) pontual(is)

Sem migration e sem deploy de função.
