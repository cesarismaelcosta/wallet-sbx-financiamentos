Edite só o arquivo `src/routes/backoffice.routes.lazy.tsx`. Faça apenas as trocas abaixo, exatamente como estão, sem alterar mais nada e sem rodar formatação.

### Troca 1
Troque:

```
          (String(r.id) ?? "").toLowerCase().includes(query) ||
          (r.lookup_id ?? "").toLowerCase().includes(query) ||
```

por:

```
          String(r.id ?? "").toLowerCase().includes(query) ||
          String(r.lookup_id ?? "").toLowerCase().includes(query) ||
```

### Troca 2
Troque:

```
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { id, created_at, ...rest } = config;
```

por:

```
    const { id, created_at, ...rest } = config;
```

### Troca 3
Troque:

```
      setEntries(currentEntriesObj.map(([term, factor]) => ({ term, factor })));
    }
  }, [factors]);
```

por:

```
      setEntries(currentEntriesObj.map(([term, factor]) => ({ term, factor })));
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps -- sincroniza só quando os fatores recebidos mudam
  }, [factors]);
```

### Troca 4
Troque:

```
        return idA - idB;
      });
  }, [rows, search, statusFilter, productsMap, categoriesMap]);
```

por:

```
        return idA - idB;
      });
  // eslint-disable-next-line react-hooks/exhaustive-deps -- getProductOrCategoryName depende de productsMap/categoriesMap, já listados
  }, [rows, search, statusFilter, productsMap, categoriesMap]);
```
