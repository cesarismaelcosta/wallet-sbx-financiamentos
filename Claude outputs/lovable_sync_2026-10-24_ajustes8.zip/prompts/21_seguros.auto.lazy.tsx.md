Edite só o arquivo `src/routes/seguros.auto.lazy.tsx`. Faça apenas as trocas abaixo, exatamente como estão, sem alterar mais nada e sem rodar formatação.

### Troca 1
Troque:

```
  useEffect(() => {
    if (simData?.setIsOrchestratorHydrating) {
      const timer = setTimeout(() => simData.setIsOrchestratorHydrating(false), 50);
      return () => clearTimeout(timer);
    }
  }, [simData?.setIsOrchestratorHydrating]);
```

por:

```
  const setIsOrchestratorHydrating = simData?.setIsOrchestratorHydrating;
  useEffect(() => {
    if (setIsOrchestratorHydrating) {
      const timer = setTimeout(() => setIsOrchestratorHydrating(false), 50);
      return () => clearTimeout(timer);
    }
  }, [setIsOrchestratorHydrating]);
```
