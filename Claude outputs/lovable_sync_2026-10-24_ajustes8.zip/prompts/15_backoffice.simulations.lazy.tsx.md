Edite só o arquivo `src/routes/backoffice.simulations.lazy.tsx`. Faça apenas as trocas abaixo, exatamente como estão, sem alterar mais nada e sem rodar formatação.

### Troca 1
Troque:

```
    const timeoutId = setTimeout(() => { setPage(0); load(0); loadStats(); }, 400);
    return () => clearTimeout(timeoutId);
  }, [search, selectedPartners, selectedProducts, dateRange, customRange]);
```

por:

```
    const timeoutId = setTimeout(() => { setPage(0); load(0); loadStats(); }, 400);
    return () => clearTimeout(timeoutId);
  // eslint-disable-next-line react-hooks/exhaustive-deps -- recarrega só quando os filtros mudam
  }, [search, selectedPartners, selectedProducts, dateRange, customRange]);
```
