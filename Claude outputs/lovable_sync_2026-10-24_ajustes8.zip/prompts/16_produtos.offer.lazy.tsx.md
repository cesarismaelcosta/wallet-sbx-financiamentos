Edite só o arquivo `src/routes/produtos.offer.lazy.tsx`. Faça apenas as trocas abaixo, exatamente como estão, sem alterar mais nada e sem rodar formatação.

### Troca 1
Troque:

```
    loadOffers();
    return () => controller.abort();
  }, [currentFlow.product_id, currentSort, pageNumber, sessionToken, flowKey, selectedCategory, selectedPropertyCategory, selectedState]);
```

por:

```
    loadOffers();
    return () => controller.abort();
  // eslint-disable-next-line react-hooks/exhaustive-deps -- recarrega só quando os filtros/página mudam
  }, [currentFlow.product_id, currentSort, pageNumber, sessionToken, flowKey, selectedCategory, selectedPropertyCategory, selectedState]);
```
