Edite só o arquivo `src/routes/produtos.index.lazy.tsx`. Faça apenas as trocas abaixo, exatamente como estão, sem alterar mais nada e sem rodar formatação.

### Troca 1
Troque:

```
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [errorKey]);
```

por:

```
    };
  }, [errorKey]);
```
