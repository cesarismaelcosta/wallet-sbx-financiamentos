/**
 * @fileoverview Componente: SimulationCharts (Módulo de Gráficos de Simulação)
 * 
 * ============================================================================
 * [ARQUITETURA E RESPONSIVIDADE - ZERO-RADIUS & NEUTRAL PURITY]
 * ============================================================================
 * Este componente renderiza a evolução de simulações e o detalhamento por status, 
 * produto e parceiro. 
 * 
 * Correções aplicadas (Zero Efeitos Colaterais):
 * 1. Zero-Radius: Todos os cantos arredondados das barras do Recharts e dos
 *    cards externos (`rounded-2xl`) foram substituídos por `rounded-none` ou 
 *    `radius={[0,0,0,0]}`.
 * 2. Neutral Purity: Extinção da paleta de cores roxa/magenta hardcoded (`barColors`)
 *    e de referências ao `--primary`. Utiliza a escala de cinzas `neutral-900` a `neutral-300`.
 * 3. Margens Dinâmicas (`right`): No desktop, a margem direita do BarChart expande 
 *    para 130px para abrigar valores monetários longos (ex: R$ 2.164.871) sem cortar.
 *    No mobile, encolhe para 60px para otimizar o espaço da tela.
 */

import { Loader2 } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Cell, LabelList } from "recharts";
import type { LabelProps } from "recharts";
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from "@/components/ui/chart";
// ✨ [PERFORMANCE]: Hook canônico do projeto (matchMedia + evento "change"), em vez de uma
// definição local ouvindo "resize" bruto — que disparava um re-render (incluindo os BarChart
// do Recharts) a cada pixel arrastado ao redimensionar a janela.
import { useIsMobile } from "@/hooks/use-mobile";

// ============================================================================
// [CONSTANTES E HELPERS]
// ============================================================================
// Tinta escura (evolução diária) + rampa azul do design system (--chart-1/2/3)
// para os rankings — validada como escala ordinal (monotônica, contraste >=2:1
// no tom mais claro contra o card branco, tons distinguíveis entre si). Ver
// skill de dataviz. Ciclo de 3 tons; rankings com mais de 3 itens repetem o
// tom mais claro (identidade real já vem do rótulo direto em cada barra).
const darkInk = "hsl(var(--foreground))"; // token do tema (adapta claro/escuro)
const chartBlues = ["hsl(var(--chart-1))", "hsl(var(--chart-2))", "hsl(var(--chart-3))"]; // tokens do tema (adapta claro/escuro)

const BRL = (n: number) => 
  n.toLocaleString("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: 0 });

const defaultChartConfig = {
  count: { label: "Quantidade", color: darkInk },
} satisfies ChartConfig;

// ============================================================================
// [COMPONENTE PRINCIPAL]
// ============================================================================
/** Item de gráfico de barras (status, produto, parceiro). */
type ChartItem = { name: string; count: number; volume: number };
/** Ponto do gráfico diário (dia já formatado). */
type DailyPoint = { day: string; count: number };
/** Indicadores usados aqui (o painel do backoffice manda o objeto completo). */
type SimChartKpis = { byStatus?: ChartItem[]; byProduct?: ChartItem[]; byPartner?: ChartItem[] };

export default function SimulationCharts({
  loading,
  simKpis,
  simDailyData,
  periodLabel,
}: {
  loading: boolean;
  simKpis: SimChartKpis | null | undefined;
  simDailyData: DailyPoint[];
  periodLabel: string;
}) {
  // ✨ Hook de responsividade injetado
  const isMobile = useIsMobile();

  return (
    <div className="space-y-6">
      
      {/* ---------------------------------------------------------------------
          GRÁFICO 1: EVOLUÇÃO DIÁRIA (Linha do Tempo)
      --------------------------------------------------------------------- */}
      <div className="grid grid-cols-1 gap-4">
        <div className="rounded-none border border-border bg-card p-5 shadow-sm">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h3 className="text-[11px] font-bold uppercase tracking-wider text-card-foreground">Evolução de Simulações Diárias</h3>
              <p className="text-xs text-muted-foreground font-medium mt-1">{periodLabel}</p>
            </div>
          </div>
          
          {loading || !simKpis ? (
            <div className="h-[240px] flex items-center justify-center text-muted-foreground font-medium">
              <Loader2 className="h-4 w-4 animate-spin mr-2 text-foreground" />
              Carregando...
            </div>
          ) : (
            <ChartContainer config={defaultChartConfig} className="h-[240px] w-full min-w-0">
              <BarChart data={simDailyData} margin={{ top: 24, right: 0, left: -24, bottom: 0 }}>
                <CartesianGrid vertical={false} strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="day" tickLine={false} axisLine={false} tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} interval="preserveStartEnd" />
                <YAxis hide />
                <ChartTooltip cursor={{ fill: "hsl(var(--muted))", opacity: 0.8 }} content={<ChartTooltipContent className="rounded-none shadow-md border-border" />} />
                <Bar dataKey="count" fill={darkInk} radius={[0, 0, 0, 0]}>
                  <LabelList dataKey="count" position="top" offset={6} className="fill-foreground" fontSize={11} fontWeight={700} formatter={(v: unknown) => (Number(v) > 0 ? (v as number | string) : "")} />
                </Bar>
              </BarChart>
            </ChartContainer>
          )}
        </div>
      </div>

      {/* ---------------------------------------------------------------------
          GRÁFICOS 2, 3 E 4: ANÁLISE VERTICAL (Status, Produto, Parceiro)
      --------------------------------------------------------------------- */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {[
          { title: "Status da Proposta", data: simKpis?.byStatus },
          { title: "Por Produto", data: simKpis?.byProduct },
          { title: "Por Parceiro", data: simKpis?.byPartner },
        ].map((chart, idx) => (
          <div key={chart.title} className="rounded-none border border-border bg-card p-5 overflow-hidden shadow-sm">
            <div className="mb-4">
              <h3 className="text-[11px] font-bold uppercase tracking-wider text-card-foreground">{chart.title}</h3>
              <p className="text-xs text-muted-foreground font-medium mt-1">{periodLabel}</p>
            </div>
            
            {loading || !chart.data ? (
              <div className="h-[240px] flex items-center justify-center text-muted-foreground font-medium">
                <Loader2 className="h-4 w-4 animate-spin mr-2 text-foreground" />
                Carregando...
              </div>
            ) : chart.data.length === 0 ? (
              <p className="text-sm text-muted-foreground font-medium text-center mt-10">Nenhum dado no período.</p>
            ) : (
              <ChartContainer config={defaultChartConfig} className="h-[240px] w-full">
                {/* ✨ FIX RESPONSIVO: Margem direita dinâmica para evitar corte dos valores monetários */}
                <BarChart 
                  data={chart.data} 
                  layout="vertical" 
                  margin={{ top: 0, right: isMobile ? 100 : 130, left: 0, bottom: 0 }}
                >
                  <CartesianGrid horizontal={false} strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis type="number" hide />
                  
                  {/* ✨ FIX RESPONSIVO: Largura do Eixo Y dinâmica para não espremer a barra */}
                  <YAxis 
                    type="category" 
                    dataKey="name" 
                    tickLine={false} 
                    axisLine={false} 
                    tick={{ fontSize: isMobile ? 10 : 11, fill: "hsl(var(--muted-foreground))", fontWeight: 500 }} 
                    width={isMobile ? 80 : 120}
                  />
                  
                  <ChartTooltip
                    cursor={{ fill: "hsl(var(--muted))", opacity: 0.8 }}
                    content={
                      <ChartTooltipContent
                        className="rounded-none shadow-md border-border"
                        formatter={(value, _name, item) => (
                          <div className="flex flex-col">
                            <span className="font-bold text-popover-foreground">{value} simulações</span>
                            <span className="text-xs font-medium text-muted-foreground">{BRL(item.payload.volume)}</span>
                          </div>
                        )}
                      />
                    }
                  />
                  <Bar dataKey="count" radius={[0, 0, 0, 0]} maxBarSize={28}>
                    {chart.data.map((_: unknown, i: number) => (
                      <Cell key={i} fill={chartBlues[i % chartBlues.length]} />
                    ))}
                    <LabelList
                      dataKey="count"
                      position="right"
                      content={(props: LabelProps) => {
                        const item = chart.data![props.index as number];
                        if (!item) return null;
                        
                        // Cálculos precisos de ancoragem para o texto do Recharts
                        const cx = Number(props.x) + Number(props.width) + 8;
                        const cy = Number(props.y) + Number(props.height) / 2;
                        
                        return (
                          <g>
                            <text x={cx} y={cy - 6} fill="hsl(var(--foreground))" fontSize={11} fontWeight={700} dominantBaseline="middle">
                              {props.value}
                            </text>
                            <text x={cx} y={cy + 8} fill="hsl(var(--muted-foreground))" fontSize={10} fontWeight={500} dominantBaseline="middle">
                              {BRL(item.volume)}
                            </text>
                          </g>
                        );
                      }}
                    />
                  </Bar>
                </BarChart>
              </ChartContainer>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}