Edite só o arquivo `src/services/offer.ts`. Faça apenas as trocas abaixo, exatamente como estão, sem alterar mais nada e sem rodar formatação.

### Troca 1
Troque:

```
import { fetchOptions, authHeaders } from "@/services/session";
import { ROOT_ROUTE } from "@/config/routes";

interface FetchOfferOptions {
```

por:

```
import { fetchOptions, authHeaders } from "@/services/session";
import { ROOT_ROUTE } from "@/config/routes";
import type { CaughtError } from "@/features/financial-hub/components/shared/types";

interface FetchOfferOptions {
```

### Troca 2
Troque:

```
    return result.data || result;

  } catch (error: any) {
    if (error.name === 'AbortError' || signal?.aborted) {
      throw error;
```

por:

```
    return result.data || result;

  } catch (caught: unknown) {
    const error = caught as CaughtError;
    if (error.name === 'AbortError' || signal?.aborted) {
      throw error;
```

### Troca 3
Troque:

```
// =========================================================================

/**
 * Consulta ao BFF responsável pela tradução de intenção estruturada de prateleira
```

por:

```
// =========================================================================

/** Resultado da busca de ofertas: lista (cada item com oferta, evento e vendedor) + total. */
export interface OffersQueryResult {
  offers?: Record<string, unknown>[];
  total?: number;
  [key: string]: unknown;
}

/**
 * Consulta ao BFF responsável pela tradução de intenção estruturada de prateleira
```

### Troca 4
Troque:

```
  params: FetchOffersQueryParams,
  { signal, originUrl }: FetchOfferOptions = {}
): Promise<any> {
  
  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
```

por:

```
  params: FetchOffersQueryParams,
  { signal, originUrl }: FetchOfferOptions = {}
): Promise<OffersQueryResult> {
  
  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
```

### Troca 5
Troque:

```
    // item da lista antes de entregar para o Front-end
    if (payload && Array.isArray(payload.offers)) {
      payload.offers = payload.offers.map((item: any) => item.data || item);
    }

    return payload;

  } catch (error: any) {
    if (error.name === 'AbortError' || signal?.aborted) {
      throw error;
```

por:

```
    // item da lista antes de entregar para o Front-end
    if (payload && Array.isArray(payload.offers)) {
      payload.offers = payload.offers.map((item: { data?: Record<string, unknown> } & Record<string, unknown>) => item.data || item);
    }

    return payload;

  } catch (caught: unknown) {
    const error = caught as CaughtError;
    if (error.name === 'AbortError' || signal?.aborted) {
      throw error;
```
