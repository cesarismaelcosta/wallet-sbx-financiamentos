Substitua todo o conteúdo de o arquivo `src/design-system/sbx-design-system-9f1c03/index.ts` com exatamente o conteúdo abaixo. Não altere nada além deste arquivo e não rode formatação.

```
import "./index.css";

export * from "./components/ui/accordion";
export * from "./components/ui/alert-dialog";
export * from "./components/ui/alert";
export * from "./components/ui/aspect-ratio";
export * from "./components/ui/avatar";
export * from "./components/ui/badge";
export * from "./components/ui/breadcrumb";
export * from "./components/ui/button";
export * from "./components/ui/button-group";
export * from "./components/ui/card";
export * from "./components/ui/carousel";
export * from "./components/ui/checkbox";
export * from "./components/ui/collapsible";
export * from "./components/ui/command";
export * from "./components/ui/context-menu";
export * from "./components/ui/dialog";
export * from "./components/ui/drawer";
export * from "./components/ui/dropdown-menu";
export * from "./components/ui/empty";
export * from "./components/ui/field";
export * from "./components/ui/form";
export * from "./components/ui/gradient-icon";
export * from "./components/ui/hover-card";
export * from "./components/ui/input-group";
export * from "./components/ui/input-otp";
export * from "./components/ui/input";
export * from "./components/ui/item";
export * from "./components/ui/kbd";
export * from "./components/ui/label";
export * from "./components/ui/menubar";
export * from "./components/ui/navigation-menu";
export * from "./components/ui/pagination";
export * from "./components/ui/popover";
export * from "./components/ui/progress";
export * from "./components/ui/radio-group";
export * from "./components/ui/scroll-area";
export * from "./components/ui/select";
export * from "./components/ui/separator";
export * from "./components/ui/sheet";
export * from "./components/ui/sidebar";
export * from "./components/ui/skeleton";
export * from "./components/ui/slider";
export { Toaster as SonnerToaster, toast } from "./components/ui/sonner";
export * from "./components/ui/spinner";
export * from "./components/ui/stepper";
export * from "./components/ui/switch";
export * from "./components/ui/table";
export * from "./components/ui/tabs";
export * from "./components/ui/textarea";
export * from "./components/ui/toast";
export * from "./components/ui/toaster";
export * from "./components/ui/toggle-group";
export * from "./components/ui/toggle";
export * from "./components/ui/tooltip";

export { ThemeProvider, useTheme } from "./components/ThemeProvider";
export { ThemeToggle } from "./components/ThemeToggle";
export { PageHeader } from "./components/PageHeader";
export { cn } from "./lib/utils";

export { useToast } from "./hooks/use-toast";
export { useIsMobile } from "./hooks/use-mobile";

```
