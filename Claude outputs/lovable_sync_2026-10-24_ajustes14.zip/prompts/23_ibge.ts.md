Edite só o arquivo `src/services/ibge.ts`. Faça apenas as trocas abaixo, exatamente como estão, sem alterar mais nada e sem rodar formatação.

### Troca 1
Troque:

```
      return r.json();
    })
    .then((rows: any[]) => (Array.isArray(rows) ? rows.map((m) => String(m?.nome ?? "")).filter(Boolean) : []))
    .catch((err) => {
      cache.delete(key); // permite tentar de novo depois
```

por:

```
      return r.json();
    })
    .then((rows: { nome?: string }[]) => (Array.isArray(rows) ? rows.map((m) => String(m?.nome ?? "")).filter(Boolean) : []))
    .catch((err) => {
      cache.delete(key); // permite tentar de novo depois
```
