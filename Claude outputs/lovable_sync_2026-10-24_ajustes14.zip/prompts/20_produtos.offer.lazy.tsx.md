Edite só o arquivo `src/routes/produtos.offer.lazy.tsx`. Faça apenas as trocas abaixo, exatamente como estão, sem alterar mais nada e sem rodar formatação.

### Troca 1
Troque:

```
import { CardOfferVSkeleton } from "@/features/financial-hub/components/shared/renderes/CardOfferVSkeleton";
import { HOME_ROUTE, buildSigninRedirect } from "@/config/routes";

// =========================================================================
```

por:

```
import { CardOfferVSkeleton } from "@/features/financial-hub/components/shared/renderes/CardOfferVSkeleton";
import { HOME_ROUTE, buildSigninRedirect } from "@/config/routes";
import type { CaughtError } from "@/features/financial-hub/components/shared/types";
import type { LucideIcon } from "lucide-react";
import type { CardOfferItem } from "@/features/financial-hub/components/shared/renderes/CardOfferV";

// =========================================================================
```

### Troca 2
Troque:

```
// [COMPONENTE DROPDOWN DESKTOP - SBX DESIGN SYSTEM]
// =========================================================================
function DesktopDropdown({ icon: Icon, label, value, options, onChange, align = "left" }: any) {
  const [isOpen, setIsOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
```

por:

```
// [COMPONENTE DROPDOWN DESKTOP - SBX DESIGN SYSTEM]
// =========================================================================
interface DesktopDropdownProps {
  icon?: LucideIcon;
  label: string;
  value: string;
  options: { label: string; value: string }[];
  onChange: (value: string) => void;
  align?: "left" | "right";
}

function DesktopDropdown({ icon: Icon, label, value, options, onChange, align = "left" }: DesktopDropdownProps) {
  const [isOpen, setIsOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
```

### Troca 3
Troque:

```
  }, []);

  const displayLabel = options.find((o: any) => o.value === value)?.label || label;

  return (
```

por:

```
  }, []);

  const displayLabel = options.find((o) => o.value === value)?.label || label;

  return (
```

### Troca 4
Troque:

```
          } min-w-full w-max max-h-[60vh] overflow-y-auto bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-none shadow-md py-1 z-50`}
        >
          {options.map((opt: any) => (
            <div
              key={opt.value}
```

por:

```
          } min-w-full w-max max-h-[60vh] overflow-y-auto bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-none shadow-md py-1 z-50`}
        >
          {options.map((opt) => (
            <div
              key={opt.value}
```

### Troca 5
Troque:

```
  const { userId, sessionToken, userProfile, logout } = useFinancialAuth();
  const navigate = useNavigate();
  const searchParams = Route.useSearch() as any;

  const currentFlow = FLOW_MAP[flowKey || "Carros"] || FLOW_MAP["Carros"];
```

por:

```
  const { userId, sessionToken, userProfile, logout } = useFinancialAuth();
  const navigate = useNavigate();
  const searchParams = Route.useSearch() as { visit_id?: string; visit_update_id?: string; redirect_uri?: string; return_uri?: string };

  const currentFlow = FLOW_MAP[flowKey || "Carros"] || FLOW_MAP["Carros"];
```

### Troca 6
Troque:

```
  // ou o tempo esgotar (onErrorTimeout limpa este estado).
  const [errorIndex, setErrorIndex] = useState<number | null>(null);
  const [offersList, setOffersList] = useState<any[]>([]);
  const [totalElements, setTotalElements] = useState<number>(0);
  const [fetchError, setFetchError] = useState<"TECHNICAL_INSTABILITY" | null>(null);
```

por:

```
  // ou o tempo esgotar (onErrorTimeout limpa este estado).
  const [errorIndex, setErrorIndex] = useState<number | null>(null);
  const [offersList, setOffersList] = useState<CardOfferItem[]>([]);
  const [totalElements, setTotalElements] = useState<number>(0);
  const [fetchError, setFetchError] = useState<"TECHNICAL_INSTABILITY" | null>(null);
```

### Troca 7
Troque:

```
          if (pageNumber === 1 || !isMobileRef.current) window.scrollTo({ top: 0, behavior: "smooth" });
        }
      } catch (error: any) {
        if (error.name === "AbortError" || controller.signal.aborted) return;
        logSystemError({
```

por:

```
          if (pageNumber === 1 || !isMobileRef.current) window.scrollTo({ top: 0, behavior: "smooth" });
        }
      } catch (caught: unknown) {
        const error = caught as CaughtError;
        if (error.name === "AbortError" || controller.signal.aborted) return;
        logSystemError({
```

### Troca 8
Troque:

```
  // que o React.memo do card funcione (ver CardOfferV.tsx). Sem isso, cada
  // render do pai criava uma função nova e o memo nunca "pegava".
  const handleSimulacao = useCallback(async (offerItem: any, idx: number) => {
    setSimulatingIndex(idx);
    setErrorIndex(null);
```

por:

```
  // que o React.memo do card funcione (ver CardOfferV.tsx). Sem isso, cada
  // render do pai criava uma função nova e o memo nunca "pegava".
  const handleSimulacao = useCallback(async (offerItem: CardOfferItem, idx: number) => {
    setSimulatingIndex(idx);
    setErrorIndex(null);
```

### Troca 9
Troque:

```
        throw new Error("URL de redirecionamento ausente.");
      }
    } catch (error: any) {
      if (error?.code === "SESSION_EXPIRED" || error?.status === 401 || error?.code === 401) {
        clearSession();
```

por:

```
        throw new Error("URL de redirecionamento ausente.");
      }
    } catch (caught: unknown) {
      const error = caught as CaughtError;
      if (error?.code === "SESSION_EXPIRED" || error?.status === 401 || error?.code === 401) {
        clearSession();
```
