Apague estes 3 arquivos sem uso do design system. Não altere mais nada (o index.ts do design system já foi ajustado no prompt anterior).

- `src/design-system/sbx-design-system-9f1c03/components/ui/chart.tsx`
- `src/design-system/sbx-design-system-9f1c03/components/ui/resizable.tsx`
- `src/design-system/sbx-design-system-9f1c03/components/ui/calendar.tsx`
