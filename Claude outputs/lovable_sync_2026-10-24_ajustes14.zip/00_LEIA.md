# Ajustes 14 (2026-10-24) · área 5 dos `any` + cliente do Supabase tipado + recharts 3

Aplicar DEPOIS do ajustes13 (o passo 10 dele, dos tipos do Supabase, é resolvido aqui no prompt 01).

Antes: confirme que o banco de homol tem as mesmas migrations do dev — o prompt 01 usa os tipos gerados do dev.

Só tipos do TypeScript: nada muda no que roda no navegador.

## Lovable: prompts na ordem
01 integrations/supabase/types.ts ... tipos do banco (substitui o passo 10 pendente do ajustes13)
02 integrations/supabase/client.ts ... cliente do Supabase com o tipo do banco
03 components/ui/chart.tsx
04 design-system/sbx-design-system-9f1c03/index.ts
05 features/financial-hub/components/layout/PanelHeader.tsx
06 features/financial-hub/components/shared/renderes/ChartsSimulation.tsx
07 features/financial-hub/components/shared/types.ts
08 features/financial-hub/core/services/gateway.ts
09 integrations/auth/AuthContext.tsx
10 integrations/auth/FinancialAuthContext.tsx
11 router.tsx
12 routes/backoffice.audit.lazy.tsx
13 routes/backoffice.consults.lazy.tsx
14 routes/backoffice.index.lazy.tsx
15 routes/backoffice.routes.lazy.tsx
16 routes/backoffice.simulations.lazy.tsx
17 routes/backoffice.users.lazy.tsx
18 routes/produtos.index.lazy.tsx
19 routes/produtos.lazy.tsx
20 routes/produtos.offer.lazy.tsx ... 9 trocas pontuais
21 routes/sandbox.lazy.tsx
22 services/event.ts
23 services/ibge.ts ... 1 trocas pontuais
24 services/offer.ts ... 5 trocas pontuais
25 services/systemNotification.ts
26 apagar chart.tsx, resizable.tsx e calendar.tsx do design system

Sem migration e sem deploy de função. O package.json de homol não muda.
