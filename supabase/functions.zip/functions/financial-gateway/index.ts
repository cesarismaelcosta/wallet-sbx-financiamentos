/**
 * FINANCIAL GATEWAY - HUB DE INTEGRAÇÃO DE CRÉDITO
 * @version 1.1.0
 * @description Ponto central de orquestração entre o ecossistema Wallet sbX e parceiros financeiros (Fandi).
 * 
 * ============================================================================
 * ARQUITETURA DO FLUXO (A JORNADA DO CLIQUE)
 * ============================================================================
 * 1. INGESTÃO: Recebe o payload estruturado do sbXPAY/Front-end.
 * 2. GATEKEEPER (NOVO): Valida IDOR (propriedade da visita) e disponibilidade da Oferta (Upstream).
 * 3. PERSISTÊNCIA: Aciona o 'simulation_handler' para validar e gravar a intenção (Status: Enviada).
 * 4. INTEGRAÇÃO (HANDSHAKE FANDI):
 *    - GUID: Identificação única da sessão.
 *    - CONTEXTO: Recuperação de regras de negócio do PDV.
 *    - SIMULAÇÃO REAL: Conversão da estimativa local em taxas bancárias.
 *    - INCLUSÃO: Registro da proposta no pipeline do parceiro.
 * 5. WEBHOOK: Canal passivo para atualização de status via 'fandi-service'.
 */

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { processSimulation } from "./simulation-handler.ts";
import { validateRequest } from "../_shared/auth.ts";
import { withSecurity } from "../_shared/server.ts";
import { validateVisitAndOfferIntegrity, validateSimulationIntegrity } from "../_shared/gateKeeper.ts";
import { debugLog } from "../_shared/logger.ts";

serve(withSecurity('financial-gateway', async (req: Request) => {
  // Descoberta da Origem
  const originPath = req.headers.get("x-original-url") || "/";
  const authPath = req.headers.get("x-auth-fallback-url");
  
  // Payload existe no arquivo inteiro, inclusive nos Catchs para pegarmos origin_url
  let payload: any = null;

  try { 

    // =========================================================================
    // 1. SEGURANÇA BÁSICA: VALIDAÇÃO DE IDENTIDADE E TOKEN
    // =========================================================================
    let auth;
    try {
        auth = await validateRequest(req);
    } catch (err: any) {
        const parts = err.message.split(':');
        const errorCode = parts[0].trim();

        let userMessage = "Falha de autenticação. Por favor, faça login novamente.";
        let finalCode = "UNAUTHORIZED";
        let fallbackUrl = authPath;
        let statusCode = 401;

        switch (errorCode) {
            case "SESSION_EXPIRED":
                userMessage = "Sua sessão expirou. Por favor, faça login novamente.";
                finalCode = "SESSION_EXPIRED";
                break;
            case "FORBIDDEN":
                userMessage = "Você não tem permissão para acessar este recurso.";
                finalCode = "FORBIDDEN";
                fallbackUrl = originPath; 
                statusCode = 403;
                break;
            case "INTERNAL_ERROR":
                userMessage = "Ocorreu um erro interno ao validar sua sessão.";
                finalCode = "INTERNAL_ERROR";
                fallbackUrl = originPath; 
                statusCode = 500;
                break;
        }

        return {
            status: statusCode,
            data: { success: false, code: finalCode, message: userMessage, fallback_url: fallbackUrl }
        };
    }

    // =========================================================================
    // 2. ROTA PRINCIPAL E GATEKEEPER DE NEGÓCIO
    // =========================================================================
    
    // Cliente Supabase necessário para o Gatekeeper operar
    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, {
      auth: { persistSession: false },
    });

    try {

      if (req.method === "POST") {
        const rawBody = await req.text();
        if (!rawBody) throw new Error("Payload ausente na requisição POST.");
        payload = JSON.parse(rawBody);

        // Injeção mantida por redundância, mas a segurança real
        // agora é provida pelo Gatekeeper logo abaixo.
        if (payload.entity && auth.user_id) {
          payload.entity.entity_id = String(auth.user_id);
        }
      } else {
        return { status: 405, data: { error: "Método HTTP não permitido." } };
      }

      // ---------------------------------------------------------------------
      // 3. GATEKEEPERS AUTÔNOMOS (Zero-Trust)
      // ---------------------------------------------------------------------
      const targetVisitId = payload.visit_id || null;
      const targetEntityId = payload.entity?.entity_id || null;

      // 3.1: Valida infomações básicas para simulação
      if (!targetVisitId || !targetEntityId) {
        throw new Error("INVALID_PAYLOAD: O parâmetro visit_id é obrigatório para operações financeiras.");
      }

      // 3.1: Valida a Visita Inteira e o Vínculo com a Oferta e Superbid
      debugLog("🚨 [Gateway POST] Validando ownership e upstream...");
      await validateVisitAndOfferIntegrity(supabase, auth, targetVisitId, {
          entity_id: payload.entity?.entity_id || null,
          offer_id: payload.offer?.offer_id || null
      });

      // 3.2: Escudo Anti-Fraude e Cross-Tampering para Crédito
      if (targetVisitId) {
          debugLog("🚨 [Gateway POST] Validando simulação e fraudes cruzadas...");
          await validateSimulationIntegrity(supabase, targetVisitId, {
              simulation_id: payload.simulation_id || null,
              entity_id: payload.entity?.entity_id || null,
              offer_id: payload.offer?.offer_id || null
          });
      }

      // ---------------------------------------------------------------------
      // 4. PROCESSAMENTO DE SIMULAÇÃO (Integração Fandi)
      // ---------------------------------------------------------------------
      // Se chegou até aqui, o usuário é dono da visita e a oferta é real.
      const result = await processSimulation(req, payload);

      return {
        status: 200,
        data: result
      };
      
    } catch (err: any) {
      debugLog("[GATEWAY ERROR]:", err.message);
      
      let errorCode = "BUSINESS_ERROR";
      let userMessage = err.message;
      
      // REGRA DE OURO: Tenta sempre ejetar para a Superbid (payload?.origin_url).
      // Só usa o originPath (Tela do React) como fallback extremo se a origem da visita não existir.
      let finalFallback = payload?.origin_url || originPath || "/";

      if (err.message.includes("OFFER_NOT_FOUND")) {
          userMessage = "Esta oferta não está mais disponível ou não foi encontrada para simulação.";
          errorCode = "OFFER_NOT_FOUND";
      } else if (err.message.includes("INVALID_RELATIONSHIP")) {
          userMessage = "Você não tem permissão para simular nesta oferta.";
          errorCode = "INVALID_RELATIONSHIP";
      } else if (err.message.includes("SESSION_EXPIRED")) {
          userMessage = "Sua sessão expirou. Por favor, faça login novamente.";
          errorCode = "SESSION_EXPIRED";
          finalFallback = authPath; // Única exceção: Manda para o Login
      } else if (err.message.includes("UPSTREAM_CONNECTION_ERROR")) {
          userMessage = "O serviço de consulta da oferta está instável. Tente novamente.";
          errorCode = "UPSTREAM_CONNECTION_ERROR";
      } else if (err.message.includes("FORBIDDEN_ACCESS") || err.message.includes("INVALID_PAYLOAD")) {
          userMessage = "Inconsistência nos dados de segurança.";
          errorCode = "FORBIDDEN";
      }

      return {
        status: 400,
        data: {
          success: false,
          code: errorCode,
          message: userMessage,
          details: errorCode === "BUSINESS_ERROR" ? "Consulte os logs." : "Bloqueio de segurança (Gatekeeper).",
          fallback_url: finalFallback // <--- FALLBACK ESCOLHIDO
        }
      };
    }
  } catch (fatalError: any) {
    // O FAILSAFE ABSOLUTO
    // Se qualquer coisa quebrar (syntax error, banco fora do ar, null pointer),
    // cai aqui ANTES de vazar para o withSecurity.
    
    debugLog(`🚨 [CRASH FATAL INTERCEPTADO]: ${fatalError.message}`);
    
    return {
        status: 500,
        data: {
            success: false,
            code: "INTERNAL_SERVER_ERROR",
            message: "Ocorreu um erro interno inesperado. Tente novamente.",
            fallback_url: payload?.origin_url || originPath || "/" // Faz jornada voltar para a origem da visita ou se não existir origem da chamada.
        }
    };
  } 
}));